package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordGateway#updateCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordGatewayUpdateCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-005833")
    void case_UTAPI_005833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005833",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005833", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005833", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005833", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005833", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005833", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005833", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005833", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005834")
    void case_UTAPI_005834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005834",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005834", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005834", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005834", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005834", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005834", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005834", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005834", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005835")
    void case_UTAPI_005835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005835",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005835", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005835", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005835", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005835", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005835", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005835", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005835", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005836")
    void case_UTAPI_005836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005836",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005836", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005836", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005836", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005836", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005836", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005836", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005836", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005837")
    void case_UTAPI_005837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005837",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005837", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005837", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005837", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005837", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005837", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005837", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005838")
    void case_UTAPI_005838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005838",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005838", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005838", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005838", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005838", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005838", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005838", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005839")
    void case_UTAPI_005839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005839",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005839", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005839", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005839", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005839", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005839", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005839", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005840")
    void case_UTAPI_005840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005840",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005840", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005840", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005840", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005840", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005840", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005840", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005840", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005841")
    void case_UTAPI_005841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005841",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005841", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005841", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005841", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005841", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005841", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005841", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005841", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005842")
    void case_UTAPI_005842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005842",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005842", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005842", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005842", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005842", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005842", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005842", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005842", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005843")
    void case_UTAPI_005843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005843",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005843", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005843", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005843", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005843", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005843", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005843", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005843", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005844")
    void case_UTAPI_005844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005844",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005844", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005844", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005844", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005844", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005844", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005844", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005844", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005845")
    void case_UTAPI_005845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005845",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005845", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005845", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005845", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005845", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005845", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005845", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005845", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005846")
    void case_UTAPI_005846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005846",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005846", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005846", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005846", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005846", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005846", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005846", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005846", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005847")
    void case_UTAPI_005847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005847",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005847", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005847", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005847", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005847", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005847", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005847", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005847", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005848")
    void case_UTAPI_005848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005848",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005848", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005848", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005848", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005848", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005848", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005848", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005848", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005849")
    void case_UTAPI_005849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005849",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005849", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005849", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005849", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005849", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005849", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005849", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005849", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005850")
    void case_UTAPI_005850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005850",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005850", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005850", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005850", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005850", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005850", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005850", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005850", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005851")
    void case_UTAPI_005851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005851",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005851", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005851", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005851", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005851", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005851", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005851", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005851", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005852")
    void case_UTAPI_005852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005852",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005852", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005852", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005852", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005852", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005852", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005852", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005852", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005853")
    void case_UTAPI_005853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005853",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005853", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005853", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005853", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005853", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005853", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005853", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005853", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005854")
    void case_UTAPI_005854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005854",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005854", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005854", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005854", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005854", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005854", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005854", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005854", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005855")
    void case_UTAPI_005855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005855",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005855", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005855", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005855", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005855", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005855", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005855", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005855", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005856")
    void case_UTAPI_005856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005856",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005856", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005856", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005856", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005856", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005856", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005856", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005856", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005857")
    void case_UTAPI_005857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005857",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005857", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005857", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005857", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005857", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005857", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005857", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005858")
    void case_UTAPI_005858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005858",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005858", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005858", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005858", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005858", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005858", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005858", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005858")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005859")
    void case_UTAPI_005859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005859",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005859", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005859", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005859", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005859", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005859", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005859", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005859", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005859", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005859", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005859", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005859", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005859")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005860")
    void case_UTAPI_005860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005860",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005860", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005860", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005860", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005860", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005860", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005860", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005860", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005860", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005860", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005860", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005860", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005860")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005861")
    void case_UTAPI_005861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005861",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005861", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005861", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005861", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005861", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005861", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005861", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005861", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005861", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005861", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005861", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005861", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005861")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005862")
    void case_UTAPI_005862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005862",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005862", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005862", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005862", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005862", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005862", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005862", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005862", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005862", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005862", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005862", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005862", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005862")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005863")
    void case_UTAPI_005863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005863",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005863", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005863", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005863", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005863", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005863", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005863", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005863", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005863", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005863", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005863", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005863", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005863")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005864")
    void case_UTAPI_005864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005864",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005864", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005864", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005864", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005864", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005864", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005864", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005864", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005864", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005864", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005864", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005864", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005864")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005865")
    void case_UTAPI_005865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005865",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005865", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005865", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005865", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005865", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005865", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005865", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005865", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005865", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005865", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005865", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005865", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005865")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005866")
    void case_UTAPI_005866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005866",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005866", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005866", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005866", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005866", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005866", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005866", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005866", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005866", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005866", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005866", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005866", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005866")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005867")
    void case_UTAPI_005867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005867",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005867", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005867", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005867", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005867", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005867", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005867", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005867", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005867", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005867", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005867", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005867", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005867")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005868")
    void case_UTAPI_005868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005868",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005868", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005868", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005868", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005868", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005868", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005868", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005868", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005868", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005868", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005868", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005868", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005868")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005869")
    void case_UTAPI_005869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005869",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005869", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005869", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005869", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005869", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005869", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005869", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005869", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005869", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005869", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005869", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005869", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005869")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005870")
    void case_UTAPI_005870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005870",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005870", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005870", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005870", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005870", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005870", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005870", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005870", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005870", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005871")
    void case_UTAPI_005871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005871",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005871", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005871", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005871", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005871", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005871", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005871", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005871", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005871", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005872")
    void case_UTAPI_005872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005872",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005872", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005872", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005872", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005872", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005872", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005872", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005872", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005872", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005873")
    void case_UTAPI_005873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005873",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005873", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005873", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005873", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005873", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005873", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005873", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005873", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005873", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005874")
    void case_UTAPI_005874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005874",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005874", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005874", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005874", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005874", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005874", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005874", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005874", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005874", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005875")
    void case_UTAPI_005875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005875",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005875", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005875", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005875", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005875", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005875", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005875", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005875", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005875", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005876")
    void case_UTAPI_005876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005876",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005876", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005876", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005876", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005876", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005876", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005876", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005876", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005876", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005877")
    void case_UTAPI_005877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005877",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005877", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005877", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005877", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005877", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005877", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005877", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005877", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005877", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005878")
    void case_UTAPI_005878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005878",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005878", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005878", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005878", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005878", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005878", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005878", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005878", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005879")
    void case_UTAPI_005879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005879",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005879", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005879", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005879", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005879", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005879", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005879", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005879", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005880")
    void case_UTAPI_005880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005880",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005880", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005880", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005880", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005880", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005880", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005880", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005880", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005881")
    void case_UTAPI_005881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005881",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005881", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005881", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005881", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005881", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005881", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005881", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005881", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005881", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005882")
    void case_UTAPI_005882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005882",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005882", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005882", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005882", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005882", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005882", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005882", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005883")
    void case_UTAPI_005883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005883",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005883", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005883", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005883", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005883", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005883", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005883", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005884")
    void case_UTAPI_005884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005884",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005884", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005884", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005884", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005884", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005884", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005884", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005885")
    void case_UTAPI_005885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005885",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005885", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005885", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005885", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005885", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005885", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005885", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005886")
    void case_UTAPI_005886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005886",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005886", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005886", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005886", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005886", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005886", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005886", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005887")
    void case_UTAPI_005887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005887",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005887", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005887", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005887", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005887", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005887", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005888")
    void case_UTAPI_005888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005888",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005888", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005888", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005888", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005888", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005888", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005889")
    void case_UTAPI_005889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005889",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005889", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005889", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005889", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005889", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005889", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005890")
    void case_UTAPI_005890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005890",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005890", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005890", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005890", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005890", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005890", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005891")
    void case_UTAPI_005891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005891",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005891", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005891", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005891", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005891", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005891", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005892")
    void case_UTAPI_005892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005892",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005892", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005892", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005892", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005892", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005892", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005893")
    void case_UTAPI_005893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005893",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005893", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005893", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005893", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005893", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005893", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005894")
    void case_UTAPI_005894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005894",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005894", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005894", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005894", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005894", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005894", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005895")
    void case_UTAPI_005895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005895",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005895", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005895", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005895", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005895", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005895", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005895", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005896")
    void case_UTAPI_005896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005896",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005896", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005896", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005896", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005896", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005896", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005896", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005897")
    void case_UTAPI_005897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005897",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005897", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005897", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005897", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005897", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005897", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005897", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005898")
    void case_UTAPI_005898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005898",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005898", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005898", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005898", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005898", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005898", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005898", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005899")
    void case_UTAPI_005899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005899",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005899", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005899", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005899", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005899", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005899", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005900")
    void case_UTAPI_005900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005900",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005900", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005900", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005900", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005900", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005900", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005901")
    void case_UTAPI_005901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005901",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005901", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005901", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005901", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005901", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005901", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005902")
    void case_UTAPI_005902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005902",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005902", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005902", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005902", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005902", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005902", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005903")
    void case_UTAPI_005903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005903",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005903", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005903", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005903", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005903", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005903", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005904")
    void case_UTAPI_005904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005904",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005904", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005904", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005904", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005904", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005904", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005905")
    void case_UTAPI_005905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005905",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005905", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005905", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005905", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005905", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005905", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005906")
    void case_UTAPI_005906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005906",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005906", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005906", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005906", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005906", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005906", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005907")
    void case_UTAPI_005907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005907",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005907", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005907", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005907", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005907", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005907", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005908")
    void case_UTAPI_005908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005908",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005908", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005908", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005908", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005908", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005908", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005909")
    void case_UTAPI_005909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005909",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005909", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005909", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005909", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005909", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005909", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005910")
    void case_UTAPI_005910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005910",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005910", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005910", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005910", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005910", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005910", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005911")
    void case_UTAPI_005911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005911",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005911", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005911", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005911", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005911", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005911", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005912")
    void case_UTAPI_005912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005912",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005912", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005912", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005912", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005912", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005912", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005913")
    void case_UTAPI_005913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005913",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005913", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005913", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005913", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005913", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005913", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005914")
    void case_UTAPI_005914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005914",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005914", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005914", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005914", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005914", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005914", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005915")
    void case_UTAPI_005915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005915",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005915", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005915", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005915", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005915", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005915", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005916")
    void case_UTAPI_005916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005916",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005916", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005916", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005916", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005916", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005916", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005917")
    void case_UTAPI_005917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005917",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005917", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005917", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005917", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005917", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005917", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005918")
    void case_UTAPI_005918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005918",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005918", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005918", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005918", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005918", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005918", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005919")
    void case_UTAPI_005919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005919",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005919", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005919", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005919", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005919", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005919", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005920")
    void case_UTAPI_005920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005920",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005920", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005920", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005920", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005920", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005920", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005921")
    void case_UTAPI_005921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005921",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005921", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005921", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005921", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005921", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005921", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005922")
    void case_UTAPI_005922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005922",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005922", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005922", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005922", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005922", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005923")
    void case_UTAPI_005923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005923",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005923", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005923", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005923", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005923", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005924")
    void case_UTAPI_005924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005924",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005924", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005924", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005924", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005924", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005925")
    void case_UTAPI_005925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005925",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005925", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005925", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005925", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005925", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005926")
    void case_UTAPI_005926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005926",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005926", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005926", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005926", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005926", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005927")
    void case_UTAPI_005927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005927",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005927", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005927", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005927", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005927", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005928")
    void case_UTAPI_005928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005928",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005928", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005928", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005928", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005928", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005929")
    void case_UTAPI_005929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005929",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005929", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005929", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005929", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005929", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005930")
    void case_UTAPI_005930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005930",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005930", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005930", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005930", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005930", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005931")
    void case_UTAPI_005931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005931",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005931", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005931", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005931", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005931", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005932")
    void case_UTAPI_005932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005932",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005932", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005932", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005932", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005932", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005933")
    void case_UTAPI_005933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005933",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005933", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005933", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005933", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005933", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005934")
    void case_UTAPI_005934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005934",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005934", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005934", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005934", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005934", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005934", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005935")
    void case_UTAPI_005935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005935",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005935", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005935", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005935", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005935", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005935", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005936")
    void case_UTAPI_005936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005936",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005936", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005936", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005936", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005936", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005936", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005937")
    void case_UTAPI_005937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005937",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005937", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005937", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005937", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005937", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005937", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005938")
    void case_UTAPI_005938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005938",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005938", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005938", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005938", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005938", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005938", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005939")
    void case_UTAPI_005939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005939",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005939", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005939", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005939", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005939", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005940")
    void case_UTAPI_005940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005940",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005940", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005940", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005940", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005940", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005941")
    void case_UTAPI_005941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005941",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005941", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005941", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005941", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005941", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005942")
    void case_UTAPI_005942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005942",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005942", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005942", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005942", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005942", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005943")
    void case_UTAPI_005943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005943",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005943", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005943", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005943", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005943", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005944")
    void case_UTAPI_005944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005944",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005944", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005944", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005944", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005944", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005945")
    void case_UTAPI_005945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005945",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005945", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005945", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005945", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005945", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005946")
    void case_UTAPI_005946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005946",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005946", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005946", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005946", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005946", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005947")
    void case_UTAPI_005947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005947",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005947", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005947", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005947", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005947", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005948")
    void case_UTAPI_005948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005948",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005948", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005948", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005948", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005948", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005949")
    void case_UTAPI_005949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005949",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005949", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005949", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005949", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005949", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005949", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005950")
    void case_UTAPI_005950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005950",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005950", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005950", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005950", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005950", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005950", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005951")
    void case_UTAPI_005951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005951",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005951", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005951", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005951", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005951", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005951", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005952")
    void case_UTAPI_005952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005952",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005952", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005952", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005952", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005952", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005952", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005953")
    void case_UTAPI_005953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005953",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005953", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005953", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005953", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005953", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005953", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005954")
    void case_UTAPI_005954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005954",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005954", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005954", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005954", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005954", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005954", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005954")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005955")
    void case_UTAPI_005955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005955",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005955", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005955", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005955", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005955", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005955")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005956")
    void case_UTAPI_005956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005956",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005956", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005956", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005956", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005956", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005956")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005957")
    void case_UTAPI_005957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005957",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005957", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005957", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005957", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005957", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005957")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005958")
    void case_UTAPI_005958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005958",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005958", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005958", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005958", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005958", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005958")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005959")
    void case_UTAPI_005959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005959",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005959", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005959", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005959", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005959", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005959")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005960")
    void case_UTAPI_005960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005960",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005960", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005960", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005960", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005960", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005960")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005961")
    void case_UTAPI_005961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005961",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005961", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005961", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005961", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005961", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005961")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005962")
    void case_UTAPI_005962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005962",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005962", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005962", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005962", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005962", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005962")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005963")
    void case_UTAPI_005963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005963",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005963", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005963", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005963", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005963", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005963")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005964")
    void case_UTAPI_005964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005964",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005964", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005964", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005964", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005964", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005964")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005965")
    void case_UTAPI_005965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005965",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005965", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005965", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005965", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005965", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005966")
    void case_UTAPI_005966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005966",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005966", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005966", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005966", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005966", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005966", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005967")
    void case_UTAPI_005967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005967",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005967", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005967", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005967", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005967", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005968")
    void case_UTAPI_005968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005968",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005968", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005968", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005968", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005968", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005969")
    void case_UTAPI_005969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005969",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005969", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005969", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005969", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005969", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005970")
    void case_UTAPI_005970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005970",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005970", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005970", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005970", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005970", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005970", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005971")
    void case_UTAPI_005971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005971",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005971", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005971", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005971", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005971", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005971", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005972")
    void case_UTAPI_005972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005972",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005972", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005972", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005972", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005972", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005972", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005973")
    void case_UTAPI_005973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005973",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005973", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005973", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005973", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005973", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005973", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005974")
    void case_UTAPI_005974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005974",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005974", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005974", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005974", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005974", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005974", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005974", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005975")
    void case_UTAPI_005975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005975",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005975", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005975", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005975", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005975", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005975", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005975", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005976")
    void case_UTAPI_005976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005976",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005976", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005976", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005976", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005976", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005976", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005976", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005977")
    void case_UTAPI_005977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005977",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005977", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005977", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005977", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005977", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005977", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005977", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005978")
    void case_UTAPI_005978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005978",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005978", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005978", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005978", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005978", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005978", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005978", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005979")
    void case_UTAPI_005979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005979",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005979", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005979", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005979", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005979", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005979", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005979", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005980")
    void case_UTAPI_005980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005980",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005980", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005980", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005980", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005980", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005980", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005980", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005981")
    void case_UTAPI_005981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005981",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005981", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005981", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005981", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005981", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005981", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005981", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005982")
    void case_UTAPI_005982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005982",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005982", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005982", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005982", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005982", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005982", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005983")
    void case_UTAPI_005983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005983",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005983", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005983", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005983", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005983", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005983", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005984")
    void case_UTAPI_005984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005984",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005984", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005984", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005984", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005984", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005984", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005984", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005985")
    void case_UTAPI_005985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005985",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005985", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005985", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005985", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005985", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005985", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005985", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005986")
    void case_UTAPI_005986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005986",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005986", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005986", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005986", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005986", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005986", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005986", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005987")
    void case_UTAPI_005987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005987",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005987", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005987", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005987", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005987", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005987", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005987", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005988")
    void case_UTAPI_005988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005988",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005988", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005988", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005988", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005988", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005988", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005988", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005988", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005989")
    void case_UTAPI_005989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005989",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005989", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005989", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005989", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005989", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005989", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005989", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005989", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005990")
    void case_UTAPI_005990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005990",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005990", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005990", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005990", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005990", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005990", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005990", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005990", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005991")
    void case_UTAPI_005991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005991",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005991", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005991", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005991", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005991", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005991", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005991", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005992")
    void case_UTAPI_005992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005992",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005992", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005992", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005992", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005992", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005992", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005993")
    void case_UTAPI_005993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005993",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005993", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005993", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005993", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005993", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005993", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005994")
    void case_UTAPI_005994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005994",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005994", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005994", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005994", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005994", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005994", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005994", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005995")
    void case_UTAPI_005995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005995",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005995", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005995", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005995", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005995", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005996")
    void case_UTAPI_005996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005996",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005996", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005996", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005996", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005996", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005997")
    void case_UTAPI_005997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005997",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005997", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005997", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005997", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005997", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005998")
    void case_UTAPI_005998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005998",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005998", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005998", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005998", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005998", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005999")
    void case_UTAPI_005999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005999",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005999", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-005999", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-005999", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-005999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005999", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006000")
    void case_UTAPI_006000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006000",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006000", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006000", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006000", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006000", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006001")
    void case_UTAPI_006001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006001",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006001", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006001", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006001", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006001", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006002")
    void case_UTAPI_006002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006002",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006002", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006002", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006002", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006002", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006003")
    void case_UTAPI_006003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006003",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006003", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006003", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006003", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006003", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006004")
    void case_UTAPI_006004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006004",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006004", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006004", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006004", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006004", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006005")
    void case_UTAPI_006005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006005",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006005", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006005", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006005", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006005", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006005", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006006")
    void case_UTAPI_006006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006006",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006006", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006006", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006006", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006006", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006006", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006007")
    void case_UTAPI_006007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006007",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006007", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006007", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006007", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006007", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006007", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006008")
    void case_UTAPI_006008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006008",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006008", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006008", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006008", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006008", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006008", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006009")
    void case_UTAPI_006009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006009",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006009", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006009", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006009", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006009", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006009", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006010")
    void case_UTAPI_006010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006010",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006010", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006010", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006010", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006010", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006010", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006011")
    void case_UTAPI_006011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006011",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006011", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006011", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006011", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006011", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006011", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006012")
    void case_UTAPI_006012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006012",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006012", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006012", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006012", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006012", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006012", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006013")
    void case_UTAPI_006013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006013",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006013", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006013", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006013", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006013", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006013", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006014")
    void case_UTAPI_006014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006014",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006014", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006014", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006014", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006014", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006014", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006015")
    void case_UTAPI_006015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006015",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006015", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006015", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006015", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006015", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006015", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006015", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006015", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006016")
    void case_UTAPI_006016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006016",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006016", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006016", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006016", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006016", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006016", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006016", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006017")
    void case_UTAPI_006017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006017",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006017", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006017", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006017", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006017", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006017", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006017", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006018")
    void case_UTAPI_006018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006018",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006018", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006018", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006018", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006018", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006018", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006018", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006019")
    void case_UTAPI_006019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006019",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006019", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006019", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006019", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006019", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006019", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006019", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006020")
    void case_UTAPI_006020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006020",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006020", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006020", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006020", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006020", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006020", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006020", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006021")
    void case_UTAPI_006021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006021",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006021", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006021", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006021", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006021", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006021", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006021", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-006022")
    void case_UTAPI_006022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006022",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006022", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006022", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006022", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006022", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006022", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006022", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

}

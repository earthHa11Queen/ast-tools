package com.matsushita.dbeditor.utils;

import java.util.Arrays;

/**
 * A single executable condition of the Oracle Plan.
 *
 * <p>Value references are resolved against the values that TestDataRuntime produced
 * for this CaseNo, so the expected condition of every check is the Case own input
 * condition and not a generic constant.</p>
 *
 * <ul>
 *   <li>{@code data:&lt;dataId&gt;} - the value obtained for that dataId</li>
 *   <li>{@code arg:&lt;index&gt;} - the argument object actually passed to the SUT</li>
 *   <li>{@code text:&lt;literal&gt;} - a literal taken from the declared contract</li>
 * </ul>
 */
public final class OracleCheck {

    private final CheckType type;
    private final String[] params;
    private final String description;

    public OracleCheck(CheckType type, String description, String... params) {
        this.type = type;
        this.description = description;
        this.params = params == null ? new String[0] : params;
    }

    public CheckType type() {
        return type;
    }

    public String description() {
        return description;
    }

    public String param(int index) {
        if (index < params.length) {
            return params[index];
        } else {
            return null;
        }
    }

    public int paramCount() {
        return params.length;
    }

    @Override
    public String toString() {
        return type + Arrays.toString(params);
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryUseCase#restoreHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryUseCaseRestoreHistoryScenario {

    @Test
    @DisplayName("UTAPI-013145")
    void case_UTAPI_013145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013145",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013145", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013145", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013145", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013145")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013146")
    void case_UTAPI_013146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013146",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013146", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013146", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013146", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013146")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013147")
    void case_UTAPI_013147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013147",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013147", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013147", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013147", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013147")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013148")
    void case_UTAPI_013148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013148",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013148", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013148", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013148", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013148")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013149")
    void case_UTAPI_013149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013149",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013149", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013149", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013149", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013149")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013150")
    void case_UTAPI_013150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013150",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013150", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013150", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013150", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013150")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013151")
    void case_UTAPI_013151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013151",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013151", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013151", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013151", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013151")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013152")
    void case_UTAPI_013152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013152",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013152", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013152", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013152", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013152")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013153")
    void case_UTAPI_013153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013153",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013153", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013153", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013153", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013153")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013154")
    void case_UTAPI_013154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013154",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013154", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013154", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013154", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013154")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013155")
    void case_UTAPI_013155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013155",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013155", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013155", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013155", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013155")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013156")
    void case_UTAPI_013156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013156",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013156", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013156", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013156", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013156", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013156")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013157")
    void case_UTAPI_013157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013157",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013157", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013157", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013157", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013157", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013157")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013158")
    void case_UTAPI_013158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013158",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013158", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013158", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013158", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013158", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013158")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013159")
    void case_UTAPI_013159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013159",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013159", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013159", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013159", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013159", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013159")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013160")
    void case_UTAPI_013160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013160",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013160", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013160", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013160", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013160", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013160")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013161")
    void case_UTAPI_013161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013161",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013161", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013161", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013161", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013161", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013161")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013162")
    void case_UTAPI_013162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013162",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013162", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013162", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013162", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013162", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013162")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013163")
    void case_UTAPI_013163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013163",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013163", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013163", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013163", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013163", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013163")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013164")
    void case_UTAPI_013164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013164",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013164", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013164", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013164", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013164", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013164")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013165")
    void case_UTAPI_013165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013165",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013165", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013165", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013165", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013165", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013165")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013166")
    void case_UTAPI_013166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013166",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013166", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013166", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013166", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013166", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013166")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013167")
    void case_UTAPI_013167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013167",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013167", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013167", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013167", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013167", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013167")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013168")
    void case_UTAPI_013168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013168",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013168", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013168", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013168", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013168", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013168")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013169")
    void case_UTAPI_013169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013169",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013169", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013169", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013169", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013169", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013169")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013170")
    void case_UTAPI_013170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013170",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013170", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013170", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013170", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013170", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013170")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013171")
    void case_UTAPI_013171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013171",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013171", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013171", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013171", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013171", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013171")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013172")
    void case_UTAPI_013172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013172",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013172", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013172", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013172", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013172", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013172")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013173")
    void case_UTAPI_013173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013173",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013173", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013173", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013173", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013173", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013173")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013174")
    void case_UTAPI_013174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013174",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013174", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013174", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013174", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013174", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013174")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013175")
    void case_UTAPI_013175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013175",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013175", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013175", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013175", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013175", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013175")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013176")
    void case_UTAPI_013176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013176",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013176", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013176", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013176", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013176", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013176")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013177")
    void case_UTAPI_013177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013177",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013177", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013177", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013177", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013177", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013177")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013178")
    void case_UTAPI_013178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013178",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013178", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013178", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013178", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013178", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013178")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013179")
    void case_UTAPI_013179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013179",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013179", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013179", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013179", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013179")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013180")
    void case_UTAPI_013180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013180",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013180", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013180", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013180", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013180")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013181")
    void case_UTAPI_013181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013181",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013181", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013181", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013181", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013181")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013182")
    void case_UTAPI_013182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013182",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013182", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013182", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013182", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013182")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013183")
    void case_UTAPI_013183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013183",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013183", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013183", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013183", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013183")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013184")
    void case_UTAPI_013184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013184",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013184", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013184", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013184", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013184")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013185")
    void case_UTAPI_013185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013185",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013185", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013185", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013185", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013185")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013186")
    void case_UTAPI_013186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013186",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013186", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013186", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013186", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013186")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013187")
    void case_UTAPI_013187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013187",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013187", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013187", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013187", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013187")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013188")
    void case_UTAPI_013188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013188",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013188", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013188", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013188", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013188")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013189")
    void case_UTAPI_013189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013189",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013189", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013189", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013189", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013189")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013190")
    void case_UTAPI_013190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013190",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013190", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013190", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013190", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013190")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013191")
    void case_UTAPI_013191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013191",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013191", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013191", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013191", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013191")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013192")
    void case_UTAPI_013192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013192",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013192", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013192", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013192", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013192")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013193")
    void case_UTAPI_013193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013193",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013193", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013193", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013193", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013193")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013194")
    void case_UTAPI_013194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013194",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013194", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013194", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013194", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013194")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013195")
    void case_UTAPI_013195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013195",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013195", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013195", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013195", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013195")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013196")
    void case_UTAPI_013196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013196",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013196", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013196", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013196", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013196")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013197")
    void case_UTAPI_013197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013197",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013197", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013197", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013197", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013197")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013198")
    void case_UTAPI_013198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013198",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013198", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013198", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013198", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013198")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013199")
    void case_UTAPI_013199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013199",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013199", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013199", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013199", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013199")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013200")
    void case_UTAPI_013200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013200",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013200", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013200", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013200", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013200")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013201")
    void case_UTAPI_013201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013201",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013201", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013201", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013201", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013201")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013202")
    void case_UTAPI_013202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013202",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013202", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013202", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013202", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013202")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013203")
    void case_UTAPI_013203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013203",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013203", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013203", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013203", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013203")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013204")
    void case_UTAPI_013204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013204",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013204", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013204", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013204", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013204")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013205")
    void case_UTAPI_013205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013205",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013205", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013205", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013205", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013205")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013206")
    void case_UTAPI_013206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013206",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013206", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013206", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013206", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013206")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013207")
    void case_UTAPI_013207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013207",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013207", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013207", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013207", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013207")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013208")
    void case_UTAPI_013208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013208",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013208", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013208", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013208", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013208")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.restoreHistory", "tableHistoryRepository", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.restoreHistory must carry the value generated for schemaName", "tableHistoryRepository", "restoreHistory", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.restoreHistory must carry the value generated for tableName", "tableHistoryRepository", "restoreHistory", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.restoreHistory must carry the value generated for seq", "tableHistoryRepository", "restoreHistory", "3", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

}

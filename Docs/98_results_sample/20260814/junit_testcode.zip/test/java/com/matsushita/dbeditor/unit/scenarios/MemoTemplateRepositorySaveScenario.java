package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoTemplateRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoTemplateRepository#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoTemplateRepositorySaveScenario {

    @Test
    @DisplayName("UTAPI-007028")
    void case_UTAPI_007028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007028",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007028", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007028", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007028", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007028", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007028", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007028")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007029")
    void case_UTAPI_007029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007029",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007029", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007029", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007029", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007029", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007029", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007029")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007030")
    void case_UTAPI_007030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007030",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007030", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007030", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007030", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007030", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007030", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007030")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007031")
    void case_UTAPI_007031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007031",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007031", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007031", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007031", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007031", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007031", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007031")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007032")
    void case_UTAPI_007032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007032",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007032", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007032", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007032", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007032", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007032", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007032")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007033")
    void case_UTAPI_007033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007033",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007033", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007033", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007033", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007033", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007033", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007033")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007034")
    void case_UTAPI_007034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007034",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007034", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007034", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007034", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007034", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007034", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007034")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007035")
    void case_UTAPI_007035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007035",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007035", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007035", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007035", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007035", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007035", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007035")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007036")
    void case_UTAPI_007036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007036",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007036", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007036", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007036", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007036", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007036", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007036")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007037")
    void case_UTAPI_007037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007037",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007037", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007037", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007037", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007037", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007037", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007037")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007038")
    void case_UTAPI_007038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007038",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007038", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007038", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007038", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007038", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007038", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007038")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007039")
    void case_UTAPI_007039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007039",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007039", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007039", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007039", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007039", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007039", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007039")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007040")
    void case_UTAPI_007040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007040",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007040", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007040", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007040", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007040", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007040", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007040")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007041")
    void case_UTAPI_007041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007041",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007041", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007041", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007041", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007041", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007041", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007041")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007042")
    void case_UTAPI_007042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007042",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007042", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007042", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007042", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007042", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007042", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007042")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007043")
    void case_UTAPI_007043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007043",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007043", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007043", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007043", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007043", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007043", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007043")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007044")
    void case_UTAPI_007044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007044",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007044", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007044", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007044", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007044", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007044", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007044")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007045")
    void case_UTAPI_007045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007045",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007045", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007045", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007045", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007045", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007045", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007045")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007046")
    void case_UTAPI_007046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007046",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007046", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007046", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007046", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007046", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007046", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007046")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007047")
    void case_UTAPI_007047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007047",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007047", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007047", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007047", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007047", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007047", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007047")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007048")
    void case_UTAPI_007048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007048",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007048", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007048", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007048", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007048", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007048", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007048")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007049")
    void case_UTAPI_007049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007049",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007049", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007049", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007049", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007049", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007049", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007049")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007050")
    void case_UTAPI_007050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007050",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007050", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007050", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007050", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007050", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007050", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007050")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007051")
    void case_UTAPI_007051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007051",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007051", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007051", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007051", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007051", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007051", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007051")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007052")
    void case_UTAPI_007052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007052",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007052", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007052", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007052", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007052", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007052", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007052")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007053")
    void case_UTAPI_007053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007053",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007053", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007053", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007053", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007053", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007053", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007053")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007054")
    void case_UTAPI_007054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007054",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007054", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007054", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007054", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007054", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007054", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007054")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007055")
    void case_UTAPI_007055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007055",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007055", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007055", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007055", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007055", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007055", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007055")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007056")
    void case_UTAPI_007056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007056",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007056", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007056", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007056", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007056", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007056", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007056")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007057")
    void case_UTAPI_007057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007057",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007057", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007057", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007057", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007057", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007057", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007057")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007058")
    void case_UTAPI_007058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007058",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007058", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007058", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007058", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007058", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007058", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007058")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007059")
    void case_UTAPI_007059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007059",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007059", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007059", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007059", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007059", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007059", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007059")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007060")
    void case_UTAPI_007060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007060",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007060", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007060", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007060", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007060", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007060", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007060")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007061")
    void case_UTAPI_007061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007061",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007061", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007061", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007061", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007061", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007061", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007061")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007062")
    void case_UTAPI_007062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007062",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007062", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007062", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007062", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007062", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007062", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007062")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007063")
    void case_UTAPI_007063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007063",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007063", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007063", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007063", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007063", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007063", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007063")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007064")
    void case_UTAPI_007064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007064",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007064", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007064", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007064", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007064", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007064", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007064")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007065")
    void case_UTAPI_007065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007065",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007065", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007065", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007065", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007065", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007065", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007065")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007066")
    void case_UTAPI_007066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007066",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007066", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007066", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007066", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007066", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007066", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007066")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007067")
    void case_UTAPI_007067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007067",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007067", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007067", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007067", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007067", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007067", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007067")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007068")
    void case_UTAPI_007068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007068",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007068", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007068", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007068", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007068", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007068", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007068")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007069")
    void case_UTAPI_007069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007069",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007069", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007069", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007069", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007069", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007069", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007069")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007070")
    void case_UTAPI_007070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007070",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007070", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007070", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007070", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007070", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007070", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007070")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007071")
    void case_UTAPI_007071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007071",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007071", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007071", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007071", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007071", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007071", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007071")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007072")
    void case_UTAPI_007072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007072",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007072", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007072", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007072", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007072", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007072", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007072")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007073")
    void case_UTAPI_007073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007073",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007073", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007073", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007073", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007073", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007073", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007073")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007074")
    void case_UTAPI_007074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007074",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007074", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007074", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007074", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007074", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007074", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007074")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007075")
    void case_UTAPI_007075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007075",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007075", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007075", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007075", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007075", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007075", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007075")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007076")
    void case_UTAPI_007076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007076",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007076", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007076", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007076", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007076", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007076", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007076")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007077")
    void case_UTAPI_007077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007077",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007077", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007077", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007077", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007077", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007077", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007077")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007078")
    void case_UTAPI_007078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007078",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007078", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007078", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007078", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007078", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007078", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007078")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007079")
    void case_UTAPI_007079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007079",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007079", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007079", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007079", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007079", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007079", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007079")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007080")
    void case_UTAPI_007080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007080",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007080", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007080", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007080", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007080", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007080", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007080")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "56:space")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007081")
    void case_UTAPI_007081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007081",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007081", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007081", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007081", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007081", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007081", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007081")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007082")
    void case_UTAPI_007082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007082",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007082", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007082", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007082", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007082", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007082", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007082")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007083")
    void case_UTAPI_007083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007083",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007083", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007083", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007083", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007083", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007083", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007083")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "59:tab")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007084")
    void case_UTAPI_007084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007084",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007084", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007084", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007084", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007084", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007084", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007084")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007085")
    void case_UTAPI_007085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007085",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007085", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007085", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007085", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007085", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007085", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007085")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007086")
    void case_UTAPI_007086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007086",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007086", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007086", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007086", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007086", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007086", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007086")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007087")
    void case_UTAPI_007087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007087",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007087", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-007087", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007087", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007087", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007087", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007087")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

}

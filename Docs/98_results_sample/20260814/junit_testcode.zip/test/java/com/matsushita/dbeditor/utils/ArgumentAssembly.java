package com.matsushita.dbeditor.utils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.matsushita.dbeditor.fixtures.SentinelRegistry;

/**
 * Builds the argument list of the target method.
 *
 * <p>Parameters are matched to instruction rows by dataId, which is derived from the AST
 * argument name, never from the row order of the CSV. Values come from TestDataRuntime;
 * project DTO graphs are assembled by ProjectObjectFactory.</p>
 */
public final class ArgumentAssembly {

    private ArgumentAssembly() {
    }

    public static Arguments build(CaseDefinition def, SentinelRegistry registry, String mirrorY,
            boolean excelFlavour) {
        List<DataRef> refs = def.dataRefs();
        Map<String, DataRef> byId = new LinkedHashMap<String, DataRef>();
        for (int i = 0; i < refs.size(); i++) {
            byId.put(refs.get(i).dataId(), refs.get(i));
        }
        Map<String, Object> collected = new LinkedHashMap<String, Object>();
        List<Object> args = new ArrayList<Object>();
        for (int i = 0; i < def.params().size(); i++) {
            ParamSpec p = def.params().get(i);
            String dataId = p.dataId();
            if (dataId == null) {
                args.add(null);
                continue;
            }
            DataRef ref = byId.get(dataId);
            if (ref == null) {
                throw new HarnessException("dataId " + dataId + " is not present in test-data-instruction for "
                        + def.caseNo());
            }
            String rowMirrorY = ref.dataRole().equals("TARGET") ? mirrorY : "-";
            Object value = ProjectObjectFactory.build(def.caseNo(), refs, ref, rowMirrorY, excelFlavour,
                    registry, collected);
            args.add(coerceForParameter(value, p.declaredType()));
            collected.put(dataId, args.get(args.size() - 1));
        }
        return new Arguments(args.toArray(new Object[0]), collected);
    }

    private static Object coerceForParameter(Object value, String declaredType) {
        String raw = TypeSupport.raw(declaredType);
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            Number n = (Number) value;
            if ("int".equals(raw) || "Integer".equals(raw)) {
                return Integer.valueOf(n.intValue());
            }
            if ("long".equals(raw) || "Long".equals(raw)) {
                return Long.valueOf(n.longValue());
            }
            if ("short".equals(raw) || "Short".equals(raw)) {
                return Short.valueOf(n.shortValue());
            }
            if ("byte".equals(raw) || "Byte".equals(raw)) {
                return Byte.valueOf(n.byteValue());
            }
            if ("double".equals(raw) || "Double".equals(raw)) {
                return Double.valueOf(n.doubleValue());
            }
            if ("float".equals(raw) || "Float".equals(raw)) {
                return Float.valueOf(n.floatValue());
            }
        }
        return value;
    }
}

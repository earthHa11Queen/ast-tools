package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for GetTableListUseCase.
 */
public final class GetTableListUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.table.GetTableListUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.table.GetTableListUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository", "tableMetadataRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository", "TableMetadataRepository"};
    private static final String[] TYPES_execute = new String[] {"Integer"};

    public GetTableListUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** List<TableMetadata> execute(connectionId) */
    public ExecutionResult execute(Object[] args) {
        return invoke("execute", TYPES_execute, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("execute".equals(operation)) {
            return execute(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

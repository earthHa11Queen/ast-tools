package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlGateway#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlGatewaySaveScenario {

    @Test
    @DisplayName("UTAPI-002965")
    void case_UTAPI_002965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002965",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002965", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002965", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002965", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002965", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002965", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002965", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002965", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002966")
    void case_UTAPI_002966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002966",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002966", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002966", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002966", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002966", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002966", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002966", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002966", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002967")
    void case_UTAPI_002967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002967",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002967", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002967", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002967", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002967", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002967", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002967", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002967", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002968")
    void case_UTAPI_002968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002968",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002968", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002968", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002968", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002968", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002968", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002968", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002968", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002969")
    void case_UTAPI_002969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002969",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002969", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002969", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002969", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002969", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002969", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002969", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002969", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002970")
    void case_UTAPI_002970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002970",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002970", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002970", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002970", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002970", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002970", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002970", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002970", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002971")
    void case_UTAPI_002971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002971",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002971", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002971", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002971", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002971", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002971", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002971", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002971", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002972")
    void case_UTAPI_002972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002972",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002972", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002972", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002972", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002972", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002972", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002972", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002972", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002973")
    void case_UTAPI_002973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002973",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002973", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002973", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002973", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002973", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002973", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002973", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002973", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002974")
    void case_UTAPI_002974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002974",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002974", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002974", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002974", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002974", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002974", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002974", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002974", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002975")
    void case_UTAPI_002975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002975",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002975", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002975", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002975", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002975", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002975", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002975", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002975", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002976")
    void case_UTAPI_002976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002976",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002976", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002976", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002976", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002976", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002976", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002976", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002976", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002977")
    void case_UTAPI_002977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002977",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002977", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002977", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002977", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002977", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002977", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002977", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002977", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002978")
    void case_UTAPI_002978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002978",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002978", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002978", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002978", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002978", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002978", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002978", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002978", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002979")
    void case_UTAPI_002979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002979",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002979", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002979", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002979", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002979", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002979", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002979", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002979", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002980")
    void case_UTAPI_002980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002980",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002980", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002980", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002980", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002980", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002980", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002980", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002980", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002981")
    void case_UTAPI_002981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002981",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002981", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002981", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002981", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002981", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002981", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002981", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002981", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002982")
    void case_UTAPI_002982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002982",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002982", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002982", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002982", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002982", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002982", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002982", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002982", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002983")
    void case_UTAPI_002983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002983",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002983", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002983", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002983", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002983", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002983", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002983", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002983", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002984")
    void case_UTAPI_002984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002984",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002984", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002984", "sql.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002984", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002984", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002984", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002984", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002984", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.contentSql", "SavedSql.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002985")
    void case_UTAPI_002985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002985",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002985", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002985", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002985", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002985", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002985", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002985", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002985", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002986")
    void case_UTAPI_002986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002986",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002986", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002986", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002986", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002986", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002986", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002986", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002986", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002987")
    void case_UTAPI_002987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002987",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002987", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002987", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002987", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002987", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002987", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002987", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002987", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002988")
    void case_UTAPI_002988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002988",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002988", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002988", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002988", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002988", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002988", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002988", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002988", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002989")
    void case_UTAPI_002989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002989",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002989", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002989", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002989", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002989", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002989", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002989", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002989", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002990")
    void case_UTAPI_002990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002990",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002990", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002990", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002990", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002990", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002990", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002990", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002990", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002991")
    void case_UTAPI_002991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002991",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002991", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002991", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002991", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002991", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002991", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002991", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002991", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002992")
    void case_UTAPI_002992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002992",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002992", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002992", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002992", "sql.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002992", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002992", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002992", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002992", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.createdTimestamp", "SavedSql.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002993")
    void case_UTAPI_002993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002993",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002993", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002993", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002993", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002993", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002993", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002993", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002993", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002994")
    void case_UTAPI_002994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002994",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002994", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002994", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002994", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002994", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002994", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002994", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002994", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002995")
    void case_UTAPI_002995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002995",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002995", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002995", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002995", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002995", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002995", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002995", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002995", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002996")
    void case_UTAPI_002996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002996",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002996", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002996", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002996", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002996", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002996", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002996", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002996", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002997")
    void case_UTAPI_002997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002997",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002997", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002997", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002997", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002997", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002997", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002997", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002997", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002998")
    void case_UTAPI_002998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002998",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002998", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002998", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002998", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002998", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002998", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002998", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002998", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002999")
    void case_UTAPI_002999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002999",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002999", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-002999", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002999", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002999", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002999", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002999", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002999", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-002999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003000")
    void case_UTAPI_003000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003000",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003000", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003000", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003000", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003000", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003000", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003000", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003000", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003001")
    void case_UTAPI_003001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003001",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003001", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003001", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003001", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003001", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003001", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003001", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003001", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003002")
    void case_UTAPI_003002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003002",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003002", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003002", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003002", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003002", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003002", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003002", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003002", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003003")
    void case_UTAPI_003003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003003",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003003", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003003", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003003", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003003", "sql.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003003", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003003", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003003", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.dbConnectionId", "SavedSql.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003004")
    void case_UTAPI_003004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003004",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003004", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003004", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003004", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003004", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003004", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003004", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003004", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003005")
    void case_UTAPI_003005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003005",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003005", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003005", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003005", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003005", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003005", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003005", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003005", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003006")
    void case_UTAPI_003006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003006",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003006", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003006", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003006", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003006", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003006", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003006", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003006", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003007")
    void case_UTAPI_003007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003007",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003007", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003007", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003007", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003007", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003007", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003007", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003007", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003008")
    void case_UTAPI_003008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003008",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003008", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003008", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003008", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003008", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003008", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003008", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003008", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003009")
    void case_UTAPI_003009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003009",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003009", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003009", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003009", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003009", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003009", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003009", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003009", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003010")
    void case_UTAPI_003010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003010",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003010", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003010", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003010", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003010", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003010", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003010", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003010", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003011")
    void case_UTAPI_003011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003011",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003011", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003011", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003011", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003011", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003011", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003011", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003011", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003012")
    void case_UTAPI_003012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003012",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003012", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003012", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003012", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003012", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003012", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003012", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003012", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003013")
    void case_UTAPI_003013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003013",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003013", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003013", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003013", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003013", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003013", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003013", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003013", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003014")
    void case_UTAPI_003014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003014",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003014", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003014", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003014", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003014", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003014", "sql.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003014", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003014", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sql.n", "SavedSql.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003015")
    void case_UTAPI_003015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003015",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003015", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003015", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003015", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003015", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003015", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003015", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003015", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003016")
    void case_UTAPI_003016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003016",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003016", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003016", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003016", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003016", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003016", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003016", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003016", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003017")
    void case_UTAPI_003017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003017",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003017", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003017", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003017", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003017", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003017", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003017", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003017", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003018")
    void case_UTAPI_003018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003018",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003018", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003018", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003018", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003018", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003018", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003018", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003018", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003019")
    void case_UTAPI_003019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003019",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003019", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003019", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003019", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003019", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003019", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003019", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003019", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003020")
    void case_UTAPI_003020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003020",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003020", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003020", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003020", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003020", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003020", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003020", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003020", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003021")
    void case_UTAPI_003021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003021",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003021", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003021", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003021", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003021", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003021", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003021", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003021", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003022")
    void case_UTAPI_003022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003022",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003022", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003022", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003022", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003022", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003022", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003022", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003022", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003023")
    void case_UTAPI_003023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003023",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003023", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003023", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003023", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003023", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003023", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003023", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003023", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003024")
    void case_UTAPI_003024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003024",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003024", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003024", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003024", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003024", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003024", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003024", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003024", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003025")
    void case_UTAPI_003025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003025",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003025", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003025", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003025", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003025", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003025", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003025", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003025", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003026")
    void case_UTAPI_003026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003026",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003026", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003026", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003026", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003026", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003026", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003026", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003026", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003027")
    void case_UTAPI_003027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003027",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003027", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003027", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003027", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003027", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003027", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003027", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003027", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003028")
    void case_UTAPI_003028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003028",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003028", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003028", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003028", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003028", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003028", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003028", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003028", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003029")
    void case_UTAPI_003029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003029",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003029", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003029", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003029", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003029", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003029", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003029", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003029", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003030")
    void case_UTAPI_003030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003030",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003030", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003030", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003030", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003030", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003030", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003030", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003030", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003031")
    void case_UTAPI_003031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003031",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003031", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003031", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003031", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003031", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003031", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003031", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003031", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003032")
    void case_UTAPI_003032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003032",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003032", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003032", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003032", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003032", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003032", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003032", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003032", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003033")
    void case_UTAPI_003033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003033",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003033", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003033", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003033", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003033", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003033", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003033", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003033", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003034")
    void case_UTAPI_003034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003034",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003034", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003034", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003034", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003034", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003034", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003034", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003034", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003035")
    void case_UTAPI_003035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003035",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003035", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003035", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003035", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003035", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003035", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003035", "sql.titleSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003035", "sql.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql.titleSql", "SavedSql.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:sql.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003036")
    void case_UTAPI_003036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003036",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003036", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003036", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003036", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003036", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003036", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003036", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003036", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003037")
    void case_UTAPI_003037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003037",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003037", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003037", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003037", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003037", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003037", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003037", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003037", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003038")
    void case_UTAPI_003038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003038",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003038", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003038", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003038", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003038", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003038", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003038", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003038", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003039")
    void case_UTAPI_003039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003039",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003039", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003039", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003039", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003039", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003039", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003039", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003039", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003040")
    void case_UTAPI_003040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003040",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003040", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003040", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003040", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003040", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003040", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003040", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003040", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003041")
    void case_UTAPI_003041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003041",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003041", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003041", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003041", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003041", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003041", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003041", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003041", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003042")
    void case_UTAPI_003042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003042",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003042", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003042", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003042", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003042", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003042", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003042", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003042", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003043")
    void case_UTAPI_003043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003043",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "save",
                "SavedSql",
                new ParamSpec[] {
                    new ParamSpec("sql", "SavedSql", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003043", "sql", "NORMAL", "OBJECT", "SavedSql"),
                    new DataRef("UTAPI-003043", "sql.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003043", "sql.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003043", "sql.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003043", "sql.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003043", "sql.titleSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003043", "sql.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-003043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::save::3::FIELD::1::SavedSql::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("sql.updatedTimestamp", "SavedSql.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for sql.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:sql.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

}

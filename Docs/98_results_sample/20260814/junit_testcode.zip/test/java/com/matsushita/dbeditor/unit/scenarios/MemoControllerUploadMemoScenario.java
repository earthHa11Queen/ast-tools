package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoController#uploadMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoControllerUploadMemoScenario {

    @Test
    @DisplayName("UTAPI-000950")
    void case_UTAPI_000950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000950",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000950", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000950", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000951")
    void case_UTAPI_000951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000951",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000951", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000951", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000952")
    void case_UTAPI_000952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000952",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000952", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000952", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000953")
    void case_UTAPI_000953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000953",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000953", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000953", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000954")
    void case_UTAPI_000954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000954",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000954", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000954", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000954")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000955")
    void case_UTAPI_000955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000955",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000955", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000955", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000955")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000956")
    void case_UTAPI_000956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000956",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000956", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000956", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000956")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000957")
    void case_UTAPI_000957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000957",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000957", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000957", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000957")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000958")
    void case_UTAPI_000958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000958",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000958", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000958", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000958")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000959")
    void case_UTAPI_000959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000959",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000959", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000959", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000959")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000960")
    void case_UTAPI_000960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000960",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000960", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000960", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000960")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000961")
    void case_UTAPI_000961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000961",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000961", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000961", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000961", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000961")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000962")
    void case_UTAPI_000962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000962",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000962", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000962", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000962", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000962")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000963")
    void case_UTAPI_000963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000963",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000963", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000963", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000963", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000963")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000964")
    void case_UTAPI_000964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000964",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000964", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000964", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000964", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000964")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000965")
    void case_UTAPI_000965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000965",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000965", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000965", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000965", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000965")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000966")
    void case_UTAPI_000966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000966",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000966", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000966", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000966", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000966")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000967")
    void case_UTAPI_000967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000967",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000967", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000967", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000967", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000967")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000968")
    void case_UTAPI_000968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000968",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000968", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000968", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000968", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000968")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000969")
    void case_UTAPI_000969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000969",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000969", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000969", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000969", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000969")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000970")
    void case_UTAPI_000970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000970",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000970", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000970", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000970", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000970")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000971")
    void case_UTAPI_000971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000971",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000971", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000971", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000971", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000971")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000972")
    void case_UTAPI_000972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000972",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000972", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000972", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000972", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000972")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000973")
    void case_UTAPI_000973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000973",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000973", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000973", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000973", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000973")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000974")
    void case_UTAPI_000974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000974",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000974", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000974", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000974", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000974")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000975")
    void case_UTAPI_000975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000975",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000975", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000975", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000975", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000975")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000976")
    void case_UTAPI_000976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000976",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000976", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000976", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000976", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000976")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000977")
    void case_UTAPI_000977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000977",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000977", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000977", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000977", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000977")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000978")
    void case_UTAPI_000978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000978",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000978", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000978", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000978", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000978")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000979")
    void case_UTAPI_000979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000979",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000979", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000979", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000979", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000979")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000980")
    void case_UTAPI_000980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000980",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000980", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000980", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000980", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000980")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000981")
    void case_UTAPI_000981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000981",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000981", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000981", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000981", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000981")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the uploaded content must be handed to the use case", "memoUseCase", "uploadMemo", "2", "text:COL_A")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000982")
    void case_UTAPI_000982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000982",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000982", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000982", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000982")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::3::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000983")
    void case_UTAPI_000983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000983",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "uploadMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000983", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000983", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000983")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::uploadMemo::3::ARG::3::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.uploadMemo")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.uploadMemo", "memoUseCase", "uploadMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.uploadMemo must carry the value generated for connectionId", "memoUseCase", "uploadMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.uploadMemo must carry the value generated for tableName", "memoUseCase", "uploadMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "memoUseCase", "uploadMemo", "0", "data:file")
                    .build()),
            new MemoControllerWrapper());
    }

}

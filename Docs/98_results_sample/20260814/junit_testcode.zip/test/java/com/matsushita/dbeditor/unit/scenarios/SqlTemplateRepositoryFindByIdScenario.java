package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateRepository#findById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateRepositoryFindByIdScenario {

    @Test
    @DisplayName("UTAPI-007212")
    void case_UTAPI_007212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007212",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007212", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007212")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007213")
    void case_UTAPI_007213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007213",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007213", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007213")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007214")
    void case_UTAPI_007214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007214",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007214", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007214")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007215")
    void case_UTAPI_007215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007215",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007215", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007215")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007216")
    void case_UTAPI_007216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007216",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007216", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007216")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007217")
    void case_UTAPI_007217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007217",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007217", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007217")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007218")
    void case_UTAPI_007218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007218",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007218", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007218")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007219")
    void case_UTAPI_007219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007219",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007219", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007219")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007220")
    void case_UTAPI_007220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007220",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007220", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007220")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007221")
    void case_UTAPI_007221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007221",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007221", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007221")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007222")
    void case_UTAPI_007222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007222",
                "com.matsushita.dbeditor.domain.repository.SqlTemplateRepository",
                "findById",
                "Optional<SqlTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007222", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007222")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/SqlTemplateRepository.java::SqlTemplateRepository::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateRepositoryWrapper());
    }

}

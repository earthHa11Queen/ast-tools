package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoResponse#empty.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoResponseEmptyScenario {

    @Test
    @DisplayName("UTAPI-010253")
    void case_UTAPI_010253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010253",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010253", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010253", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010253")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010254")
    void case_UTAPI_010254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010254",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010254", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010254", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010254")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010255")
    void case_UTAPI_010255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010255",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010255", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010255", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010255")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010256")
    void case_UTAPI_010256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010256",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010256", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010256", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010256")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010257")
    void case_UTAPI_010257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010257",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010257", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010257", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010257")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010258")
    void case_UTAPI_010258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010258",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010258", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010258", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010258")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010259")
    void case_UTAPI_010259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010259",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010259", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010259", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010259")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010260")
    void case_UTAPI_010260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010260",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010260", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010260", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010260")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010261")
    void case_UTAPI_010261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010261",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010261", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010261", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010261")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010262")
    void case_UTAPI_010262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010262",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010262", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010262", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010262")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010263")
    void case_UTAPI_010263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010263",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010263", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010263", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010263")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010264")
    void case_UTAPI_010264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010264",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010264", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010264", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010264")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010265")
    void case_UTAPI_010265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010265",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010265", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010265", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010265")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010266")
    void case_UTAPI_010266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010266",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010266", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010266", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010266")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010267")
    void case_UTAPI_010267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010267",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010267", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010267", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010267")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010268")
    void case_UTAPI_010268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010268",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010268", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010268", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010268")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010269")
    void case_UTAPI_010269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010269",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010269", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010269", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010269")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010270")
    void case_UTAPI_010270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010270",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010270", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010270", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010270")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010271")
    void case_UTAPI_010271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010271",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010271", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010271", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010271")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010272")
    void case_UTAPI_010272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010272",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010272", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010272", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010272")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010273")
    void case_UTAPI_010273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010273",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010273", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010273", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010273")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010274")
    void case_UTAPI_010274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010274",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010274", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010274", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010274")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010275")
    void case_UTAPI_010275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010275",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010275", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010275", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010275")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010276")
    void case_UTAPI_010276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010276",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010276", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010276", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010276")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010277")
    void case_UTAPI_010277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010277",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010277", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010277", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010277")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010278")
    void case_UTAPI_010278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010278",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010278", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010278", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010278")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010279")
    void case_UTAPI_010279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010279",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010279", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010279", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010279")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010280")
    void case_UTAPI_010280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010280",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010280", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010280", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010280")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010281")
    void case_UTAPI_010281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010281",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010281", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010281", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010281")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010282")
    void case_UTAPI_010282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010282",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010282", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010282", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010282")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010283")
    void case_UTAPI_010283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010283",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010283", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010283", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010283")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010284")
    void case_UTAPI_010284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010284",
                "com.matsushita.dbeditor.dto.outdto.MemoResponse",
                "empty",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010284", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010284", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010284")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/MemoResponse.java::MemoResponse::empty::2::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the empty response")
                    .expected("the supplied identifiers are carried onto the response unchanged")
                    .failure("an identifier is dropped or swapped between fields")
                    .assertion("assertNotNull and assertEquals per carried field")
                    .check(CheckType.RETURN_NOT_NULL, "the factory must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getConnectionId must carry the supplied connectionId", "getConnectionId", "data:connectionId")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry the supplied tableName", "getTableName", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "the factory must complete for this input condition")
                    .build()),
            new MemoResponseWrapper());
    }

}

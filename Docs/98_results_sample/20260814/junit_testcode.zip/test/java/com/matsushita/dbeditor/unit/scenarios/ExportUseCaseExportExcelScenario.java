package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportUseCase#exportExcel.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportUseCaseExportExcelScenario {

    @Test
    @DisplayName("UTAPI-012147")
    void case_UTAPI_012147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012147",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012147", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012147", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012147")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012148")
    void case_UTAPI_012148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012148",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012148", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012148", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012148")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012149")
    void case_UTAPI_012149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012149",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012149", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012149", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012149")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012150")
    void case_UTAPI_012150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012150",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012150", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012150", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012150")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012151")
    void case_UTAPI_012151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012151",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012151", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012151", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012151")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012152")
    void case_UTAPI_012152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012152",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012152", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012152", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012152")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012153")
    void case_UTAPI_012153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012153",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012153", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012153", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012153")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012154")
    void case_UTAPI_012154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012154",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012154", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012154", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012154")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012155")
    void case_UTAPI_012155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012155",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012155", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012155", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012155")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012156")
    void case_UTAPI_012156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012156",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012156", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012156", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012156", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012156")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012157")
    void case_UTAPI_012157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012157",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012157", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012157", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012157", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012157")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012158")
    void case_UTAPI_012158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012158",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012158", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012158", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012158", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012158")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012159")
    void case_UTAPI_012159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012159",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012159", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012159", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012159", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012159")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012160")
    void case_UTAPI_012160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012160",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012160", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012160", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012160", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012160")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012161")
    void case_UTAPI_012161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012161",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012161", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012161", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012161", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012161")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012162")
    void case_UTAPI_012162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012162",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012162", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012162", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012162", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012162")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012163")
    void case_UTAPI_012163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012163",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012163", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012163", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012163", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012163")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012164")
    void case_UTAPI_012164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012164",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012164", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012164", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012164", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012164")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012165")
    void case_UTAPI_012165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012165",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012165", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012165", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012165", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012165")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012166")
    void case_UTAPI_012166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012166",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012166", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012166", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012166", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012166")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012167")
    void case_UTAPI_012167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012167",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012167", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012167", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012167", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012167")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012168")
    void case_UTAPI_012168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012168",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012168", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012168", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012168", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012168")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012169")
    void case_UTAPI_012169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012169",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012169", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012169", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012169", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012169")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012170")
    void case_UTAPI_012170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012170",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012170", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012170", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012170", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012170")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012171")
    void case_UTAPI_012171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012171",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012171", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012171", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012171", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012171")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012172")
    void case_UTAPI_012172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012172",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012172", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012172", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012172", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012172")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012173")
    void case_UTAPI_012173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012173",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012173", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012173", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012173", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012173")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012174")
    void case_UTAPI_012174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012174",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012174", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012174", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012174", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012174")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012175")
    void case_UTAPI_012175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012175",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012175", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012175", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012175", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012175")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012176")
    void case_UTAPI_012176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012176",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012176", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012176", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012176", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012176")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012177")
    void case_UTAPI_012177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012177",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012177", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012177", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012177", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012177")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012178")
    void case_UTAPI_012178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012178",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012178", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012178", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012178", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012178")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012179")
    void case_UTAPI_012179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012179",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012179", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012179", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012179")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012180")
    void case_UTAPI_012180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012180",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012180", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012180", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012180")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012181")
    void case_UTAPI_012181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012181",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012181", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012181", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012181")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012182")
    void case_UTAPI_012182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012182",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012182", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012182", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012182")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012183")
    void case_UTAPI_012183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012183",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012183", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012183", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012183")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012184")
    void case_UTAPI_012184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012184",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012184", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012184", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012184")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012185")
    void case_UTAPI_012185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012185",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012185", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012185", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012185")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012186")
    void case_UTAPI_012186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012186",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012186", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012186", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012186")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012187")
    void case_UTAPI_012187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012187",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012187", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012187", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012187")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012188")
    void case_UTAPI_012188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012188",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012188", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012188", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012188")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012189")
    void case_UTAPI_012189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012189",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012189", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012189", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012189")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012190")
    void case_UTAPI_012190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012190",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012190", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012190", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012190")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012191")
    void case_UTAPI_012191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012191",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012191", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012191", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012191")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012192")
    void case_UTAPI_012192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012192",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012192", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012192", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012192")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012193")
    void case_UTAPI_012193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012193",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012193", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012193", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012193")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012194")
    void case_UTAPI_012194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012194",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012194", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012194", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012194")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012195")
    void case_UTAPI_012195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012195",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012195", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012195", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012195")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012196")
    void case_UTAPI_012196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012196",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012196", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012196", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012196")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012197")
    void case_UTAPI_012197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012197",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012197", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012197", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012197")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012198")
    void case_UTAPI_012198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012198",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012198", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012198", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012198")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012199")
    void case_UTAPI_012199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012199",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportExcel",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012199", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012199", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012199")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportExcel::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictRepository#createBackup.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictRepositoryCreateBackupScenario {

    @Test
    @DisplayName("UTAPI-007649")
    void case_UTAPI_007649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007649",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007649", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007649", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007649", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007649")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007650")
    void case_UTAPI_007650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007650",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007650", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007650", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007650")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007651")
    void case_UTAPI_007651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007651",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007651", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007651", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007651")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007652")
    void case_UTAPI_007652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007652",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007652", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007652", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007652")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007653")
    void case_UTAPI_007653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007653",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007653", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007653", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007653")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007654")
    void case_UTAPI_007654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007654",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007654", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007654")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007655")
    void case_UTAPI_007655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007655",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007655", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007655", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007655")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007656")
    void case_UTAPI_007656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007656",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007656", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007656", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007656")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007657")
    void case_UTAPI_007657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007657",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007657", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007657", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007657")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007658")
    void case_UTAPI_007658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007658",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007658", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007658", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007658")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007659")
    void case_UTAPI_007659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007659",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007659", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007659", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007659")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007660")
    void case_UTAPI_007660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007660",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007660", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007660", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007660")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007661")
    void case_UTAPI_007661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007661",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007661", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007661", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007661", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007661")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007662")
    void case_UTAPI_007662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007662",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007662", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007662", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007662", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007662")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007663")
    void case_UTAPI_007663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007663",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007663", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007663", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007663", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007663")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007664")
    void case_UTAPI_007664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007664",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007664", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007664", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007664", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007664")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007665")
    void case_UTAPI_007665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007665",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007665", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007665", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007665", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007665")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007666")
    void case_UTAPI_007666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007666",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007666", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007666", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007666", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007666")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007667")
    void case_UTAPI_007667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007667",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007667", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007667", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007667", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007667")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007668")
    void case_UTAPI_007668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007668",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007668", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007668", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007668", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007668")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007669")
    void case_UTAPI_007669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007669",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007669", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007669", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007669", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007669")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007670")
    void case_UTAPI_007670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007670",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007670", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007670", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007670", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007670")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007671")
    void case_UTAPI_007671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007671",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007671", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007671", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007671", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007671")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007672")
    void case_UTAPI_007672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007672",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007672", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007672", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007672", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007672")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007673")
    void case_UTAPI_007673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007673",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007673", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007673", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007673", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007673")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007674")
    void case_UTAPI_007674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007674",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007674", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007674", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007674")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007675")
    void case_UTAPI_007675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007675",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007675", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007675", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007675")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007676")
    void case_UTAPI_007676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007676",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007676", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007676", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007676")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007677")
    void case_UTAPI_007677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007677",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007677", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007677", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007677")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007678")
    void case_UTAPI_007678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007678",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007678", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007678", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007678")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007679")
    void case_UTAPI_007679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007679",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007679", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007679")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007680")
    void case_UTAPI_007680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007680",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007680", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007680")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007681")
    void case_UTAPI_007681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007681",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007681", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007681", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007681")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007682")
    void case_UTAPI_007682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007682",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007682", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007682", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007682")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007683")
    void case_UTAPI_007683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007683",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007683", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007683", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007683")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007684")
    void case_UTAPI_007684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007684",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007684", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007684", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007684", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007684")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007685")
    void case_UTAPI_007685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007685",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007685", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007685", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007685", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007685")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007686")
    void case_UTAPI_007686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007686",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007686", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007686", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007686", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007686")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007687")
    void case_UTAPI_007687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007687",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007687", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007687", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007687", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007687", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007687", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007687")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007688")
    void case_UTAPI_007688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007688",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007688", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007688", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007688", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007688", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007688", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007688")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007689")
    void case_UTAPI_007689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007689",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007689", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007689", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007689", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007689", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007689", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007689")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007690")
    void case_UTAPI_007690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007690",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007690", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007690", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007690", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007690", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007690", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007690")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007691")
    void case_UTAPI_007691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007691",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007691", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007691", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007691", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007691", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007691", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007691")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007692")
    void case_UTAPI_007692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007692",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007692", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007692", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007692", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007692", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007692", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007692")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007693")
    void case_UTAPI_007693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007693",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007693", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007693", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007693", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007693", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007693", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007693")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007694")
    void case_UTAPI_007694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007694",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007694", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007694", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007694", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007694", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007694", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007694")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007695")
    void case_UTAPI_007695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007695",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007695", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007695", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007695", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007695", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007695", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007695", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007695")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007696")
    void case_UTAPI_007696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007696",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007696", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007696", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007696", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007696", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007696", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007696", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007696")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007697")
    void case_UTAPI_007697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007697",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007697", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007697", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007697", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007697", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007697", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007697", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007697")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007698")
    void case_UTAPI_007698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007698",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007698", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007698", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007698", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007698", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007698", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007698")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007699")
    void case_UTAPI_007699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007699",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007699", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007699", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007699", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007699", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007699", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007699")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007700")
    void case_UTAPI_007700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007700",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007700", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007700", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007700", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007700", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007700", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007700", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007700")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007701")
    void case_UTAPI_007701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007701",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007701", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007701", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007701", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007701", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007701", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007701", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007701")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007702")
    void case_UTAPI_007702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007702",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007702", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007702", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007702", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007702", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007702", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007702", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007702")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007703")
    void case_UTAPI_007703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007703",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007703", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007703", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007703", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007703", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007703", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007703", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007703")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007704")
    void case_UTAPI_007704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007704",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007704", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007704", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007704", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007704", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007704", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007704", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007704")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007705")
    void case_UTAPI_007705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007705",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007705", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007705", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007705", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007705", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007705", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007705")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007706")
    void case_UTAPI_007706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007706",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007706", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007706", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007706", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007706", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007706", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007706")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007707")
    void case_UTAPI_007707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007707",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007707", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007707", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007707", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007707", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007707", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007707")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007708")
    void case_UTAPI_007708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007708",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007708", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007708", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007708", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007708", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007708", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007708")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007709")
    void case_UTAPI_007709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007709",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007709", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007709", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007709", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007709", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007709", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007709")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007710")
    void case_UTAPI_007710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007710",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007710", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007710", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007710", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007710", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007710", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007710")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007711")
    void case_UTAPI_007711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007711",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007711", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007711", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007711", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007711", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007711", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007711")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007712")
    void case_UTAPI_007712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007712",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007712", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007712", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007712", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007712", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007712", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007712")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007713")
    void case_UTAPI_007713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007713",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007713", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007713", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007713", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007713", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007713", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007713")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007714")
    void case_UTAPI_007714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007714",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007714", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007714", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007714", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007714", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007714", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007714")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007715")
    void case_UTAPI_007715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007715",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007715", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007715", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007715", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007715", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007715", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007715", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007715")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007716")
    void case_UTAPI_007716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007716",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007716", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007716", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007716", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007716", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007716", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007716", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007716")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007717")
    void case_UTAPI_007717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007717",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007717", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007717", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007717", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007717", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007717", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007717", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007717")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007718")
    void case_UTAPI_007718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007718",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007718", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007718", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007718", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007718", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007718", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007718", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007718")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007719")
    void case_UTAPI_007719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007719",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007719", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007719", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007719", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007719", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007719", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007719", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007719")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007720")
    void case_UTAPI_007720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007720",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007720", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007720", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007720", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007720", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007720", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007720", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007720", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007720")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007721")
    void case_UTAPI_007721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007721",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007721", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007721", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007721", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007721", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007721", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007721", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007721", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007721")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007722")
    void case_UTAPI_007722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007722",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007722", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007722", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007722", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007722", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007722", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007722", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007722", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007722")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007723")
    void case_UTAPI_007723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007723",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007723", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007723", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007723", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007723", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007723", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007723", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007723", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007723")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007724")
    void case_UTAPI_007724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007724",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007724", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007724", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007724", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007724", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007724", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007724", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007724", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007724")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007725")
    void case_UTAPI_007725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007725",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007725", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007725", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007725", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007725", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007725", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007725", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007725")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007726")
    void case_UTAPI_007726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007726",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007726", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007726", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007726", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007726", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007726", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007726", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007726", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007726")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007727")
    void case_UTAPI_007727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007727",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007727", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007727", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007727", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007727", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007727", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007727", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007727")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007728")
    void case_UTAPI_007728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007728",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007728", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007728", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007728", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007728", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007728", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007728", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007728")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007729")
    void case_UTAPI_007729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007729",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007729", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007729", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007729", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007729", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007729", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007729", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007729")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007730")
    void case_UTAPI_007730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007730",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007730", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007730", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007730", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007730", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007730", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007730", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007730")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007731")
    void case_UTAPI_007731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007731",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007731", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007731", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007731", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007731", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007731", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007731", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007731")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007732")
    void case_UTAPI_007732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007732",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007732", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007732", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007732", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007732", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007732", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007732", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007732")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007733")
    void case_UTAPI_007733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007733",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007733", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007733", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007733", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007733", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007733", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007733")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007734")
    void case_UTAPI_007734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007734",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007734", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007734", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007734", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007734", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007734", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007734")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007735")
    void case_UTAPI_007735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007735",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007735", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007735", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007735", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007735", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007735", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007735")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007736")
    void case_UTAPI_007736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007736",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007736", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007736", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007736", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007736", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007736", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007736")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007737")
    void case_UTAPI_007737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007737",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007737", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007737", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007737", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007737", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007737", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007737")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007738")
    void case_UTAPI_007738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007738",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007738", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007738", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007738", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007738", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007738", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007738")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007739")
    void case_UTAPI_007739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007739",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007739", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007739", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007739", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007739")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007740")
    void case_UTAPI_007740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007740",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007740", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007740", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007740", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007740")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007741")
    void case_UTAPI_007741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007741",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007741", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007741", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007741", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007741")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007742")
    void case_UTAPI_007742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007742",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007742", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007742", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007742", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007742")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007743")
    void case_UTAPI_007743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007743",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007743", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007743", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007743", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007743")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007744")
    void case_UTAPI_007744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007744",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007744", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007744", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007744", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007744")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007745")
    void case_UTAPI_007745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007745",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007745", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007745", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007745", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007745")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007746")
    void case_UTAPI_007746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007746",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007746", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007746", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007746", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007746")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007747")
    void case_UTAPI_007747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007747",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007747", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007747", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007747", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007747")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007748")
    void case_UTAPI_007748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007748",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007748", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007748", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007748", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007748")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007749")
    void case_UTAPI_007749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007749",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007749", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007749", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007749", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007749")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007750")
    void case_UTAPI_007750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007750",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007750", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007750", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007750", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007750", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007750", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007750")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007751")
    void case_UTAPI_007751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007751",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007751", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007751", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007751", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007751", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007751", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007751")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007752")
    void case_UTAPI_007752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007752",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007752", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007752", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007752", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007752", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007752", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007752")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007753")
    void case_UTAPI_007753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007753",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007753", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007753", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007753", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007753", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007753", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007753")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007754")
    void case_UTAPI_007754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007754",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007754", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007754", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007754", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007754", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007754", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007754")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007755")
    void case_UTAPI_007755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007755",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007755", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007755", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007755", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007755", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007755", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007755")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007756")
    void case_UTAPI_007756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007756",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007756", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007756", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007756", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007756", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007756", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007756")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007757")
    void case_UTAPI_007757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007757",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007757", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007757", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007757", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007757", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007757", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007757")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007758")
    void case_UTAPI_007758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007758",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007758", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007758", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007758", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007758", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007758", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007758", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007758")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007759")
    void case_UTAPI_007759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007759",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007759", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007759", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007759", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007759", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007759", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007759", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007759")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007760")
    void case_UTAPI_007760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007760",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007760", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007760", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007760", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007760", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007760")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007761")
    void case_UTAPI_007761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007761",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007761", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007761", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007761", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007761")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007762")
    void case_UTAPI_007762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007762",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007762", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007762", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007762", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007762")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007763")
    void case_UTAPI_007763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007763",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007763", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007763", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007763", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007763")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007764")
    void case_UTAPI_007764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007764",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007764", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007764", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007764", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007764")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007765")
    void case_UTAPI_007765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007765",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007765", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007765", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007765", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007765", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007765")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007766")
    void case_UTAPI_007766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007766",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007766", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007766", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007766", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007766", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007766")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007767")
    void case_UTAPI_007767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007767",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007767", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007767", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007767", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007767", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007767")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007768")
    void case_UTAPI_007768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007768",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007768", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007768", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007768", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007768", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007768")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007769")
    void case_UTAPI_007769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007769",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007769", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007769", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007769", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007769", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007769")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007770")
    void case_UTAPI_007770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007770",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007770", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007770", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007770", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007770", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007770")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007771")
    void case_UTAPI_007771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007771",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007771", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007771", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007771")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007772")
    void case_UTAPI_007772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007772",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007772", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007772", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007772")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007773")
    void case_UTAPI_007773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007773",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007773", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007773", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007773")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007774")
    void case_UTAPI_007774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007774",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007774", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007774", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007774")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007775")
    void case_UTAPI_007775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007775",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007775", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007775", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007775")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007776")
    void case_UTAPI_007776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007776",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007776", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007776", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007776", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007776", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007776")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007777")
    void case_UTAPI_007777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007777",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007777", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007777", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007777", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007777", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007777")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007778")
    void case_UTAPI_007778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007778",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007778", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007778", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007778", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007778", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007778")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007779")
    void case_UTAPI_007779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007779",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007779", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007779", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007779", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007779", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007779")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007780")
    void case_UTAPI_007780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007780",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007780", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007780", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007780", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007780", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007780")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007781")
    void case_UTAPI_007781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007781",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007781", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007781", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007781", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007781", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007781")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007782")
    void case_UTAPI_007782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007782",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007782", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007782", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007782", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007782", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007782", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007782")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007783")
    void case_UTAPI_007783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007783",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007783", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007783", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007783", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007783", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007783", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007783")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007784")
    void case_UTAPI_007784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007784",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007784", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007784", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007784", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007784", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007784", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007784")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007785")
    void case_UTAPI_007785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007785",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007785", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007785", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007785", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007785", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007785", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007785")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007786")
    void case_UTAPI_007786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007786",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007786", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007786", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007786", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007786", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007786", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007786")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007787")
    void case_UTAPI_007787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007787",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007787", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007787", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007787", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007787", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007787", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007787")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007788")
    void case_UTAPI_007788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007788",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007788", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007788", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007788", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007788", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007788", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007788")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007789")
    void case_UTAPI_007789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007789",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007789", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007789", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007789", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007789", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007789")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007790")
    void case_UTAPI_007790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007790",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007790", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007790", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007790", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007790", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007790")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007791")
    void case_UTAPI_007791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007791",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007791", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007791", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007791", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007791", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007791")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007792")
    void case_UTAPI_007792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007792",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007792", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007792", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007792", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007792", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007792")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007793")
    void case_UTAPI_007793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007793",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007793", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007793", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007793", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007793", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007793", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007793")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007794")
    void case_UTAPI_007794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007794",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007794", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007794", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007794", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007794", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007794", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007794")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007795")
    void case_UTAPI_007795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007795",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007795", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007795", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007795", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007795", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007795", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007795")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007796")
    void case_UTAPI_007796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007796",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007796", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007796", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007796", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007796", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007796", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007796")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007797")
    void case_UTAPI_007797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007797",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007797", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007797", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007797", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007797", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007797", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007797")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007798")
    void case_UTAPI_007798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007798",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007798", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007798", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007798", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007798")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007799")
    void case_UTAPI_007799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007799",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007799", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007799", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007799", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007799")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007800")
    void case_UTAPI_007800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007800",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007800", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007800", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007800", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007800")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007801")
    void case_UTAPI_007801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007801",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007801", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007801", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007801", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007801")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007802")
    void case_UTAPI_007802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007802",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007802", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007802", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007802", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007802")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007803")
    void case_UTAPI_007803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007803",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007803", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007803", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007803", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007803")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007804")
    void case_UTAPI_007804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007804",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007804", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007804", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007804")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007805")
    void case_UTAPI_007805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007805",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007805", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007805", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007805")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007806")
    void case_UTAPI_007806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007806",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007806", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007806", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007806")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007807")
    void case_UTAPI_007807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007807",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007807", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007807", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007807")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007808")
    void case_UTAPI_007808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007808",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007808", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007808", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007808")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007809")
    void case_UTAPI_007809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007809",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007809", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007809", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007809", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007809")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007810")
    void case_UTAPI_007810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007810",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007810", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007810", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007810", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007810")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007811")
    void case_UTAPI_007811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007811",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007811", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007811", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007811", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007811")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007812")
    void case_UTAPI_007812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007812",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007812", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007812", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007812")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007813")
    void case_UTAPI_007813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007813",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007813", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007813", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007813")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007814")
    void case_UTAPI_007814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007814",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007814", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007814", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007814")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007815")
    void case_UTAPI_007815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007815",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007815", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007815", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007815")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007816")
    void case_UTAPI_007816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007816",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007816", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007816", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007816", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007816")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007817")
    void case_UTAPI_007817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007817",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007817", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007817", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007817", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007817")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007818")
    void case_UTAPI_007818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007818",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007818", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007818", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007818", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007818")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007819")
    void case_UTAPI_007819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007819",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007819", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007819", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007819", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007819")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007820")
    void case_UTAPI_007820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007820",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007820", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007820", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007820", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007820")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007821")
    void case_UTAPI_007821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007821",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007821", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007821", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007821", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007821")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007822")
    void case_UTAPI_007822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007822",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007822", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007822", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007822", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007822")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007823")
    void case_UTAPI_007823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007823",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007823", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007823", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007823", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007823")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007824")
    void case_UTAPI_007824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007824",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007824", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007824", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007824", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007824")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007825")
    void case_UTAPI_007825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007825",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007825", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007825", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007825", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007825")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007826")
    void case_UTAPI_007826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007826",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007826", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007826", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007826", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007826")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007827")
    void case_UTAPI_007827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007827",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007827", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007827", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007827")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007828")
    void case_UTAPI_007828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007828",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007828", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007828", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007828")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007829")
    void case_UTAPI_007829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007829",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007829", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007829", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007829", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007829")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007830")
    void case_UTAPI_007830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007830",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007830", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007830", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007830", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007830")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007831")
    void case_UTAPI_007831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007831",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007831", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007831", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007831", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007831")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

}

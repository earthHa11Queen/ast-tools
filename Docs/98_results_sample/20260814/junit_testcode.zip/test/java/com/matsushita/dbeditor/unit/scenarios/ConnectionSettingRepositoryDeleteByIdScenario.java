package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingRepository#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingRepositoryDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-006023")
    void case_UTAPI_006023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006023",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006023", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006023")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006024")
    void case_UTAPI_006024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006024",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006024", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006024")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006025")
    void case_UTAPI_006025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006025",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006025", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006025")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006026")
    void case_UTAPI_006026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006026",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006026", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006026")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006027")
    void case_UTAPI_006027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006027",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006027", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006027")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006028")
    void case_UTAPI_006028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006028",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006028", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006028")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006029")
    void case_UTAPI_006029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006029",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006029", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006029")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006030")
    void case_UTAPI_006030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006030",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006030", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006030")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006031")
    void case_UTAPI_006031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006031",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006031", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006031")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006032")
    void case_UTAPI_006032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006032",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006032", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006032")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006033")
    void case_UTAPI_006033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006033",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006033", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-006033")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

}

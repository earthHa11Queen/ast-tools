package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#listSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseListSqlScenario {

    @Test
    @DisplayName("UTAPI-012904")
    void case_UTAPI_012904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012904",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012904", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012904")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012905")
    void case_UTAPI_012905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012905",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012905", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012905")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012906")
    void case_UTAPI_012906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012906",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012906", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012906")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012907")
    void case_UTAPI_012907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012907",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012907", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012907")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012908")
    void case_UTAPI_012908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012908",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012908", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012908")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012909")
    void case_UTAPI_012909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012909",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012909", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012909")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012910")
    void case_UTAPI_012910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012910",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012910", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012910")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012911")
    void case_UTAPI_012911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012911",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012911", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012911")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012912")
    void case_UTAPI_012912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012912",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012912", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012912")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012913")
    void case_UTAPI_012913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012913",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012913", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012913")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012914")
    void case_UTAPI_012914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012914",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "listSql",
                "List<SqlResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012914", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012914")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::listSql::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findAllByConnectionId")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findAllByConnectionId", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findAllByConnectionId must carry the value generated for connectionId", "savedSqlRepository", "findAllByConnectionId", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.RETURN_COLLECTION_SIZE_MATCHES_STUB, "the result must hold exactly what savedSqlRepository.findAllByConnectionId returned", "savedSqlRepository", "findAllByConnectionId")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

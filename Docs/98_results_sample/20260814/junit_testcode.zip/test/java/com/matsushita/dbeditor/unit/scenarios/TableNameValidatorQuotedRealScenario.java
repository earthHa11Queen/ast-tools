package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#quotedReal.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorQuotedRealScenario {

    @Test
    @DisplayName("UTAPI-010999")
    void case_UTAPI_010999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010999",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010999", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010999", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010999")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedReal for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011000")
    void case_UTAPI_011000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011000",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011000", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011000", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011000")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedReal for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011001")
    void case_UTAPI_011001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011001",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011001", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011001", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011001")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011002")
    void case_UTAPI_011002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011002",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011002", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011002", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011002")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011003")
    void case_UTAPI_011003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011003",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011003", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011003", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011003")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011004")
    void case_UTAPI_011004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011004",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011004", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011004", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011004")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011005")
    void case_UTAPI_011005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011005",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011005", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011005", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011005")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011006")
    void case_UTAPI_011006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011006",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011006", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011006", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011006")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011007")
    void case_UTAPI_011007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011007",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011007", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011007", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011007")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011008")
    void case_UTAPI_011008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011008",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011008", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011008", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011008")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011009")
    void case_UTAPI_011009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011009",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011009", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011009", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011009")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011010")
    void case_UTAPI_011010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011010",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011010", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011010", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011010")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011011")
    void case_UTAPI_011011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011011",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011011", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011011", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011011")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011012")
    void case_UTAPI_011012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011012",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011012", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011012", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011012")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011013")
    void case_UTAPI_011013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011013",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011013", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011013", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011013")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011014")
    void case_UTAPI_011014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011014",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011014", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011014", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011014")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011015")
    void case_UTAPI_011015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011015",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011015", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011015", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011015")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011016")
    void case_UTAPI_011016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011016",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011016", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011016")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011017")
    void case_UTAPI_011017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011017",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011017", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011017")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011018")
    void case_UTAPI_011018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011018",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011018", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011018")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011019")
    void case_UTAPI_011019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011019",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011019", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011019")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::1::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011020")
    void case_UTAPI_011020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011020",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011020", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011020")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedReal for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011021")
    void case_UTAPI_011021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011021",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011021", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011021")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedReal for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011022")
    void case_UTAPI_011022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011022",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011022", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011022")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011023")
    void case_UTAPI_011023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011023",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011023", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011023", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011023")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011024")
    void case_UTAPI_011024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011024",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011024", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011024", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011024")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011025")
    void case_UTAPI_011025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011025",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011025", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011025", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011025")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011026")
    void case_UTAPI_011026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011026",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011026", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011026", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011026")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011027")
    void case_UTAPI_011027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011027",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011027", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011027", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011027")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011028")
    void case_UTAPI_011028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011028",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011028", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011028")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011029")
    void case_UTAPI_011029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011029",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011029", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011029")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011030")
    void case_UTAPI_011030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011030",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011030", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011030")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011031")
    void case_UTAPI_011031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011031",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011031", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011031")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011032")
    void case_UTAPI_011032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011032",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011032", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011032")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011033")
    void case_UTAPI_011033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011033",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011033", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011033")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011034")
    void case_UTAPI_011034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011034",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011034", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011034")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011035")
    void case_UTAPI_011035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011035",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011035", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011035")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011036")
    void case_UTAPI_011036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011036",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011036", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011036")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011037")
    void case_UTAPI_011037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011037",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011037", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011037")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011038")
    void case_UTAPI_011038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011038",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011038", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011038")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011039")
    void case_UTAPI_011039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011039",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011039", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011039", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011039")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011040")
    void case_UTAPI_011040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011040",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedReal",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011040", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011040", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011040")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedReal::6::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedReal, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateGateway#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateGatewaySaveScenario {

    @Test
    @DisplayName("UTAPI-003067")
    void case_UTAPI_003067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003067",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003067", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003067", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003067", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003067", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003067", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "1:length_null", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003068")
    void case_UTAPI_003068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003068",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003068", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003068", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003068", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003068", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003068", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003069")
    void case_UTAPI_003069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003069",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003069", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003069", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003069", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003069", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003069", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "3:length_min", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003070")
    void case_UTAPI_003070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003070",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003070", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003070", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003070", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003070", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003070", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003071")
    void case_UTAPI_003071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003071",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003071", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003071", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003071", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003071", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003071", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "5:length_max", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003072")
    void case_UTAPI_003072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003072",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003072", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003072", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003072", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003072", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003072", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003073")
    void case_UTAPI_003073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003073",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003073", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003073", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003073", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003073", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003073", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003074")
    void case_UTAPI_003074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003074",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003074", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003074", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003074", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003074", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003074", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003075")
    void case_UTAPI_003075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003075",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003075", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003075", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003075", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003075", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003075", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003076")
    void case_UTAPI_003076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003076",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003076", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003076", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003076", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003076", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003076", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003077")
    void case_UTAPI_003077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003077",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003077", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003077", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003077", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003077", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003077", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003078")
    void case_UTAPI_003078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003078",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003078", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003078", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003078", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003078", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003078", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003079")
    void case_UTAPI_003079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003079",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003079", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003079", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003079", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003079", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003079", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "56:space")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003080")
    void case_UTAPI_003080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003080",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003080", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003080", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003080", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003080", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003080", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003081")
    void case_UTAPI_003081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003081",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003081", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003081", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003081", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003081", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003081", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003082")
    void case_UTAPI_003082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003082",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003082", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003082", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003082", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003082", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003082", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "59:tab")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003083")
    void case_UTAPI_003083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003083",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003083", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003083", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003083", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003083", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003083", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003084")
    void case_UTAPI_003084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003084",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003084", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003084", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003084", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003084", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003084", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003085")
    void case_UTAPI_003085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003085",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003085", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003085", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003085", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003085", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003085", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003086")
    void case_UTAPI_003086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003086",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003086", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003086", "template.contentSql", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003086", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003086", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003086", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::contentSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.contentSql", "SqlTemplate.contentSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003087")
    void case_UTAPI_003087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003087",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003087", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003087", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003087", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003087", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003087", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003088")
    void case_UTAPI_003088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003088",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003088", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003088", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003088", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003088", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003088", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003089")
    void case_UTAPI_003089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003089",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003089", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003089", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003089", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003089", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003089", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003090")
    void case_UTAPI_003090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003090",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003090", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003090", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003090", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003090", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003090", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003091")
    void case_UTAPI_003091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003091",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003091", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003091", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003091", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003091", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003091", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003092")
    void case_UTAPI_003092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003092",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003092", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003092", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003092", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003092", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003092", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003093")
    void case_UTAPI_003093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003093",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003093", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003093", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003093", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003093", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003093", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003094")
    void case_UTAPI_003094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003094",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003094", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003094", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003094", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003094", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003094", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("template.createdTimestamp", "SqlTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003095")
    void case_UTAPI_003095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003095",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003095", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003095", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003095", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003095", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003095", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003096")
    void case_UTAPI_003096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003096",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003096", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003096", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003096", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003096", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003096", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003097")
    void case_UTAPI_003097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003097",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003097", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003097", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003097", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003097", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003097", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003098")
    void case_UTAPI_003098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003098",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003098", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003098", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003098", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003098", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003098", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003099")
    void case_UTAPI_003099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003099",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003099", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003099", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003099", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003099", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003099", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003100")
    void case_UTAPI_003100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003100",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003100", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003100", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003100", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003100", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003100", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003101")
    void case_UTAPI_003101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003101",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003101", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003101", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003101", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003101", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003101", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003102")
    void case_UTAPI_003102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003102",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003102", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003102", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003102", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003102", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003102", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003103")
    void case_UTAPI_003103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003103",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003103", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003103", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003103", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003103", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003103", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003104")
    void case_UTAPI_003104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003104",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003104", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003104", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003104", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003104", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003104", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003105")
    void case_UTAPI_003105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003105",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003105", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003105", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003105", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003105", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003105", "template.titleSql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("template.n", "SqlTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003106")
    void case_UTAPI_003106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003106",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003106", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003106", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003106", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003106", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003106", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "1:length_null", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003107")
    void case_UTAPI_003107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003107",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003107", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003107", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003107", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003107", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003107", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003108")
    void case_UTAPI_003108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003108",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003108", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003108", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003108", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003108", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003108", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "3:length_min", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003109")
    void case_UTAPI_003109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003109",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003109", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003109", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003109", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003109", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003109", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003110")
    void case_UTAPI_003110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003110",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003110", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003110", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003110", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003110", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003110", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "5:length_max", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003111")
    void case_UTAPI_003111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003111",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003111", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003111", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003111", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003111", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003111", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003112")
    void case_UTAPI_003112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003112",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003112", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003112", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003112", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003112", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003112", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003113")
    void case_UTAPI_003113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003113",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003113", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003113", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003113", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003113", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003113", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003114")
    void case_UTAPI_003114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003114",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003114", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003114", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003114", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003114", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003114", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003115")
    void case_UTAPI_003115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003115",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003115", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003115", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003115", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003115", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003115", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003116")
    void case_UTAPI_003116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003116",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003116", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003116", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003116", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003116", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003116", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003117")
    void case_UTAPI_003117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003117",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003117", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003117", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003117", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003117", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003117", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003118")
    void case_UTAPI_003118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003118",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003118", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003118", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003118", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003118", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003118", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003119")
    void case_UTAPI_003119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003119",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003119", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003119", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003119", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003119", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003119", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "56:space")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003120")
    void case_UTAPI_003120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003120",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003120", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003120", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003120", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003120", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003120", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003121")
    void case_UTAPI_003121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003121",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003121", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003121", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003121", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003121", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003121", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003122")
    void case_UTAPI_003122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003122",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003122", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003122", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003122", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003122", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003122", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "59:tab")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003123")
    void case_UTAPI_003123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003123",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003123", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003123", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003123", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003123", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003123", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003124")
    void case_UTAPI_003124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003124",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003124", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003124", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003124", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003124", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003124", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003125")
    void case_UTAPI_003125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003125",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003125", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003125", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003125", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003125", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003125", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003126")
    void case_UTAPI_003126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003126",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "save",
                "SqlTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "SqlTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003126", "template", "NORMAL", "OBJECT", "SqlTemplate"),
                    new DataRef("UTAPI-003126", "template.contentSql", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003126", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003126", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003126", "template.titleSql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::save::3::FIELD::1::SqlTemplate::titleSql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.titleSql", "SqlTemplate.titleSql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleSql is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentSql")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentSql")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleSql must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleSql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

}

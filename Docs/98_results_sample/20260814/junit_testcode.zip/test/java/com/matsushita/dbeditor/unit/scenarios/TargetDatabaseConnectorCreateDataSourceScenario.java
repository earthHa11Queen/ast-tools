package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TargetDatabaseConnectorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TargetDatabaseConnector#createDataSource.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TargetDatabaseConnectorCreateDataSourceScenario {

    @Test
    @DisplayName("UTAPI-011210")
    void case_UTAPI_011210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011210",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011210", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011210", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011210")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011211")
    void case_UTAPI_011211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011211",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011211", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011211", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011211")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011212")
    void case_UTAPI_011212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011212",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011212", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011212")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011213")
    void case_UTAPI_011213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011213",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011213", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011213")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011214")
    void case_UTAPI_011214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011214",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011214", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011214")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011215")
    void case_UTAPI_011215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011215",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011215", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011215")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011216")
    void case_UTAPI_011216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011216",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011216", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011216")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011217")
    void case_UTAPI_011217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011217",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011217", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011217", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011217")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011218")
    void case_UTAPI_011218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011218",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011218", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011218", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011218")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011219")
    void case_UTAPI_011219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011219",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011219", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011219", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011219")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011220")
    void case_UTAPI_011220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011220",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011220", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011220", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011220")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011221")
    void case_UTAPI_011221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011221",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011221", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011221", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011221")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011222")
    void case_UTAPI_011222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011222",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011222", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011222", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011222")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011223")
    void case_UTAPI_011223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011223",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011223", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011223", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011223")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011224")
    void case_UTAPI_011224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011224",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011224", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011224", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011224")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011225")
    void case_UTAPI_011225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011225",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011225", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011225", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011225")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011226")
    void case_UTAPI_011226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011226",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011226", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011226")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011227")
    void case_UTAPI_011227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011227",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011227", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011227")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011228")
    void case_UTAPI_011228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011228",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011228", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011228", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011228")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011229")
    void case_UTAPI_011229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011229",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011229", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011229", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011229")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011230")
    void case_UTAPI_011230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011230",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011230", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011230", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011230")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011231")
    void case_UTAPI_011231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011231",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011231", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011231", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011231")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011232")
    void case_UTAPI_011232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011232",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011232", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011232", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011232")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011233")
    void case_UTAPI_011233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011233",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011233", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011233", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011233")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011234")
    void case_UTAPI_011234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011234",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011234", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011234", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011234")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011235")
    void case_UTAPI_011235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011235",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011235", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011235", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011235")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011236")
    void case_UTAPI_011236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011236",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011236", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011236", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011236")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011237")
    void case_UTAPI_011237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011237",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011237", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011237", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011237")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011238")
    void case_UTAPI_011238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011238",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011238", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011238", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011238")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011239")
    void case_UTAPI_011239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011239",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011239", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011239", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011239")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011240")
    void case_UTAPI_011240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011240",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011240", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011240", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011240")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011241")
    void case_UTAPI_011241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011241",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011241", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011241", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011241")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011242")
    void case_UTAPI_011242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011242",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011242", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011242", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011242")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011243")
    void case_UTAPI_011243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011243",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011243", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011243", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011243")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011244")
    void case_UTAPI_011244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011244",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011244", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011244")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011245")
    void case_UTAPI_011245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011245",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011245", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011245", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011245", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011245")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011246")
    void case_UTAPI_011246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011246",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011246", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011246", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011246", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011246")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011247")
    void case_UTAPI_011247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011247",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011247", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011247", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011247", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011247", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011247")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011248")
    void case_UTAPI_011248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011248",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011248", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011248", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011248", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011248", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011248")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011249")
    void case_UTAPI_011249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011249",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011249", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011249", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011249", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011249")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011250")
    void case_UTAPI_011250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011250",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011250", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011250", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011250", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011250")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011251")
    void case_UTAPI_011251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011251",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011251", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011251", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011251", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011251")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011252")
    void case_UTAPI_011252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011252",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011252", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011252", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011252", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011252")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011253")
    void case_UTAPI_011253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011253",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011253", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011253", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011253", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011253")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011254")
    void case_UTAPI_011254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011254",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011254", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011254", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011254", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011254")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011255")
    void case_UTAPI_011255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011255",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011255", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011255", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011255", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011255", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011255")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011256")
    void case_UTAPI_011256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011256",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011256", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011256", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011256", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011256", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011256")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011257")
    void case_UTAPI_011257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011257",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011257", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011257", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011257", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011257", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011257")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011258")
    void case_UTAPI_011258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011258",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011258", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011258", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011258", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011258", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011258")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011259")
    void case_UTAPI_011259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011259",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011259", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011259", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011259", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011259", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011259", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011259", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011259", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011259", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011259", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011259", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011259")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011260")
    void case_UTAPI_011260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011260",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011260", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011260", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011260", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011260", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011260", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011260", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011260", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011260", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011260", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011260", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011260")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011261")
    void case_UTAPI_011261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011261",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011261", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011261", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011261", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011261", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011261", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011261", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011261", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011261", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011261", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011261", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011261")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011262")
    void case_UTAPI_011262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011262",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011262", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011262", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011262", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011262", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011262", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011262", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011262", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011262", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011262", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011262", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011262")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011263")
    void case_UTAPI_011263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011263",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011263", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011263", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011263", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011263", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011263", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011263", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011263", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011263", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011263", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011263", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011263")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011264")
    void case_UTAPI_011264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011264",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011264", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011264", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011264", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011264", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011264", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011264", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011264", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011264", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011264", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011264", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011264")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011265")
    void case_UTAPI_011265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011265",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011265", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011265", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011265", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011265", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011265", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011265", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011265", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011265", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011265", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011265", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011265")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011266")
    void case_UTAPI_011266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011266",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011266", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011266", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011266", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011266", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011266", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011266", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011266", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011266", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011266", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011266", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011266")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011267")
    void case_UTAPI_011267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011267",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011267", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011267", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011267", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011267", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011267", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011267", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011267", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011267", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011267", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011267", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011267")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011268")
    void case_UTAPI_011268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011268",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011268", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011268", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011268", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011268", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011268", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011268", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011268", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011268", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011268", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011268", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011268")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011269")
    void case_UTAPI_011269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011269",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011269", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011269", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011269", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011269", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011269", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011269", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011269", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011269", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011269", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011269", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011269")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011270")
    void case_UTAPI_011270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011270",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011270", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011270", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011270", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011270", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011270", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011270", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011270", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011270", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011270", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011270", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011270")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011271")
    void case_UTAPI_011271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011271",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011271", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011271", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011271", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011271", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011271", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011271", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011271", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011271", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011271", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011271", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011271")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011272")
    void case_UTAPI_011272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011272",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011272", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011272", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011272", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011272", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011272", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011272", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011272", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011272", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011272", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011272", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011272")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011273")
    void case_UTAPI_011273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011273",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011273", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011273", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011273", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011273", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011273", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011273", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011273", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011273", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011273", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011273", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011273")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011274")
    void case_UTAPI_011274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011274",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011274", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011274", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011274", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011274", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011274", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011274", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011274", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011274", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011274", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011274", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011274")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011275")
    void case_UTAPI_011275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011275",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011275", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011275", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011275", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011275", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011275", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011275", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011275", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011275", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011275", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011275", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011275")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011276")
    void case_UTAPI_011276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011276",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011276", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011276", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011276", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011276", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011276", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011276", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011276", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011276", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011276", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011276", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011276")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011277")
    void case_UTAPI_011277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011277",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011277", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011277", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011277", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011277", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011277", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011277", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011277", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011277", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011277", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011277", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011277")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011278")
    void case_UTAPI_011278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011278",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011278", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011278", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011278", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011278", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011278", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011278", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011278", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011278", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011278", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011278", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011278")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011279")
    void case_UTAPI_011279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011279",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011279", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011279", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011279", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011279", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011279", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011279", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011279", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011279", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011279", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011279", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011279")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011280")
    void case_UTAPI_011280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011280",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011280", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011280", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011280", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011280")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011281")
    void case_UTAPI_011281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011281",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011281", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011281", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011281")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011282")
    void case_UTAPI_011282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011282",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011282", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011282", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011282")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011283")
    void case_UTAPI_011283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011283",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011283", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011283", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011283")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011284")
    void case_UTAPI_011284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011284",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011284", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011284", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011284")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011285")
    void case_UTAPI_011285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011285",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011285", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011285", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011285")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011286")
    void case_UTAPI_011286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011286",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011286", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011286", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011286")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011287")
    void case_UTAPI_011287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011287",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011287", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011287", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011287")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011288")
    void case_UTAPI_011288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011288",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011288", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011288")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011289")
    void case_UTAPI_011289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011289",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011289", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011289")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011290")
    void case_UTAPI_011290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011290",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011290", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011290")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011291")
    void case_UTAPI_011291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011291",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011291", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011291", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011291")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011292")
    void case_UTAPI_011292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011292",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011292", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011292", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011292")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011293")
    void case_UTAPI_011293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011293",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011293", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011293", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011293")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011294")
    void case_UTAPI_011294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011294",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011294", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011294", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011294")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011295")
    void case_UTAPI_011295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011295",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011295", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011295", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011295")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011296")
    void case_UTAPI_011296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011296",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011296", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011296", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011296")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011297")
    void case_UTAPI_011297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011297",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011297", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011297", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011297")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011298")
    void case_UTAPI_011298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011298",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011298", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011298", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011298")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011299")
    void case_UTAPI_011299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011299",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011299", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011299", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011299")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011300")
    void case_UTAPI_011300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011300",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011300", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011300", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011300")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011301")
    void case_UTAPI_011301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011301",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011301", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011301", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011301")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011302")
    void case_UTAPI_011302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011302",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011302", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011302", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011302")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011303")
    void case_UTAPI_011303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011303",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011303", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011303")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011304")
    void case_UTAPI_011304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011304",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011304", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011304")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011305")
    void case_UTAPI_011305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011305",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011305", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011305", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011305")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011306")
    void case_UTAPI_011306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011306",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011306", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011306", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011306")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011307")
    void case_UTAPI_011307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011307",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011307", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011307", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011307")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011308")
    void case_UTAPI_011308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011308",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011308", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011308", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011308")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011309")
    void case_UTAPI_011309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011309",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011309", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011309")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011310")
    void case_UTAPI_011310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011310",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011310", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011310", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011310")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011311")
    void case_UTAPI_011311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011311",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011311", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011311", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011311")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011312")
    void case_UTAPI_011312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011312",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011312", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011312", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011312")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011313")
    void case_UTAPI_011313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011313",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011313", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011313", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011313")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011314")
    void case_UTAPI_011314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011314",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011314", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011314", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011314")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011315")
    void case_UTAPI_011315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011315",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011315", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011315", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011315")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011316")
    void case_UTAPI_011316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011316",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011316", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011316", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011316")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011317")
    void case_UTAPI_011317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011317",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011317", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011317", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011317")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011318")
    void case_UTAPI_011318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011318",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011318", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011318", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011318", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011318")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011319")
    void case_UTAPI_011319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011319",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011319", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011319", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011319", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011319")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011320")
    void case_UTAPI_011320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011320",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011320", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011320", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011320", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011320")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011321")
    void case_UTAPI_011321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011321",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011321", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011321", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011321", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011321")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011322")
    void case_UTAPI_011322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011322",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011322", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011322", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011322", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011322")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011323")
    void case_UTAPI_011323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011323",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011323", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011323", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011323", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011323")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011324")
    void case_UTAPI_011324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011324",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011324", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011324", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011324", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011324")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011325")
    void case_UTAPI_011325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011325",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011325", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011325", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011325", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011325")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011326")
    void case_UTAPI_011326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011326",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011326", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011326", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011326", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011326")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011327")
    void case_UTAPI_011327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011327",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011327", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011327", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011327", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011327")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011328")
    void case_UTAPI_011328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011328",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011328", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011328", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011328", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011328")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011329")
    void case_UTAPI_011329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011329",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011329", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011329", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011329")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011330")
    void case_UTAPI_011330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011330",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011330", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011330", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011330")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011331")
    void case_UTAPI_011331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011331",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011331", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011331", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011331")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011332")
    void case_UTAPI_011332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011332",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011332", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011332", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011332")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011333")
    void case_UTAPI_011333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011333",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011333", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011333", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011333")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011334")
    void case_UTAPI_011334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011334",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011334", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011334", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011334")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011335")
    void case_UTAPI_011335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011335",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011335", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011335", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011335")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011336")
    void case_UTAPI_011336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011336",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011336", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011336", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011336")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011337")
    void case_UTAPI_011337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011337",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011337", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011337", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011337")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011338")
    void case_UTAPI_011338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011338",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011338", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011338", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011338")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011339")
    void case_UTAPI_011339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011339",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011339", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011339", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011339", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011339")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011340")
    void case_UTAPI_011340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011340",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011340", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011340", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011340", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011340")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011341")
    void case_UTAPI_011341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011341",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011341", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011341", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011341", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011341")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011342")
    void case_UTAPI_011342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011342",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011342", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011342", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011342", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011342")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011343")
    void case_UTAPI_011343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011343",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011343", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011343", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011343", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011343")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011344")
    void case_UTAPI_011344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011344",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011344", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011344", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011344", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011344")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011345")
    void case_UTAPI_011345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011345",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011345", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011345", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011345", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011345")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011346")
    void case_UTAPI_011346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011346",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011346", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011346", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011346", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011346")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011347")
    void case_UTAPI_011347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011347",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011347", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011347", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011347", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011347")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011348")
    void case_UTAPI_011348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011348",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011348", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011348", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011348", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011348")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011349")
    void case_UTAPI_011349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011349",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011349", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011349", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011349", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011349")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011350")
    void case_UTAPI_011350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011350",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createDataSource",
                "DataSource",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011350", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011350", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011350")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createDataSource::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbHost", "getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain dbPort", "getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the data source url must contain databaseName", "getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured user", "getUsername", "data:setting.dbUsername")
                    .check(CheckType.RETURN_PATH_EQUALS, "the data source must use the configured password", "getPassword", "data:setting.dbPassword")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

}

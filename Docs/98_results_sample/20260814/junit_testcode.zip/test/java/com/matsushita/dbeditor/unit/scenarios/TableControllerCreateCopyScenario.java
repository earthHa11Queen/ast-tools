package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#createCopy.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerCreateCopyScenario {

    @Test
    @DisplayName("UTAPI-001316")
    void case_UTAPI_001316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001316",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001316", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001316", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001316", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001316")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001317")
    void case_UTAPI_001317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001317",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001317", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001317", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001317", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001317")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001318")
    void case_UTAPI_001318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001318",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001318", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001318", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001318", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001318")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001319")
    void case_UTAPI_001319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001319",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001319", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001319", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001319", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001319")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001320")
    void case_UTAPI_001320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001320",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001320", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001320", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001320", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001320")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001321")
    void case_UTAPI_001321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001321",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001321", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001321", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001321", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001321")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001322")
    void case_UTAPI_001322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001322",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001322", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001322", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001322", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001322")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001323")
    void case_UTAPI_001323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001323",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001323", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001323", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001323", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001323")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001324")
    void case_UTAPI_001324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001324",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001324", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001324", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001324", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001324")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001325")
    void case_UTAPI_001325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001325",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001325", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001325", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001325", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001325")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001326")
    void case_UTAPI_001326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001326",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001326", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001326", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001326", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001326")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001327")
    void case_UTAPI_001327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001327",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001327", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001327", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001327", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001327")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001328")
    void case_UTAPI_001328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001328",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001328", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001328", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001328", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001328")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001329")
    void case_UTAPI_001329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001329",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001329", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001329", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001329", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001329")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001330")
    void case_UTAPI_001330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001330",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001330", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001330", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001330", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001330")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001331")
    void case_UTAPI_001331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001331",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001331", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001331", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001331", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001331")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001332")
    void case_UTAPI_001332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001332",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001332", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001332", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001332", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001332")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001333")
    void case_UTAPI_001333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001333",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001333", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001333", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001333", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001333")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001334")
    void case_UTAPI_001334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001334",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001334", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001334", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001334", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001334")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001335")
    void case_UTAPI_001335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001335",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001335", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001335", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001335", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001335")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001336")
    void case_UTAPI_001336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001336",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001336", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001336", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001336", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001336")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001337")
    void case_UTAPI_001337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001337",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001337", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001337", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001337", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001337")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001338")
    void case_UTAPI_001338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001338",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001338", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001338", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001338", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001338")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001339")
    void case_UTAPI_001339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001339",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001339", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001339", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001339", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001339")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001340")
    void case_UTAPI_001340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001340",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001340", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001340", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001340", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001340")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001341")
    void case_UTAPI_001341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001341",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001341", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001341", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001341", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001341")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001342")
    void case_UTAPI_001342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001342",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001342", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001342", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001342", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001342")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001343")
    void case_UTAPI_001343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001343",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001343", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001343", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001343", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001343")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001344")
    void case_UTAPI_001344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001344",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001344", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001344", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001344", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001344")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001345")
    void case_UTAPI_001345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001345",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001345", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001345", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001345", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001345")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001346")
    void case_UTAPI_001346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001346",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001346", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001346", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001346", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001346")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001347")
    void case_UTAPI_001347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001347",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001347", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001347", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001347", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001347")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001348")
    void case_UTAPI_001348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001348",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001348", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001348", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001348", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001348")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001349")
    void case_UTAPI_001349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001349",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001349", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001349", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001349", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001349")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001350")
    void case_UTAPI_001350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001350",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001350", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001350", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001350", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001350")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001351")
    void case_UTAPI_001351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001351",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001351", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001351", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001351", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001351")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001352")
    void case_UTAPI_001352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001352",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001352", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001352", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001352", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001352")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001353")
    void case_UTAPI_001353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001353",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001353", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001353", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001353", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001353")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001354")
    void case_UTAPI_001354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001354",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001354", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001354", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001354", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001354")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001355")
    void case_UTAPI_001355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001355",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001355", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001355", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001355", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001355")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001356")
    void case_UTAPI_001356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001356",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001356", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001356", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001356", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001356")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001357")
    void case_UTAPI_001357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001357",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001357", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001357", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001357", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001357")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001358")
    void case_UTAPI_001358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001358",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001358", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001358", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001358", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001358")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001359")
    void case_UTAPI_001359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001359",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001359", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001359", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001359", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001359")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001360")
    void case_UTAPI_001360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001360",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001360", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001360", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001360", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001360")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001361")
    void case_UTAPI_001361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001361",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001361", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001361", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001361", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001361")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001362")
    void case_UTAPI_001362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001362",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001362", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001362", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001362", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001362")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001363")
    void case_UTAPI_001363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001363",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001363", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001363", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001363", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001363")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001364")
    void case_UTAPI_001364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001364",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001364", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001364", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001364", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001364")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001365")
    void case_UTAPI_001365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001365",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001365", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001365", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001365", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001365")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001366")
    void case_UTAPI_001366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001366",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001366", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001366", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001366", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001366")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001367")
    void case_UTAPI_001367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001367",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "createCopy",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001367", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001367", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001367", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001367")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::createCopy::5::ARG::3::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.createCopy")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.createCopy", "tableRecordUseCase", "createCopy")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.createCopy must carry the value generated for connectionId", "tableRecordUseCase", "createCopy", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.createCopy must carry the value generated for schema", "tableRecordUseCase", "createCopy", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.createCopy must carry the value generated for name", "tableRecordUseCase", "createCopy", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

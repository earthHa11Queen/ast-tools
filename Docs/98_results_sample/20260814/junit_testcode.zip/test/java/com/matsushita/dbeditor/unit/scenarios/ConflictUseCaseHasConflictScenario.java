package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConflictUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConflictUseCase#hasConflict.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConflictUseCaseHasConflictScenario {

    @Test
    @DisplayName("UTAPI-011666")
    void case_UTAPI_011666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011666",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011666", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011666", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011666")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011667")
    void case_UTAPI_011667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011667",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011667", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011667", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011667")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011668")
    void case_UTAPI_011668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011668",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011668", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011668", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011668")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011669")
    void case_UTAPI_011669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011669",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011669", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011669", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011669")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011670")
    void case_UTAPI_011670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011670",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011670", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011670", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011670")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011671")
    void case_UTAPI_011671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011671",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011671", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011671", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011671")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011672")
    void case_UTAPI_011672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011672",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011672", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011672", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011672")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011673")
    void case_UTAPI_011673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011673",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011673", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011673", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011673")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011674")
    void case_UTAPI_011674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011674",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011674", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011674", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011674")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011675")
    void case_UTAPI_011675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011675",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011675", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011675", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011675")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011676")
    void case_UTAPI_011676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011676",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011676", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011676")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011677")
    void case_UTAPI_011677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011677",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011677", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011677", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011677")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011678")
    void case_UTAPI_011678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011678",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011678", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011678", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011678")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011679")
    void case_UTAPI_011679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011679",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011679", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011679", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011679")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011680")
    void case_UTAPI_011680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011680",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011680", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011680", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011680")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011681")
    void case_UTAPI_011681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011681",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011681", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011681", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011681")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011682")
    void case_UTAPI_011682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011682",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011682", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011682", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011682")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011683")
    void case_UTAPI_011683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011683",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011683", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011683", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011683")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011684")
    void case_UTAPI_011684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011684",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011684", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011684", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011684")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011685")
    void case_UTAPI_011685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011685",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011685", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011685", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011685")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011686")
    void case_UTAPI_011686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011686",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011686", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011686", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011686")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011687")
    void case_UTAPI_011687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011687",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011687", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011687", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011687")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011688")
    void case_UTAPI_011688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011688",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011688", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011688", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011688")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011689")
    void case_UTAPI_011689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011689",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011689", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011689", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011689")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011690")
    void case_UTAPI_011690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011690",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011690", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011690", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011690")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011691")
    void case_UTAPI_011691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011691",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011691", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011691", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011691")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011692")
    void case_UTAPI_011692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011692",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011692", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011692", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011692")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011693")
    void case_UTAPI_011693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011693",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011693", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011693", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011693")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011694")
    void case_UTAPI_011694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011694",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011694", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011694", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011694")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011695")
    void case_UTAPI_011695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011695",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011695", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011695", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011695")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011696")
    void case_UTAPI_011696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011696",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011696", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011696", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011696")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011697")
    void case_UTAPI_011697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011697",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011697", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011697", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011697")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011698")
    void case_UTAPI_011698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011698",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011698", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011698", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011698")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011699")
    void case_UTAPI_011699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011699",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011699", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011699", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011699")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011700")
    void case_UTAPI_011700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011700",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011700", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011700", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011700")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011701")
    void case_UTAPI_011701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011701",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011701", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011701", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011701")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011702")
    void case_UTAPI_011702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011702",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011702", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011702", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011702")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011703")
    void case_UTAPI_011703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011703",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011703", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011703", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011703")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011704")
    void case_UTAPI_011704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011704",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011704", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011704", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011704")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011705")
    void case_UTAPI_011705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011705",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011705", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011705", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011705")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011706")
    void case_UTAPI_011706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011706",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011706", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011706", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011706")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011707")
    void case_UTAPI_011707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011707",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011707", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011707", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011707")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011708")
    void case_UTAPI_011708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011708",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011708", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011708", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011708")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011709")
    void case_UTAPI_011709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011709",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011709", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011709", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011709")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011710")
    void case_UTAPI_011710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011710",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011710", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011710", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011710")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011711")
    void case_UTAPI_011711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011711",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011711", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011711", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011711")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011712")
    void case_UTAPI_011712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011712",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011712", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011712", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011712")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011713")
    void case_UTAPI_011713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011713",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011713", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011713", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011713")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011714")
    void case_UTAPI_011714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011714",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011714", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011714", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011714")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011715")
    void case_UTAPI_011715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011715",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011715", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011715", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011715")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011716")
    void case_UTAPI_011716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011716",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011716", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011716", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011716")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011717")
    void case_UTAPI_011717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011717",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011717", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011717", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011717")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011718")
    void case_UTAPI_011718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011718",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011718", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011718", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011718")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.hasConflict")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.hasConflict", "tableConflictRepository", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.hasConflict must carry the value generated for schemaName", "tableConflictRepository", "hasConflict", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.hasConflict must carry the value generated for tableName", "tableConflictRepository", "hasConflict", "2", "data:tableName")
                    .check(CheckType.RETURN_EQUALS_VALUE, "the result must be the value obtained from tableConflictRepository.hasConflict", "stub:tableConflictRepository#hasConflict")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

}

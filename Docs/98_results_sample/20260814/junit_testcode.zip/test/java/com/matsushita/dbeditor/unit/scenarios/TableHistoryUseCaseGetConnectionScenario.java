package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryUseCase#getConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryUseCaseGetConnectionScenario {

    @Test
    @DisplayName("UTAPI-013017")
    void case_UTAPI_013017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013017",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013017", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013017")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013018")
    void case_UTAPI_013018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013018",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013018", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013018")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013019")
    void case_UTAPI_013019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013019",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013019", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013019")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013020")
    void case_UTAPI_013020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013020",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013020", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013020")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013021")
    void case_UTAPI_013021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013021",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013021", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013021")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013022")
    void case_UTAPI_013022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013022",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013022", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013022")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013023")
    void case_UTAPI_013023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013023",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013023", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013023")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013024")
    void case_UTAPI_013024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013024",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013024", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013024")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013025")
    void case_UTAPI_013025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013025",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013025", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013025")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013026")
    void case_UTAPI_013026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013026",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013026", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013026")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013027")
    void case_UTAPI_013027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013027",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getConnection",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013027", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013027")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getConnection::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

}

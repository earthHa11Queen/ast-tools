package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#downloadSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerDownloadSqlScenario {

    @Test
    @DisplayName("UTAPI-000984")
    void case_UTAPI_000984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000984",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000984", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000984")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "1:length_null", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000985")
    void case_UTAPI_000985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000985",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000985", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000985")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "2:length_empty", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000986")
    void case_UTAPI_000986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000986",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000986", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000986")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "3:length_min", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000987")
    void case_UTAPI_000987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000987",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000987", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000987")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000988")
    void case_UTAPI_000988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000988",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000988", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000988")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "5:length_max", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000989")
    void case_UTAPI_000989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000989",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000989", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000989")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000990")
    void case_UTAPI_000990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000990",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000990", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000990")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000991")
    void case_UTAPI_000991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000991",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000991", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000991")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("46:hw_integer", "-", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000992")
    void case_UTAPI_000992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000992",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000992", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000992")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "-", "12:integer_positive")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000993")
    void case_UTAPI_000993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000993",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000993", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000993")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "-", "13:integer_negative")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000994")
    void case_UTAPI_000994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000994",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "downloadSql",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000994", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000994")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::downloadSql::6::ARG::1::-::id")
                    .mirror("-", "-", "14:integer_zero")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.getSqlForDownload")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.getSqlForDownload", "sqlUseCase", "getSqlForDownload")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.getSqlForDownload must carry the value generated for id", "sqlUseCase", "getSqlForDownload", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

}

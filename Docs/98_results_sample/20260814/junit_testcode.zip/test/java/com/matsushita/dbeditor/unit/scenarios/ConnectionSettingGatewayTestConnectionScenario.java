package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingGateway#testConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingGatewayTestConnectionScenario {

    @Test
    @DisplayName("UTAPI-002011")
    void case_UTAPI_002011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002011",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002011", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002011", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002011", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002011", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002011", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "1:length_null", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002012")
    void case_UTAPI_002012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002012",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002012", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002012", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002012", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002012", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002012", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "2:length_empty", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002013")
    void case_UTAPI_002013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002013",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002013", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002013", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002013", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002013", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002013", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "3:length_min", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002014")
    void case_UTAPI_002014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002014",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002014", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002014", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002014", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002014", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002014", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002015")
    void case_UTAPI_002015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002015",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002015", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002015", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002015", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002015", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002015", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "5:length_max", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002016")
    void case_UTAPI_002016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002016",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002016", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002016", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002016", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002016", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002016", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002017")
    void case_UTAPI_002017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002017",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002017", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002017", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002017", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002017", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002017", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002018")
    void case_UTAPI_002018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002018",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002018", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002018", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002018", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002018", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002018", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002019")
    void case_UTAPI_002019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002019",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002019", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002019", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002019", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002019", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002019", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002020")
    void case_UTAPI_002020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002020",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002020", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002020", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002020", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002020", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002020", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002021")
    void case_UTAPI_002021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002021",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002021", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002021", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002021", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002021", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002021", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002022")
    void case_UTAPI_002022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002022",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002022", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002022", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002022", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002022", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002022", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002023")
    void case_UTAPI_002023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002023",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002023", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002023", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002023", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002023", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002023", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "56:space")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002024")
    void case_UTAPI_002024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002024",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002024", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002024", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002024", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002024", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002024", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002025")
    void case_UTAPI_002025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002025",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002025", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002025", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002025", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002025", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002025", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002026")
    void case_UTAPI_002026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002026",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002026", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002026", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002026", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002026", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002026", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "59:tab")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002027")
    void case_UTAPI_002027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002027",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002027", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002027", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002027", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002027", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002027", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "60:control_character_null")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002028")
    void case_UTAPI_002028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002028",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002028", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002028", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002028", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002028", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002028", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002029")
    void case_UTAPI_002029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002029",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002029", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002029", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002029", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002029", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002029", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002030")
    void case_UTAPI_002030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002030",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002030", "host", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002030", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002030", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002030", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002030", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::1::-::host")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("host", "host")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002031")
    void case_UTAPI_002031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002031",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002031", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002031", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002031", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002031", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002031", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "1:length_null", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002032")
    void case_UTAPI_002032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002032",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002032", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002032", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002032", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002032", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002032", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "2:length_empty", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002033")
    void case_UTAPI_002033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002033",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002033", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002033", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002033", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002033", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002033", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "3:length_min", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002034")
    void case_UTAPI_002034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002034",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002034", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002034", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002034", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002034", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002034", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002035")
    void case_UTAPI_002035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002035",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002035", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002035", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002035", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002035", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002035", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "5:length_max", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002036")
    void case_UTAPI_002036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002036",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002036", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002036", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002036", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002036", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002036", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002037")
    void case_UTAPI_002037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002037",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002037", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002037", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002037", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002037", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002037", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002038")
    void case_UTAPI_002038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002038",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002038", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002038", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002038", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002038", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002038", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("46:hw_integer", "-", "-")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002039")
    void case_UTAPI_002039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002039",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002039", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002039", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002039", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002039", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002039", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "12:integer_positive")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002040")
    void case_UTAPI_002040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002040",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002040", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002040", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002040", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002040", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002040", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "13:integer_negative")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002041")
    void case_UTAPI_002041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002041",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002041", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002041", "port", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002041", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002041", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002041", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::2::-::port")
                    .mirror("-", "-", "14:integer_zero")
                    .target("port", "port")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002042")
    void case_UTAPI_002042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002042",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002042", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002042", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002042", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002042", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002042", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002043")
    void case_UTAPI_002043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002043",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002043", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002043", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002043", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002043", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002043", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002044")
    void case_UTAPI_002044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002044",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002044", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002044", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002044", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002044", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002044", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002045")
    void case_UTAPI_002045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002045",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002045", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002045", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002045", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002045", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002045", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002046")
    void case_UTAPI_002046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002046",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002046", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002046", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002046", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002046", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002046", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002047")
    void case_UTAPI_002047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002047",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002047", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002047", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002047", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002047", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002047", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002048")
    void case_UTAPI_002048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002048",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002048", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002048", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002048", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002048", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002048", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002049")
    void case_UTAPI_002049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002049",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002049", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002049", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002049", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002049", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002049", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002050")
    void case_UTAPI_002050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002050",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002050", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002050", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002050", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002050", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002050", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002051")
    void case_UTAPI_002051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002051",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002051", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002051", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002051", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002051", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002051", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002052")
    void case_UTAPI_002052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002052",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002052", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002052", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002052", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002052", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002052", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002053")
    void case_UTAPI_002053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002053",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002053", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002053", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002053", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002053", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002053", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002054")
    void case_UTAPI_002054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002054",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002054", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002054", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002054", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002054", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002054", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002055")
    void case_UTAPI_002055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002055",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002055", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002055", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002055", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002055", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002055", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002056")
    void case_UTAPI_002056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002056",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002056", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002056", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002056", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002056", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002056", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002057")
    void case_UTAPI_002057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002057",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002057", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002057", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002057", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002057", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002057", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002058")
    void case_UTAPI_002058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002058",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002058", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002058", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002058", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002058", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002058", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002059")
    void case_UTAPI_002059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002059",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002059", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002059", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002059", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002059", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002059", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002060")
    void case_UTAPI_002060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002060",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002060", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002060", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002060", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002060", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002060", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002061")
    void case_UTAPI_002061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002061",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002061", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002061", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002061", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002061", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002061", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002062")
    void case_UTAPI_002062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002062",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002062", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002062", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002062", "databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002062", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002062", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::3::-::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("databaseName", "databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002063")
    void case_UTAPI_002063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002063",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002063", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002063", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002063", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002063", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002063", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "1:length_null", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002064")
    void case_UTAPI_002064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002064",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002064", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002064", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002064", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002064", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002064", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "2:length_empty", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002065")
    void case_UTAPI_002065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002065",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002065", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002065", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002065", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002065", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002065", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "3:length_min", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002066")
    void case_UTAPI_002066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002066",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002066", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002066", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002066", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002066", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002066", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002067")
    void case_UTAPI_002067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002067",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002067", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002067", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002067", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002067", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002067", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "5:length_max", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002068")
    void case_UTAPI_002068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002068",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002068", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002068", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002068", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002068", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002068", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002069")
    void case_UTAPI_002069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002069",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002069", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002069", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002069", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002069", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002069", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002070")
    void case_UTAPI_002070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002070",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002070", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002070", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002070", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002070", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002070", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002071")
    void case_UTAPI_002071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002071",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002071", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002071", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002071", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002071", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002071", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002072")
    void case_UTAPI_002072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002072",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002072", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002072", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002072", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002072", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002072", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002073")
    void case_UTAPI_002073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002073",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002073", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002073", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002073", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002073", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002073", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002074")
    void case_UTAPI_002074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002074",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002074", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002074", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002074", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002074", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002074", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002075")
    void case_UTAPI_002075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002075",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002075", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002075", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002075", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002075", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002075", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002076")
    void case_UTAPI_002076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002076",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002076", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002076", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002076", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002076", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002076", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "56:space")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002077")
    void case_UTAPI_002077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002077",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002077", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002077", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002077", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002077", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002077", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002078")
    void case_UTAPI_002078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002078",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002078", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002078", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002078", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002078", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002078", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002079")
    void case_UTAPI_002079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002079",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002079", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002079", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002079", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002079", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002079", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "59:tab")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002080")
    void case_UTAPI_002080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002080",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002080", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002080", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002080", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002080", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002080", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "60:control_character_null")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002081")
    void case_UTAPI_002081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002081",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002081", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002081", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002081", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002081", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002081", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002082")
    void case_UTAPI_002082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002082",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002082", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002082", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002082", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002082", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002082", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002083")
    void case_UTAPI_002083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002083",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002083", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002083", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002083", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002083", "username", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002083", "password", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::4::-::username")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("username", "username")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002084")
    void case_UTAPI_002084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002084",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002084", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002084", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002084", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002084", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002084", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "1:length_null", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002085")
    void case_UTAPI_002085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002085",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002085", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002085", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002085", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002085", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002085", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "2:length_empty", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002086")
    void case_UTAPI_002086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002086",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002086", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002086", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002086", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002086", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002086", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "3:length_min", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002087")
    void case_UTAPI_002087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002087",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002087", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002087", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002087", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002087", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002087", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002088")
    void case_UTAPI_002088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002088",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002088", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002088", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002088", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002088", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002088", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "5:length_max", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002089")
    void case_UTAPI_002089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002089",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002089", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002089", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002089", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002089", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002089", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002090")
    void case_UTAPI_002090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002090",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002090", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002090", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002090", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002090", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002090", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002091")
    void case_UTAPI_002091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002091",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002091", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002091", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002091", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002091", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002091", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002092")
    void case_UTAPI_002092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002092",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002092", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002092", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002092", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002092", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002092", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002093")
    void case_UTAPI_002093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002093",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002093", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002093", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002093", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002093", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002093", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002094")
    void case_UTAPI_002094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002094",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002094", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002094", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002094", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002094", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002094", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002095")
    void case_UTAPI_002095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002095",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002095", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002095", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002095", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002095", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002095", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002096")
    void case_UTAPI_002096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002096",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002096", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002096", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002096", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002096", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002096", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "56:space")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002097")
    void case_UTAPI_002097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002097",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002097", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002097", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002097", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002097", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002097", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002098")
    void case_UTAPI_002098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002098",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002098", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002098", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002098", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002098", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002098", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002099")
    void case_UTAPI_002099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002099",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002099", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002099", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002099", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002099", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002099", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "59:tab")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002100")
    void case_UTAPI_002100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002100",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002100", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002100", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002100", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002100", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002100", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "60:control_character_null")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002101")
    void case_UTAPI_002101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002101",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002101", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002101", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002101", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002101", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002101", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002102")
    void case_UTAPI_002102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002102",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002102", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002102", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002102", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002102", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002102", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002103")
    void case_UTAPI_002103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002103",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "testConnection",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("host", "String", "host"),
                    new ParamSpec("port", "Integer", "port"),
                    new ParamSpec("databaseName", "String", "databaseName"),
                    new ParamSpec("username", "String", "username"),
                    new ParamSpec("password", "String", "password")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002103", "host", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002103", "port", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002103", "databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002103", "username", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002103", "password", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::testConnection::6::ARG::5::-::password")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("password", "password")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.JDBC_CONNECTION_CONTRACT)
                    .observation("the connection request handed to the JDBC driver manager")
                    .expected("host, port and database name appear in the connection url and the supplied credentials are used unchanged")
                    .failure("a credential or url part is dropped, replaced by a default, or the test reports an outcome without attempting a connection")
                    .assertion("assert the captured url and credentials of the connection attempt")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection attempt must go through the JDBC driver manager", "DriverManager", "getConnection")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied host", "DriverManager", "getConnection", "0", "data:host")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied port", "DriverManager", "getConnection", "0", "data:port")
                    .check(CheckType.ARG_CONTAINS_TEXT, "the connection url must carry the supplied database name", "DriverManager", "getConnection", "0", "data:databaseName")
                    .check(CheckType.ARG_EQUALS, "the supplied user must be used for the connection attempt", "DriverManager", "getConnection", "1", "data:username")
                    .check(CheckType.ARG_EQUALS, "the supplied password must be used for the connection attempt", "DriverManager", "getConnection", "2", "data:password")
                    .check(CheckType.NO_EXCEPTION, "a connection test must report its outcome instead of propagating a failure")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

}

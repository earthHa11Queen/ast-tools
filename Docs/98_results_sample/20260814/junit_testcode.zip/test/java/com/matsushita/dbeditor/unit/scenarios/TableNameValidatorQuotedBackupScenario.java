package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#quotedBackup.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorQuotedBackupScenario {

    @Test
    @DisplayName("UTAPI-010862")
    void case_UTAPI_010862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010862",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010862", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010862", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010862")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedBackup for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010863")
    void case_UTAPI_010863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010863",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010863", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010863", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010863")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedBackup for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:schemaName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010864")
    void case_UTAPI_010864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010864",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010864", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010864", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010864")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010865")
    void case_UTAPI_010865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010865",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010865", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010865", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010865")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010866")
    void case_UTAPI_010866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010866",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010866", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010866", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010866")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010867")
    void case_UTAPI_010867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010867",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010867", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010867", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010867")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010868")
    void case_UTAPI_010868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010868",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010868", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010868", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010868")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010869")
    void case_UTAPI_010869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010869",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010869", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010869", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010869")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010870")
    void case_UTAPI_010870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010870",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010870", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010870", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010870")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010871")
    void case_UTAPI_010871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010871",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010871", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010871", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010871")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010872")
    void case_UTAPI_010872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010872",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010872", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010872", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010872")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010873")
    void case_UTAPI_010873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010873",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010873", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010873", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010873")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010874")
    void case_UTAPI_010874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010874",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010874", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010874", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010874")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010875")
    void case_UTAPI_010875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010875",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010875", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010875", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010875")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010876")
    void case_UTAPI_010876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010876",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010876", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010876", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010876")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010877")
    void case_UTAPI_010877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010877",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010877", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010877", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010877")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010878")
    void case_UTAPI_010878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010878",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010878", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010878", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010878")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010879")
    void case_UTAPI_010879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010879",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010879", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010879", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010879")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010880")
    void case_UTAPI_010880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010880",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010880", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010880", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010880")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010881")
    void case_UTAPI_010881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010881",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010881", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010881", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010881")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010882")
    void case_UTAPI_010882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010882",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010882", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010882", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010882")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::1::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010883")
    void case_UTAPI_010883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010883",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010883", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010883", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010883")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedBackup for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010884")
    void case_UTAPI_010884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010884",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010884", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010884", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010884")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the outcome of quotedBackup for an absent or empty identifier")
                    .expected("the composition rejects the identifier as an invalid argument")
                    .failure("an absent or empty identifier is composed into a statement fragment")
                    .assertion("assertThrows(IllegalArgumentException.class, ...)")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent or empty identifier can never match the declared identifier pattern", "java.lang.IllegalArgumentException", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010885")
    void case_UTAPI_010885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010885",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010885", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010885", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010885")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010886")
    void case_UTAPI_010886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010886",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010886", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010886", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010886")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010887")
    void case_UTAPI_010887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010887",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010887", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010887", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010887")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010888")
    void case_UTAPI_010888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010888",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010888", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010888", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010888")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010889")
    void case_UTAPI_010889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010889",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010889", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010889", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010889")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010890")
    void case_UTAPI_010890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010890",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010890", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010890", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010890")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010891")
    void case_UTAPI_010891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010891",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010891", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010891", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010891")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010892")
    void case_UTAPI_010892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010892",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010892", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010892", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010892")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010893")
    void case_UTAPI_010893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010893",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010893", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010893", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010893")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010894")
    void case_UTAPI_010894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010894",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010894", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010894", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010894")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010895")
    void case_UTAPI_010895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010895",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010895", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010895", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010895")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010896")
    void case_UTAPI_010896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010896",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010896", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010896", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010896")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010897")
    void case_UTAPI_010897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010897",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010897", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010897", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010897")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010898")
    void case_UTAPI_010898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010898",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010898", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010898", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010898")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010899")
    void case_UTAPI_010899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010899",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010899", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010899", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010899")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010900")
    void case_UTAPI_010900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010900",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010900", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010900", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010900")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010901")
    void case_UTAPI_010901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010901",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010901", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010901", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010901")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010902")
    void case_UTAPI_010902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010902",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010902", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010902", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010902")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010903")
    void case_UTAPI_010903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010903",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "quotedBackup",
                "String",
                new ParamSpec[] {
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010903", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010903", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010903")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::quotedBackup::10::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by quotedBackup, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain schemaName", "data:schemaName")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for WebConfig.
 */
public final class WebConfigWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.infrastructure.config.WebConfig";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.infrastructure.config.WebConfig";
    private static final String[] DEP_NAMES = new String[] {};
    private static final String[] DEP_TYPES = new String[] {};
    private static final String[] TYPES_addCorsMappings = new String[] {"CorsRegistry"};

    public WebConfigWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void addCorsMappings(registry) */
    public ExecutionResult addCorsMappings(Object[] args) {
        return invoke("addCorsMappings", TYPES_addCorsMappings, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("addCorsMappings".equals(operation)) {
            return addCorsMappings(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

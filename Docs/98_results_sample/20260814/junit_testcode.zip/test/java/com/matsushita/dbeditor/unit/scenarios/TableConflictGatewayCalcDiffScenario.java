package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictGateway#calcDiff.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictGatewayCalcDiffScenario {

    @Test
    @DisplayName("UTAPI-003310")
    void case_UTAPI_003310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003310",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003310", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003310", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003310")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003311")
    void case_UTAPI_003311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003311",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003311", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003311", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003311", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003311", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003311")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003312")
    void case_UTAPI_003312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003312",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003312", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003312", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003312", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003312")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003313")
    void case_UTAPI_003313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003313",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003313", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003313", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003313", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003313")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003314")
    void case_UTAPI_003314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003314",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003314", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003314", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003314", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003314")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003315")
    void case_UTAPI_003315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003315",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003315", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003315", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003315", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003315")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003316")
    void case_UTAPI_003316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003316",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003316", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003316", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003316", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003316")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003317")
    void case_UTAPI_003317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003317",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003317", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003317", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003317", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003317")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003318")
    void case_UTAPI_003318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003318",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003318", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003318", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003318", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003318", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003318")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003319")
    void case_UTAPI_003319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003319",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003319", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003319", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003319", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003319", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003319")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003320")
    void case_UTAPI_003320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003320",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003320", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003320", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003320", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003320", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003320")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003321")
    void case_UTAPI_003321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003321",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003321", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003321", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003321", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003321", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003321")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003322")
    void case_UTAPI_003322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003322",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003322", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003322", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003322", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003322", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003322")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003323")
    void case_UTAPI_003323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003323",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003323", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003323", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003323", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003323", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003323")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003324")
    void case_UTAPI_003324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003324",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003324", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003324", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003324", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003324", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003324")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003325")
    void case_UTAPI_003325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003325",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003325", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003325", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003325", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003325", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003325")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003326")
    void case_UTAPI_003326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003326",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003326", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003326", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003326", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003326", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003326")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003327")
    void case_UTAPI_003327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003327",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003327", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003327", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003327", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003327", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003327")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003328")
    void case_UTAPI_003328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003328",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003328", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003328", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003328", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003328", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003328")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003329")
    void case_UTAPI_003329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003329",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003329", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003329", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003329", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003329")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003330")
    void case_UTAPI_003330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003330",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003330", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003330", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003330", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003330")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003331")
    void case_UTAPI_003331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003331",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003331", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003331", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003331", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003331")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003332")
    void case_UTAPI_003332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003332",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003332", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003332", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003332", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003332")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003333")
    void case_UTAPI_003333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003333",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003333", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003333", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003333", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003333", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003333", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003333")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003334")
    void case_UTAPI_003334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003334",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003334", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003334", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003334", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003334", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003334", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003334")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003335")
    void case_UTAPI_003335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003335",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003335", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003335", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003335", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003335", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003335", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003335")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003336")
    void case_UTAPI_003336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003336",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003336", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003336", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003336", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003336", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003336", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003336")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003337")
    void case_UTAPI_003337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003337",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003337", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003337", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003337", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003337", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003337", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003337")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003338")
    void case_UTAPI_003338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003338",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003338", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003338", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003338", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003338", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003338", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003338")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003339")
    void case_UTAPI_003339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003339",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003339", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003339", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003339", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003339", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003339", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003339")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003340")
    void case_UTAPI_003340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003340",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003340", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003340", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003340", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003340", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003340", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003340")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003341")
    void case_UTAPI_003341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003341",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003341", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003341", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003341", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003341", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003341", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003341")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003342")
    void case_UTAPI_003342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003342",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003342", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003342", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003342", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003342", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003342", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003342")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003343")
    void case_UTAPI_003343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003343",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003343", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003343", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003343", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003343", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003343")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003344")
    void case_UTAPI_003344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003344",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003344", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003344", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003344", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003344", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003344", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003344")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003345")
    void case_UTAPI_003345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003345",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003345", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003345", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003345", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003345", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003345", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003345")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003346")
    void case_UTAPI_003346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003346",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003346", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003346", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003346", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003346", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003346", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003346")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003347")
    void case_UTAPI_003347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003347",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003347", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003347", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003347", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003347", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003347", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003347")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003348")
    void case_UTAPI_003348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003348",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003348", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003348", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003348", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003348", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003348", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003348")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003349")
    void case_UTAPI_003349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003349",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003349", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003349", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003349", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003349", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003349", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003349")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003350")
    void case_UTAPI_003350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003350",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003350", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003350", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003350", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003350", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003350")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003351")
    void case_UTAPI_003351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003351",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003351", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003351", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003351", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003351")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003352")
    void case_UTAPI_003352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003352",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003352", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003352", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003352", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003352", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003352")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003353")
    void case_UTAPI_003353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003353",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003353", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003353", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003353", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003353", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003353")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003354")
    void case_UTAPI_003354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003354",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003354", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003354", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003354", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003354", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003354")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003355")
    void case_UTAPI_003355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003355",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003355", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003355", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003355", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003355", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003355")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003356")
    void case_UTAPI_003356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003356",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003356", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003356", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003356", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003356", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003356")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003357")
    void case_UTAPI_003357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003357",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003357", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003357", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003357", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003357", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003357")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003358")
    void case_UTAPI_003358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003358",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003358", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003358", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003358", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003358", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003358")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003359")
    void case_UTAPI_003359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003359",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003359", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003359", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003359", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003359", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003359")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003360")
    void case_UTAPI_003360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003360",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003360", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003360", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003360", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003360", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003360")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003361")
    void case_UTAPI_003361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003361",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003361", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003361", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003361", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003361", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003361")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003362")
    void case_UTAPI_003362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003362",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003362", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003362", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003362", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003362", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003362")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003363")
    void case_UTAPI_003363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003363",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003363", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003363", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003363", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003363", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003363")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003364")
    void case_UTAPI_003364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003364",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003364", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003364", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003364", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003364", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003364")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003365")
    void case_UTAPI_003365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003365",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003365", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003365", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003365", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003365", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003365")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003366")
    void case_UTAPI_003366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003366",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003366", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003366", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003366", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003366", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003366")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003367")
    void case_UTAPI_003367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003367",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003367", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003367", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003367", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003367", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003367")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003368")
    void case_UTAPI_003368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003368",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003368", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003368", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003368", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003368", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003368")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003369")
    void case_UTAPI_003369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003369",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003369", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003369", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003369", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003369", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003369")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003370")
    void case_UTAPI_003370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003370",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003370", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003370", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003370", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003370")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003371")
    void case_UTAPI_003371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003371",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003371", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003371", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003371", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003371")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003372")
    void case_UTAPI_003372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003372",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003372", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003372", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003372", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003372")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003373")
    void case_UTAPI_003373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003373",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003373", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003373", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003373", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003373")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003374")
    void case_UTAPI_003374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003374",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003374", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003374", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003374", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003374")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003375")
    void case_UTAPI_003375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003375",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003375", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003375", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003375", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003375")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003376")
    void case_UTAPI_003376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003376",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003376", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003376", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003376", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003376")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003377")
    void case_UTAPI_003377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003377",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003377", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003377", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003377", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003377")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003378")
    void case_UTAPI_003378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003378",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003378", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003378", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003378", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003378")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003379")
    void case_UTAPI_003379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003379",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003379", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003379", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003379", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003379")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003380")
    void case_UTAPI_003380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003380",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003380", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003380", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003380", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003380")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003381")
    void case_UTAPI_003381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003381",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003381", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003381", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003381")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003382")
    void case_UTAPI_003382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003382",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003382", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003382", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003382")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003383")
    void case_UTAPI_003383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003383",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003383", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003383", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003383")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003384")
    void case_UTAPI_003384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003384",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003384", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003384", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003384", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003384")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003385")
    void case_UTAPI_003385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003385",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003385", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003385", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003385", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003385")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003386")
    void case_UTAPI_003386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003386",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003386", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003386", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003386", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003386", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003386")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003387")
    void case_UTAPI_003387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003387",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003387", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003387", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003387", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003387", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003387")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003388")
    void case_UTAPI_003388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003388",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003388", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003388", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003388", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003388", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003388")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003389")
    void case_UTAPI_003389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003389",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003389", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003389", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003389", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003389", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003389")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003390")
    void case_UTAPI_003390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003390",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003390", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003390", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003390", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003390", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003390")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003391")
    void case_UTAPI_003391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003391",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003391", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003391", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003391", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003391", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003391")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003392")
    void case_UTAPI_003392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003392",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003392", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003392", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003392", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003392", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003392")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003393")
    void case_UTAPI_003393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003393",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003393", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003393", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003393", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003393", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003393")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003394")
    void case_UTAPI_003394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003394",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003394", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003394", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003394", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003394", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003394", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003394")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003395")
    void case_UTAPI_003395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003395",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003395", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003395", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003395", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003395", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003395", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003395")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003396")
    void case_UTAPI_003396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003396",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003396", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003396", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003396", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003396", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003396", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003396")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003397")
    void case_UTAPI_003397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003397",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003397", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003397", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003397", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003397", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003397", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003397")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003398")
    void case_UTAPI_003398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003398",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003398", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003398", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003398", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003398", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003398", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003398")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003399")
    void case_UTAPI_003399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003399",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003399", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003399", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003399", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003399", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003399", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003399")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003400")
    void case_UTAPI_003400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003400",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003400", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003400", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003400", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003400")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003401")
    void case_UTAPI_003401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003401",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003401", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003401", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003401", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003401")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003402")
    void case_UTAPI_003402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003402",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003402", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003402", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003402", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003402")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003403")
    void case_UTAPI_003403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003403",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003403", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003403", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003403", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003403")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003404")
    void case_UTAPI_003404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003404",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003404", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003404", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003404", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003404", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003404")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003405")
    void case_UTAPI_003405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003405",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003405", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003405", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003405", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003405")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003406")
    void case_UTAPI_003406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003406",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003406", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003406", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003406", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003406")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003407")
    void case_UTAPI_003407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003407",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003407", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003407", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003407")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003408")
    void case_UTAPI_003408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003408",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003408", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003408", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003408")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003409")
    void case_UTAPI_003409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003409",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003409", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003409", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003409")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003410")
    void case_UTAPI_003410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003410",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003410", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003410", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003410")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003411")
    void case_UTAPI_003411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003411",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003411", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003411", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003411", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003411", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003411")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003412")
    void case_UTAPI_003412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003412",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003412", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003412", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003412", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003412", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003412")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003413")
    void case_UTAPI_003413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003413",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003413", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003413", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003413", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003413")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003414")
    void case_UTAPI_003414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003414",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003414", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003414", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003414", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003414")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003415")
    void case_UTAPI_003415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003415",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003415", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003415", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003415", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003415")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003416")
    void case_UTAPI_003416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003416",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003416", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003416", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003416", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003416", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003416")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003417")
    void case_UTAPI_003417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003417",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003417", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003417", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003417", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003417", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003417")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003418")
    void case_UTAPI_003418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003418",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003418", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003418", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003418", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003418", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003418")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003419")
    void case_UTAPI_003419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003419",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003419", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003419", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003419", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003419", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003419")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003420")
    void case_UTAPI_003420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003420",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003420", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003420", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003420", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003420", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003420")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003421")
    void case_UTAPI_003421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003421",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003421", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003421", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003421", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003421", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003421", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003421", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003421")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003422")
    void case_UTAPI_003422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003422",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003422", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003422", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003422", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003422", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003422", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003422", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003422")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003423")
    void case_UTAPI_003423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003423",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003423", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003423", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003423", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003423", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003423", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003423")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003424")
    void case_UTAPI_003424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003424",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003424", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003424", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003424", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003424", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003424", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003424")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003425")
    void case_UTAPI_003425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003425",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003425", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003425", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003425", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003425", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003425", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003425", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003425")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003426")
    void case_UTAPI_003426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003426",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003426", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003426", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003426", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003426", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003426", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003426", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003426")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003427")
    void case_UTAPI_003427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003427",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003427", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003427", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003427", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003427", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003427", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003427", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003427")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003428")
    void case_UTAPI_003428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003428",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003428", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003428", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003428", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003428", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003428", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003428", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003428")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003429")
    void case_UTAPI_003429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003429",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003429", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003429", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003429", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003429", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003429", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003429", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003429")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003430")
    void case_UTAPI_003430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003430",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003430", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003430", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003430", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003430", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003430", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003430", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003430")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003431")
    void case_UTAPI_003431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003431",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003431", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003431", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003431", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003431", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003431", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003431", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003431")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003432")
    void case_UTAPI_003432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003432",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003432", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003432", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003432")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003433")
    void case_UTAPI_003433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003433",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003433", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003433", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003433")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003434")
    void case_UTAPI_003434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003434",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003434", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003434", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003434")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003435")
    void case_UTAPI_003435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003435",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003435", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003435", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003435")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003436")
    void case_UTAPI_003436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003436",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003436", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003436", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003436", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003436")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003437")
    void case_UTAPI_003437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003437",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003437", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003437", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003437", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003437")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003438")
    void case_UTAPI_003438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003438",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003438", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003438", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003438", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003438")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003439")
    void case_UTAPI_003439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003439",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003439", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003439", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003439", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003439")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003440")
    void case_UTAPI_003440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003440",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003440", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003440", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003440", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003440")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003441")
    void case_UTAPI_003441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003441",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003441", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003441", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003441", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003441")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003442")
    void case_UTAPI_003442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003442",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003442", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003442", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003442", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003442")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003443")
    void case_UTAPI_003443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003443",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003443", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003443", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003443", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003443")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003444")
    void case_UTAPI_003444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003444",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003444", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003444", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003444", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003444")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003445")
    void case_UTAPI_003445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003445",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003445", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003445", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003445", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003445")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003446")
    void case_UTAPI_003446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003446",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003446", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003446", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003446", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003446")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003447")
    void case_UTAPI_003447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003447",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003447", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003447", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003447", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003447")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003448")
    void case_UTAPI_003448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003448",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003448", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003448", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003448", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003448")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003449")
    void case_UTAPI_003449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003449",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003449", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003449", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003449")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003450")
    void case_UTAPI_003450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003450",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003450", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003450", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003450", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003450")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003451")
    void case_UTAPI_003451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003451",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003451", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003451", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003451", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003451")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003452")
    void case_UTAPI_003452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003452",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003452", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003452", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003452", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003452")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003453")
    void case_UTAPI_003453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003453",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003453", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003453", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003453", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003453")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003454")
    void case_UTAPI_003454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003454",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003454", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003454", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003454", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003454")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003455")
    void case_UTAPI_003455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003455",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003455", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003455", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003455", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003455")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003456")
    void case_UTAPI_003456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003456",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003456", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003456", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003456", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003456")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003457")
    void case_UTAPI_003457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003457",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003457", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003457", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003457", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003457")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003458")
    void case_UTAPI_003458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003458",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003458", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003458", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003458", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003458")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003459")
    void case_UTAPI_003459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003459",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003459", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003459", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003459", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003459")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003460")
    void case_UTAPI_003460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003460",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003460", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003460", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003460", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003460")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003461")
    void case_UTAPI_003461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003461",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003461", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003461", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003461", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003461")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003462")
    void case_UTAPI_003462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003462",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003462", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003462", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003462")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003463")
    void case_UTAPI_003463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003463",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003463", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003463", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003463")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003464")
    void case_UTAPI_003464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003464",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003464", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003464", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003464", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003464")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003465")
    void case_UTAPI_003465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003465",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003465", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003465", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003465", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003465")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003466")
    void case_UTAPI_003466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003466",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003466", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003466", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003466", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003466")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003467")
    void case_UTAPI_003467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003467",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003467", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003467", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003467", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003467")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003468")
    void case_UTAPI_003468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003468",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003468", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003468", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003468", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003468")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003469")
    void case_UTAPI_003469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003469",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003469", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003469", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003469", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003469")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003470")
    void case_UTAPI_003470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003470",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003470", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003470", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003470", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003470")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003471")
    void case_UTAPI_003471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003471",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003471", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003471", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003471", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003471")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003472")
    void case_UTAPI_003472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003472",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003472", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003472")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003473")
    void case_UTAPI_003473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003473",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003473", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003473")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003474")
    void case_UTAPI_003474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003474",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003474", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003474", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003474")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003475")
    void case_UTAPI_003475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003475",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003475", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003475", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003475")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003476")
    void case_UTAPI_003476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003476",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003476", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003476", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003476")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003477")
    void case_UTAPI_003477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003477",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003477", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003477", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003477")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003478")
    void case_UTAPI_003478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003478",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003478", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003478")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003479")
    void case_UTAPI_003479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003479",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003479", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003479")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003480")
    void case_UTAPI_003480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003480",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003480", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003480")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003481")
    void case_UTAPI_003481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003481",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003481", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003481")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003482")
    void case_UTAPI_003482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003482",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003482", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003482")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003483")
    void case_UTAPI_003483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003483",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003483", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003483")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003484")
    void case_UTAPI_003484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003484",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003484", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003484")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003485")
    void case_UTAPI_003485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003485",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003485", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003485")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003486")
    void case_UTAPI_003486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003486",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003486", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003486")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003487")
    void case_UTAPI_003487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003487",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003487", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003487")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003488")
    void case_UTAPI_003488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003488",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003488", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003489")
    void case_UTAPI_003489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003489",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003489", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003490")
    void case_UTAPI_003490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003490",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003490", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003491")
    void case_UTAPI_003491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003491",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003491", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003492")
    void case_UTAPI_003492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003492",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "calcDiff",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003492", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::calcDiff::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

}

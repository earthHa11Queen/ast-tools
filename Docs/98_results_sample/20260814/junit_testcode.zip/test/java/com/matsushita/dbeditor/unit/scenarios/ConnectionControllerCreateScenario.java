package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionController#create.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionControllerCreateScenario {

    @Test
    @DisplayName("UTAPI-000008")
    void case_UTAPI_000008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000008",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000008", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000008", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000008", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000008", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000008", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000008", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000008", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.databaseName classifies this input condition", "ConnectionSettingRequest", "databaseName", "NotBlank", "data:request.databaseName")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000009")
    void case_UTAPI_000009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000009",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000009", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000009", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000009", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000009", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000009", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000009", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000009", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000010")
    void case_UTAPI_000010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000010",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000010", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000010", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000010", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000010", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000010", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000010", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000010", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000011")
    void case_UTAPI_000011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000011",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000011", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000011", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000011", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000011", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000011", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000011", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000011", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000012")
    void case_UTAPI_000012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000012",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000012", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000012", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000012", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000012", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000012", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000012", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000012", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000013")
    void case_UTAPI_000013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000013",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000013", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000013", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000013", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000013", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000013", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000013", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000013", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000014")
    void case_UTAPI_000014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000014",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000014", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000014", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000014", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000014", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000014", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000014", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000014", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000015")
    void case_UTAPI_000015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000015",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000015", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000015", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000015", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000015", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000015", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000015", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000015", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000016")
    void case_UTAPI_000016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000016",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000016", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000016", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000016", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000016", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000016", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000016", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000016", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000017")
    void case_UTAPI_000017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000017",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000017", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000017", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000017", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000017", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000017", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000017", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000017", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000018")
    void case_UTAPI_000018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000018",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000018", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000018", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000018", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000018", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000018", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000018", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000018", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000019")
    void case_UTAPI_000019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000019",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000019", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000019", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000019", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000019", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000019", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000019", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000019", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000020")
    void case_UTAPI_000020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000020",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000020", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000020", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000020", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000020", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000020", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000020", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000020", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000021")
    void case_UTAPI_000021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000021",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000021", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000021", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000021", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000021", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000021", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000021", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000021", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000022")
    void case_UTAPI_000022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000022",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000022", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000022", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000022", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000022", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000022", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000022", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000022", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000023")
    void case_UTAPI_000023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000023",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000023", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000023", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000023", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000023", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000023", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000023", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000023", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000024")
    void case_UTAPI_000024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000024",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000024", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000024", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000024", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000024", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000024", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000024", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000024", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000024")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000025")
    void case_UTAPI_000025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000025",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000025", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000025", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000025", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000025", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000025", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000025", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000025", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000025")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000026")
    void case_UTAPI_000026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000026",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000026", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000026", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000026", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000026", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000026", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000026", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000026", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000026")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000027")
    void case_UTAPI_000027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000027",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000027", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000027", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000027", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000027", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000027", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000027", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000027", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000027")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000028")
    void case_UTAPI_000028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000028",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000028", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000028", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000028", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000028", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000028", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000028", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000028", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000028")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbHost classifies this input condition", "ConnectionSettingRequest", "dbHost", "NotBlank", "data:request.dbHost")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000029")
    void case_UTAPI_000029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000029",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000029", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000029", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000029", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000029", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000029", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000029", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000029", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000029")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000030")
    void case_UTAPI_000030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000030",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000030", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000030", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000030", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000030", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000030", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000030", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000030", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000030")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000031")
    void case_UTAPI_000031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000031",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000031", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000031", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000031", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000031", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000031", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000031", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000031", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000031")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000032")
    void case_UTAPI_000032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000032",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000032", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000032", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000032", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000032", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000032", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000032", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000032", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000032")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000033")
    void case_UTAPI_000033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000033",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000033", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000033", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000033", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000033", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000033", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000033", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000033", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000033")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000034")
    void case_UTAPI_000034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000034",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000034", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000034", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000034", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000034", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000034", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000034", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000034", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000034")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000035")
    void case_UTAPI_000035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000035",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000035", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000035", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000035", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000035", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000035", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000035", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000035", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000035")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000036")
    void case_UTAPI_000036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000036",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000036", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000036", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000036", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000036", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000036", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000036", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000036", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000036")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000037")
    void case_UTAPI_000037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000037",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000037", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000037", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000037", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000037", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000037", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000037", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000037", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000037")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000038")
    void case_UTAPI_000038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000038",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000038", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000038", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000038", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000038", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000038", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000038", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000038", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000038")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000039")
    void case_UTAPI_000039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000039",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000039", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000039", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000039", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000039", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000039", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000039", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000039", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000039")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000040")
    void case_UTAPI_000040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000040",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000040", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000040", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000040", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000040", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000040", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000040", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000040", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000040")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000041")
    void case_UTAPI_000041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000041",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000041", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000041", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000041", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000041", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000041", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000041", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000041", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000041")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000042")
    void case_UTAPI_000042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000042",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000042", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000042", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000042", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000042", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000042", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000042", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000042", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000042")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000043")
    void case_UTAPI_000043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000043",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000043", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000043", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000043", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000043", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000043", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000043", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000043", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000043")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000044")
    void case_UTAPI_000044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000044",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000044", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000044", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000044", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000044", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000044", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000044", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000044", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000045")
    void case_UTAPI_000045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000045",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000045", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000045", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000045", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000045", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000045", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000045", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000045", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000046")
    void case_UTAPI_000046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000046",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000046", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000046", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000046", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000046", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000046", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000046", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000046", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000047")
    void case_UTAPI_000047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000047",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000047", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000047", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000047", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000047", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000047", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000047", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000047", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbName classifies this input condition", "ConnectionSettingRequest", "dbName", "NotBlank", "data:request.dbName")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000048")
    void case_UTAPI_000048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000048",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000048", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000048", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000048", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000048", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000048", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000048", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000048", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000049")
    void case_UTAPI_000049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000049",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000049", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000049", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000049", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000049", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000049", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000049", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000049", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000050")
    void case_UTAPI_000050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000050",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000050", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000050", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000050", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000050", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000050", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000050", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000050", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000051")
    void case_UTAPI_000051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000051",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000051", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000051", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000051", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000051", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000051", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000051", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000051", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000052")
    void case_UTAPI_000052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000052",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000052", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000052", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000052", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000052", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000052", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000052", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000052", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000053")
    void case_UTAPI_000053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000053",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000053", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000053", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000053", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000053", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000053", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000053", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000053", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000054")
    void case_UTAPI_000054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000054",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000054", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000054", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000054", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000054", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000054", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000054", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000054", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000055")
    void case_UTAPI_000055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000055",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000055", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000055", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000055", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000055", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000055", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000055", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000055", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000055")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000056")
    void case_UTAPI_000056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000056",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000056", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000056", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000056", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000056", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000056", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000056", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000056", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000056")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000057")
    void case_UTAPI_000057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000057",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000057", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000057", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000057", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000057", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000057", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000057", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000057", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000057")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000058")
    void case_UTAPI_000058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000058",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000058", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000058", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000058", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000058", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000058", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000058", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000058", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000058")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000059")
    void case_UTAPI_000059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000059",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000059", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000059", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000059", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000059", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000059", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000059", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000059", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000059")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000060")
    void case_UTAPI_000060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000060",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000060", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000060", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000060", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000060", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000060", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000060", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000060", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000060")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000061")
    void case_UTAPI_000061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000061",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000061", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000061", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000061", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000061", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000061", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000061", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000061", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000061")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000062")
    void case_UTAPI_000062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000062",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000062", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000062", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000062", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000062", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000062", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000062", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000062", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000062")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000063")
    void case_UTAPI_000063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000063",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000063", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000063", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000063", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000063", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000063", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000063", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000063", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000063")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000064")
    void case_UTAPI_000064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000064",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000064", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000064", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000064", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000064", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000064", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000064", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000064", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000064")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000065")
    void case_UTAPI_000065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000065",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000065", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000065", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000065", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000065", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000065", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000065", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000065", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000066")
    void case_UTAPI_000066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000066",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000066", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000066", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000066", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000066", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000066", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000066", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000066", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000067")
    void case_UTAPI_000067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000067",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000067", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000067", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000067", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000067", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000067", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000067", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000067", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbPassword classifies this input condition", "ConnectionSettingRequest", "dbPassword", "NotBlank", "data:request.dbPassword")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000068")
    void case_UTAPI_000068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000068",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000068", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000068", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000068", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000068", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000068", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000068", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000068", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000069")
    void case_UTAPI_000069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000069",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000069", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000069", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000069", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000069", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000069", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000069", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000069", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000070")
    void case_UTAPI_000070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000070",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000070", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000070", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000070", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000070", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000070", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000070", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000070", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000071")
    void case_UTAPI_000071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000071",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000071", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000071", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000071", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000071", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000071", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000071", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000071", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000072")
    void case_UTAPI_000072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000072",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000072", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000072", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000072", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000072", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000072", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000072", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000072", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000073")
    void case_UTAPI_000073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000073",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000073", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000073", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000073", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000073", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000073", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000073", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000073", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000074")
    void case_UTAPI_000074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000074",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000074", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000074", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000074", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000074", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000074", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000074", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000074", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000075")
    void case_UTAPI_000075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000075",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000075", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000075", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000075", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000075", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000075", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000075", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000075", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000076")
    void case_UTAPI_000076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000076",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000076", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000076", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000076", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000076", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000076", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000076", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000076", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000077")
    void case_UTAPI_000077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000077",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000077", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000077", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000077", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000077", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000077", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000077", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000077", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000078")
    void case_UTAPI_000078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000078",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000078", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000078", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000078", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000078", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000078", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000078", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000078", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000079")
    void case_UTAPI_000079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000079",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000079", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000079", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000079", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000079", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000079", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000079", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000079", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000080")
    void case_UTAPI_000080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000080",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000080", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000080", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000080", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000080", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000080", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000080", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000080", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000081")
    void case_UTAPI_000081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000081",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000081", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000081", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000081", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000081", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000081", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000081", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000081", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000082")
    void case_UTAPI_000082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000082",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000082", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000082", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000082", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000082", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000082", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000082", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000082", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000083")
    void case_UTAPI_000083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000083",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000083", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000083", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000083", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000083", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000083", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000083", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000083", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000084")
    void case_UTAPI_000084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000084",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000084", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000084", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000084", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000084", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000084", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000084", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000084", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000085")
    void case_UTAPI_000085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000085",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000085", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000085", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000085", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000085", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000085", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000085", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000085", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000086")
    void case_UTAPI_000086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000086",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000086", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000086", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000086", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000086", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000086", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000086", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000086", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000087")
    void case_UTAPI_000087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000087",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000087", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000087", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000087", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000087", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000087", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000087", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000087", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000088")
    void case_UTAPI_000088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000088",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000088", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000088", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000088", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000088", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000088", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000088", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000088", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000089")
    void case_UTAPI_000089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000089",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000089", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000089", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000089", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000089", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000089", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000089", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000089", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000090")
    void case_UTAPI_000090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000090",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000090", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000090", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000090", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000090", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000090", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000090", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000090", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000091")
    void case_UTAPI_000091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000091",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000091", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000091", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000091", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000091", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000091", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000091", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000091", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000092")
    void case_UTAPI_000092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000092",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000092", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000092", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000092", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000092", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000092", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000092", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000092", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000093")
    void case_UTAPI_000093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000093",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000093", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000093", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000093", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000093", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000093", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000093", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000093", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000094")
    void case_UTAPI_000094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000094",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000094", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000094", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000094", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000094", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000094", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000094", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000094", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000095")
    void case_UTAPI_000095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000095",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000095", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000095", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000095", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000095", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000095", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000095", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000095", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000096")
    void case_UTAPI_000096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000096",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000096", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000096", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000096", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000096", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000096", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000096", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000096", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbUsername classifies this input condition", "ConnectionSettingRequest", "dbUsername", "NotBlank", "data:request.dbUsername")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000097")
    void case_UTAPI_000097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000097",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000097", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000097", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000097", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000097", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000097", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000097", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000097", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000098")
    void case_UTAPI_000098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000098",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000098", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000098", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000098", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000098", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000098", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000098", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000098", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000099")
    void case_UTAPI_000099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000099",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000099", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000099", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000099", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000099", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000099", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000099", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000099", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000100")
    void case_UTAPI_000100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000100",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000100", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000100", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000100", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000100", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000100", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000100", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000100", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000101")
    void case_UTAPI_000101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000101",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000101", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000101", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000101", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000101", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000101", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000101", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000101", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000102")
    void case_UTAPI_000102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000102",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000102", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000102", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000102", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000102", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000102", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000102", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000102", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000103")
    void case_UTAPI_000103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000103",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000103", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000103", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000103", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000103", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000103", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000103", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000103", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000104")
    void case_UTAPI_000104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000104",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000104", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000104", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000104", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000104", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000104", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000104", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000104", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000105")
    void case_UTAPI_000105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000105",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000105", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000105", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000105", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000105", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000105", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000105", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000105", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000106")
    void case_UTAPI_000106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000106",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000106", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000106", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000106", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000106", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000106", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000106", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000106", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000107")
    void case_UTAPI_000107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000107",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000107", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000107", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000107", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000107", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000107", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000107", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000107", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000108")
    void case_UTAPI_000108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000108",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000108", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000108", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000108", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000108", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000108", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000108", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000108", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000109")
    void case_UTAPI_000109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000109",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000109", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000109", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000109", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000109", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000109", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000109", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000109", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000110")
    void case_UTAPI_000110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000110",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000110", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000110", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000110", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000110", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000110", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000110", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000110", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000111")
    void case_UTAPI_000111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000111",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000111", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000111", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000111", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000111", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000111", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000111", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000111", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000112")
    void case_UTAPI_000112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000112",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000112", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000112", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000112", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000112", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000112", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000112", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000112", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000113")
    void case_UTAPI_000113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000113",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000113", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000113", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000113", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000113", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000113", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000113", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000113", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000114")
    void case_UTAPI_000114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000114",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000114", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000114", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000114", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000114", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000114", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000114", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000114", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000115")
    void case_UTAPI_000115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000115",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "create",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000115", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-000115", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000115", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000115", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000115", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000115", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000115", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.create")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.create", "connectionUseCase", "create")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.create must carry the value generated for request", "connectionUseCase", "create", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

}

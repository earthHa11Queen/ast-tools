package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoController#getMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoControllerGetMemoScenario {

    @Test
    @DisplayName("UTAPI-000836")
    void case_UTAPI_000836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000836",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000836", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000836", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000837")
    void case_UTAPI_000837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000837",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000837", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000837", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000838")
    void case_UTAPI_000838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000838",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000838", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000838", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000839")
    void case_UTAPI_000839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000839",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000839", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000839", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000840")
    void case_UTAPI_000840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000840",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000840", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000840", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000841")
    void case_UTAPI_000841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000841",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000841", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000841", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000842")
    void case_UTAPI_000842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000842",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000842", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000842", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000843")
    void case_UTAPI_000843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000843",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000843", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000843", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000844")
    void case_UTAPI_000844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000844",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000844", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000844", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000845")
    void case_UTAPI_000845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000845",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000845", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000845", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000846")
    void case_UTAPI_000846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000846",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000846", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000846", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000847")
    void case_UTAPI_000847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000847",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000847", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000847", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000848")
    void case_UTAPI_000848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000848",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000848", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000848", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000849")
    void case_UTAPI_000849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000849",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000849", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000849", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000850")
    void case_UTAPI_000850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000850",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000850", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000850", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000851")
    void case_UTAPI_000851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000851",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000851", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000851", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000852")
    void case_UTAPI_000852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000852",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000852", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000852", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000853")
    void case_UTAPI_000853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000853",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000853", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000853", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000854")
    void case_UTAPI_000854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000854",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000854", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000854", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000855")
    void case_UTAPI_000855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000855",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000855", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000855", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000856")
    void case_UTAPI_000856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000856",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000856", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000856", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000857")
    void case_UTAPI_000857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000857",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000857", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000857", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000858")
    void case_UTAPI_000858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000858",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000858", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000858", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000858")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000859")
    void case_UTAPI_000859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000859",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000859", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000859", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000859")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000860")
    void case_UTAPI_000860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000860",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000860", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000860", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000860")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000861")
    void case_UTAPI_000861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000861",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000861", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000861", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000861")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000862")
    void case_UTAPI_000862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000862",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000862", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000862", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000862")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000863")
    void case_UTAPI_000863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000863",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000863", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000863", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000863")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000864")
    void case_UTAPI_000864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000864",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000864", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000864", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000864")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000865")
    void case_UTAPI_000865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000865",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000865", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000865", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000865")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000866")
    void case_UTAPI_000866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000866",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000866", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000866", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000866")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000867")
    void case_UTAPI_000867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000867",
                "com.matsushita.dbeditor.adapter.controller.MemoController",
                "getMemo",
                "ResponseEntity<MemoResponse>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000867", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000867", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000867")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/MemoController.java::MemoController::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoUseCase.getMemo")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoUseCase.getMemo", "memoUseCase", "getMemo")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoUseCase.getMemo must carry the value generated for connectionId", "memoUseCase", "getMemo", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of memoUseCase.getMemo must carry the value generated for tableName", "memoUseCase", "getMemo", "1", "data:tableName")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoControllerWrapper());
    }

}

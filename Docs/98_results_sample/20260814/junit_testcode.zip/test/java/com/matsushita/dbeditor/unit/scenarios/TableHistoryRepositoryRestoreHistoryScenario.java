package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryRepository#restoreHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryRepositoryRestoreHistoryScenario {

    @Test
    @DisplayName("UTAPI-008392")
    void case_UTAPI_008392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008392",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008392", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008392", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008392", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008392", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008392")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008393")
    void case_UTAPI_008393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008393",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008393", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008393", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008393", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008393", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008393")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008394")
    void case_UTAPI_008394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008394",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008394", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008394", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008394", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008394", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008394")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008395")
    void case_UTAPI_008395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008395",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008395", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008395", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008395", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008395", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008395")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008396")
    void case_UTAPI_008396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008396",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008396", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008396", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008396", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008396", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008396")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008397")
    void case_UTAPI_008397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008397",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008397", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008397", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008397", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008397", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008397")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008398")
    void case_UTAPI_008398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008398",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008398", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008398", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008398", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008398", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008398")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008399")
    void case_UTAPI_008399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008399",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008399", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008399", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008399", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008399", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008399")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008400")
    void case_UTAPI_008400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008400",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008400", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008400", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008400", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008400", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008400")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008401")
    void case_UTAPI_008401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008401",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008401", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008401", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008401", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008401", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008401")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008402")
    void case_UTAPI_008402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008402",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008402", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008402", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008402", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008402")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008403")
    void case_UTAPI_008403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008403",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008403", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008403", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008403", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008403")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008404")
    void case_UTAPI_008404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008404",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008404", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008404", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008404", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008404", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008404")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008405")
    void case_UTAPI_008405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008405",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008405", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008405", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008405", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008405")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008406")
    void case_UTAPI_008406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008406",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008406", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008406", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008406", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008406")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008407")
    void case_UTAPI_008407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008407",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008407", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008407", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008407")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008408")
    void case_UTAPI_008408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008408",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008408", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008408", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008408")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008409")
    void case_UTAPI_008409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008409",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008409", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008409", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008409")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008410")
    void case_UTAPI_008410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008410",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008410", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008410", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008410")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008411")
    void case_UTAPI_008411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008411",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008411", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008411", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008411", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008411")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008412")
    void case_UTAPI_008412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008412",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008412", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008412", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008412", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008412")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008413")
    void case_UTAPI_008413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008413",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008413", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008413", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008413", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008413")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008414")
    void case_UTAPI_008414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008414",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008414", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008414", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008414", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008414")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008415")
    void case_UTAPI_008415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008415",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008415", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008415", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008415", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008415")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008416")
    void case_UTAPI_008416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008416",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008416", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008416", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008416", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008416", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008416")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008417")
    void case_UTAPI_008417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008417",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008417", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008417", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008417", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008417", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008417")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008418")
    void case_UTAPI_008418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008418",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008418", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008418", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008418", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008418", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008418")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008419")
    void case_UTAPI_008419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008419",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008419", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008419", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008419", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008419", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008419")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008420")
    void case_UTAPI_008420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008420",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008420", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008420", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008420", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008420", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008420")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008421")
    void case_UTAPI_008421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008421",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008421", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008421", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008421", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008421", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008421")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008422")
    void case_UTAPI_008422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008422",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008422", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008422", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008422", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008422", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008422")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008423")
    void case_UTAPI_008423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008423",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008423", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008423", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008423", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008423")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008424")
    void case_UTAPI_008424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008424",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008424", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008424", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008424", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008424")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008425")
    void case_UTAPI_008425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008425",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008425", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008425", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008425", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008425")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008426")
    void case_UTAPI_008426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008426",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008426", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008426", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008426", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008426")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008427")
    void case_UTAPI_008427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008427",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008427", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008427", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008427", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008427")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008428")
    void case_UTAPI_008428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008428",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008428", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008428", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008428", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008428")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008429")
    void case_UTAPI_008429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008429",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008429", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008429", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008429", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008429")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008430")
    void case_UTAPI_008430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008430",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008430", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008430", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008430", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008430")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008431")
    void case_UTAPI_008431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008431",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008431", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008431", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008431", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008431")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008432")
    void case_UTAPI_008432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008432",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008432", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008432", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008432")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008433")
    void case_UTAPI_008433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008433",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008433", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008433", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008433")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008434")
    void case_UTAPI_008434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008434",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008434", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008434", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008434")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008435")
    void case_UTAPI_008435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008435",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008435", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008435", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008435")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008436")
    void case_UTAPI_008436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008436",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008436", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008436", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008436", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008436")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008437")
    void case_UTAPI_008437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008437",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008437", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008437", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008437", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008437")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008438")
    void case_UTAPI_008438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008438",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008438", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008438", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008438", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008438")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008439")
    void case_UTAPI_008439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008439",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008439", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008439", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008439", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008439")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008440")
    void case_UTAPI_008440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008440",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008440", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008440", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008440", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008440")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008441")
    void case_UTAPI_008441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008441",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008441", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008441", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008441", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008441")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008442")
    void case_UTAPI_008442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008442",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008442", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008442", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008442", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008442")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008443")
    void case_UTAPI_008443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008443",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008443", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008443", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008443", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008443")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008444")
    void case_UTAPI_008444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008444",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008444", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008444", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008444", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008444")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008445")
    void case_UTAPI_008445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008445",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008445", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008445", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008445", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008445")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008446")
    void case_UTAPI_008446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008446",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008446", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008446", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008446", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008446")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008447")
    void case_UTAPI_008447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008447",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008447", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008447", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008447", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008447")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008448")
    void case_UTAPI_008448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008448",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008448", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008448", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008448", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008448")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008449")
    void case_UTAPI_008449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008449",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008449", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008449")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008450")
    void case_UTAPI_008450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008450",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008450", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008450", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008450")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008451")
    void case_UTAPI_008451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008451",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008451", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008451", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008451")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008452")
    void case_UTAPI_008452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008452",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008452", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008452", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008452")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008453")
    void case_UTAPI_008453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008453",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008453", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008453", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008453")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008454")
    void case_UTAPI_008454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008454",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008454", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008454", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008454")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008455")
    void case_UTAPI_008455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008455",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008455", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008455", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008455")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008456")
    void case_UTAPI_008456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008456",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008456", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008456", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008456")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008457")
    void case_UTAPI_008457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008457",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008457", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008457", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008457")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008458")
    void case_UTAPI_008458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008458",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008458", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008458", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008458")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008459")
    void case_UTAPI_008459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008459",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008459", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008459", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008459")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008460")
    void case_UTAPI_008460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008460",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008460", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008460", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008460")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008461")
    void case_UTAPI_008461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008461",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008461", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008461", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008461")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008462")
    void case_UTAPI_008462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008462",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008462", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008462", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008462")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008463")
    void case_UTAPI_008463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008463",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008463", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008463", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008463")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008464")
    void case_UTAPI_008464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008464",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008464", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008464", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008464")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008465")
    void case_UTAPI_008465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008465",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008465", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008465")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008466")
    void case_UTAPI_008466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008466",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008466", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008466")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008467")
    void case_UTAPI_008467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008467",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008467", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008467")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008468")
    void case_UTAPI_008468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008468",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008468", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008468")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008469")
    void case_UTAPI_008469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008469",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008469", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008469")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008470")
    void case_UTAPI_008470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008470",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008470", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008470")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008471")
    void case_UTAPI_008471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008471",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008471", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008471")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008472")
    void case_UTAPI_008472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008472",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008472", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008472")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008473")
    void case_UTAPI_008473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008473",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008473", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008473")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008474")
    void case_UTAPI_008474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008474",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008474", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008474", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008474")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008475")
    void case_UTAPI_008475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008475",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008475", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008475", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008475")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008476")
    void case_UTAPI_008476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008476",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008476", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008476", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008476")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008477")
    void case_UTAPI_008477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008477",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008477", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008477", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008477")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008478")
    void case_UTAPI_008478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008478",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008478", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008478")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008479")
    void case_UTAPI_008479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008479",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008479", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008479")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008480")
    void case_UTAPI_008480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008480",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008480", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008480")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008481")
    void case_UTAPI_008481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008481",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008481", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008481")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008482")
    void case_UTAPI_008482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008482",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008482", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008482")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008483")
    void case_UTAPI_008483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008483",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008483", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008483")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008484")
    void case_UTAPI_008484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008484",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008484", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008484")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008485")
    void case_UTAPI_008485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008485",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008485", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008485")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008486")
    void case_UTAPI_008486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008486",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008486", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008486")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008487")
    void case_UTAPI_008487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008487",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008487", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008487")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008488")
    void case_UTAPI_008488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008488",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008488", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008488")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008489")
    void case_UTAPI_008489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008489",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008489", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008489")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008490")
    void case_UTAPI_008490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008490",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008490", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008490")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008491")
    void case_UTAPI_008491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008491",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008491", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008491")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008492")
    void case_UTAPI_008492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008492",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008492", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008492")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008493")
    void case_UTAPI_008493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008493",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008493", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008493", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008493", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008493")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008494")
    void case_UTAPI_008494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008494",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008494", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008494", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008494", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008494")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008495")
    void case_UTAPI_008495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008495",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008495", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008495", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008495", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008495")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008496")
    void case_UTAPI_008496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008496",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008496", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008496", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008496")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008497")
    void case_UTAPI_008497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008497",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008497", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008497", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008497", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008497")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008498")
    void case_UTAPI_008498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008498",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008498", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008498", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008498", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008498")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008499")
    void case_UTAPI_008499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008499",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008499", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008499", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008499", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008499")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008500")
    void case_UTAPI_008500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008500",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008500", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008500", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008500", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008500")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008501")
    void case_UTAPI_008501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008501",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008501", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008501", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008501", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008501")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008502")
    void case_UTAPI_008502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008502",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008502", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008502", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008502", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008502")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008503")
    void case_UTAPI_008503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008503",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008503", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008503", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008503", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008503")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008504")
    void case_UTAPI_008504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008504",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008504", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008504", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008504", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008504")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008505")
    void case_UTAPI_008505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008505",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008505", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008505", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008505", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008505")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008506")
    void case_UTAPI_008506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008506",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008506", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008506", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008506", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008506")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008507")
    void case_UTAPI_008507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008507",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008507", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008507", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008507", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008507")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008508")
    void case_UTAPI_008508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008508",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008508", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008508", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008508", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008508")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008509")
    void case_UTAPI_008509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008509",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008509", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008509", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008509", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008509")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008510")
    void case_UTAPI_008510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008510",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008510", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008510", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008510", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008510")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008511")
    void case_UTAPI_008511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008511",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008511", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008511", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008511", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008511")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008512")
    void case_UTAPI_008512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008512",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008512", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008512", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008512", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008512")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008513")
    void case_UTAPI_008513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008513",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008513", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008513", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008513", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008513")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008514")
    void case_UTAPI_008514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008514",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008514", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008514", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008514")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008515")
    void case_UTAPI_008515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008515",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008515", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008515", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008515")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008516")
    void case_UTAPI_008516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008516",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008516", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008516", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008516")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008517")
    void case_UTAPI_008517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008517",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008517", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008517", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008517")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008518")
    void case_UTAPI_008518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008518",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008518", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008518", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008518")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008519")
    void case_UTAPI_008519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008519",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008519", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008519", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008519")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008520")
    void case_UTAPI_008520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008520",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008520", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008520", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008520")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008521")
    void case_UTAPI_008521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008521",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008521", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008521", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008521")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008522")
    void case_UTAPI_008522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008522",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008522", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008522")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008523")
    void case_UTAPI_008523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008523",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008523", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008523")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008524")
    void case_UTAPI_008524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008524",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008524", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008524")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008525")
    void case_UTAPI_008525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008525",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008525", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008525", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008525")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008526")
    void case_UTAPI_008526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008526",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008526", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008526", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008526")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008527")
    void case_UTAPI_008527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008527",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008527", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008527", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008527")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008528")
    void case_UTAPI_008528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008528",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008528", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008528", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008528")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008529")
    void case_UTAPI_008529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008529",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008529", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008529", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008529")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008530")
    void case_UTAPI_008530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008530",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008530", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008530", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008530")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008531")
    void case_UTAPI_008531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008531",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008531", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008531", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008531")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008532")
    void case_UTAPI_008532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008532",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008532", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008532", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008532")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008533")
    void case_UTAPI_008533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008533",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008533", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008533", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008533", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008533")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008534")
    void case_UTAPI_008534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008534",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008534", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008534", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008534", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008534")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008535")
    void case_UTAPI_008535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008535",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008535", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008535", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008535", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008535")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008536")
    void case_UTAPI_008536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008536",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008536", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008536", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008536", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008536")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008537")
    void case_UTAPI_008537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008537",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008537", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008537", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008537", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008537")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008538")
    void case_UTAPI_008538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008538",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008538", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008538", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008538", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008538")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008539")
    void case_UTAPI_008539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008539",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008539", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008539", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008539", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008539")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008540")
    void case_UTAPI_008540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008540",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008540", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008540", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008540", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008540")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008541")
    void case_UTAPI_008541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008541",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008541", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008541", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008541", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008541")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008542")
    void case_UTAPI_008542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008542",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008542", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008542", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008542", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008542")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008543")
    void case_UTAPI_008543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008543",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008543", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008543", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008543", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008543")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008544")
    void case_UTAPI_008544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008544",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008544", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008544", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008544", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008544")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008545")
    void case_UTAPI_008545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008545",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008545", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008545", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008545", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008545")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008546")
    void case_UTAPI_008546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008546",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008546", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008546", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008546", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008546")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008547")
    void case_UTAPI_008547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008547",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008547", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008547", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008547", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008547")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008548")
    void case_UTAPI_008548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008548",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008548", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008548", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008548", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008548")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008549")
    void case_UTAPI_008549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008549",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008549", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008549", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008549", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008549")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008550")
    void case_UTAPI_008550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008550",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008550", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008550", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008550", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008550")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008551")
    void case_UTAPI_008551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008551",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008551", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008551", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008551", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008551")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008552")
    void case_UTAPI_008552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008552",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008552", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008552", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008552", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008552")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008553")
    void case_UTAPI_008553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008553",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008553", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008553", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008553", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008553")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008554")
    void case_UTAPI_008554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008554",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008554", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008554", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008554")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008555")
    void case_UTAPI_008555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008555",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008555", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008555", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008555")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008556")
    void case_UTAPI_008556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008556",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008556", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008556", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008556")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008557")
    void case_UTAPI_008557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008557",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008557", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008557", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008557")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008558")
    void case_UTAPI_008558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008558",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008558", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008558", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008558")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008559")
    void case_UTAPI_008559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008559",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008559", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008559", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008559")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008560")
    void case_UTAPI_008560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008560",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008560", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008560", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008560")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008561")
    void case_UTAPI_008561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008561",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008561", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008561", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008561")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008562")
    void case_UTAPI_008562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008562",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008562", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008562", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008562")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008563")
    void case_UTAPI_008563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008563",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008563", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008563", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008563")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008564")
    void case_UTAPI_008564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008564",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008564", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008564", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008564")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008565")
    void case_UTAPI_008565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008565",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008565", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008565", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008565")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008566")
    void case_UTAPI_008566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008566",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008566", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008566", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008566")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008567")
    void case_UTAPI_008567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008567",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008567", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008567", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008567", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008567")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008568")
    void case_UTAPI_008568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008568",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008568", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008568", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008568", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008568")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008569")
    void case_UTAPI_008569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008569",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008569", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008569", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008569", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008569")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008570")
    void case_UTAPI_008570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008570",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008570", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008570", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008570", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008570")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008571")
    void case_UTAPI_008571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008571",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008571", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008571", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008571")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008572")
    void case_UTAPI_008572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008572",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008572", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008572", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008572")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008573")
    void case_UTAPI_008573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008573",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008573", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008573", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008573")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008574")
    void case_UTAPI_008574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008574",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008574", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008574", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008574")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008575")
    void case_UTAPI_008575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008575",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008575", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008575")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008576")
    void case_UTAPI_008576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008576",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008576", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008576")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008577")
    void case_UTAPI_008577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008577",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008577", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008577", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008577")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008578")
    void case_UTAPI_008578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008578",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008578", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008578", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008578")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008579")
    void case_UTAPI_008579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008579",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008579", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008579", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008579")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008580")
    void case_UTAPI_008580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008580",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008580", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008580", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008580")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008581")
    void case_UTAPI_008581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008581",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008581", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008581", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008581")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008582")
    void case_UTAPI_008582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008582",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008582", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008582", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008582", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008582")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008583")
    void case_UTAPI_008583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008583",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008583", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008583", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008583", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008583")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008584")
    void case_UTAPI_008584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008584",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008584", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008584", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008584", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008584")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008585")
    void case_UTAPI_008585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008585",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "restoreHistory",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008585", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008585", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008585", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008585")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::restoreHistory::4::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

}

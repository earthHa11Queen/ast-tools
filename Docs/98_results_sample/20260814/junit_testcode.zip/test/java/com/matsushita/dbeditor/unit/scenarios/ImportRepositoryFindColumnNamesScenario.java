package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportRepository#findColumnNames.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportRepositoryFindColumnNamesScenario {

    @Test
    @DisplayName("UTAPI-006625")
    void case_UTAPI_006625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006625",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006625", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006625")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006626")
    void case_UTAPI_006626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006626",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006626", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006626", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006626")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006627")
    void case_UTAPI_006627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006627",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006627", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006627", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006627")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006628")
    void case_UTAPI_006628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006628",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006628", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006628", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006628")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006629")
    void case_UTAPI_006629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006629",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006629", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006629")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006630")
    void case_UTAPI_006630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006630",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006630", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006630", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006630")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006631")
    void case_UTAPI_006631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006631",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006631", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006631", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006631")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006632")
    void case_UTAPI_006632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006632",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006632", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006632", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006632")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006633")
    void case_UTAPI_006633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006633",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006633", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006633", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006633")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006634")
    void case_UTAPI_006634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006634",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006634", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006634")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006635")
    void case_UTAPI_006635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006635",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006635", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006635")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006636")
    void case_UTAPI_006636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006636",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006636", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006636")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006637")
    void case_UTAPI_006637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006637",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006637", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006637")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006638")
    void case_UTAPI_006638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006638",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006638", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006638", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006638")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006639")
    void case_UTAPI_006639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006639",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006639", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006639", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006639")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006640")
    void case_UTAPI_006640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006640",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006640", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006640", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006640")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006641")
    void case_UTAPI_006641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006641",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006641", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006641", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006641")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006642")
    void case_UTAPI_006642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006642",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006642", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006642", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006642")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006643")
    void case_UTAPI_006643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006643",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006643", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006643", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006643")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006644")
    void case_UTAPI_006644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006644",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006644", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006644", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006644")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006645")
    void case_UTAPI_006645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006645",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006645", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006645", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006645")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006646")
    void case_UTAPI_006646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006646",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006646", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006646", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006646")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006647")
    void case_UTAPI_006647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006647",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006647", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006647", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006647")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006648")
    void case_UTAPI_006648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006648",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006648", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006648", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006648")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006649")
    void case_UTAPI_006649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006649",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006649", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006649", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006649")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006650")
    void case_UTAPI_006650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006650",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006650", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006650")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006651")
    void case_UTAPI_006651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006651",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006651", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006651")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006652")
    void case_UTAPI_006652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006652",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006652", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006652")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006653")
    void case_UTAPI_006653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006653",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006653", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006653")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006654")
    void case_UTAPI_006654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006654",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006654", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006654")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006655")
    void case_UTAPI_006655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006655",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006655", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006655", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006655")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006656")
    void case_UTAPI_006656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006656",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006656", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006656", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006656")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006657")
    void case_UTAPI_006657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006657",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006657", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006657", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006657", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006657")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006658")
    void case_UTAPI_006658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006658",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006658", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006658", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006658", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006658")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006659")
    void case_UTAPI_006659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006659",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006659", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006659", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006659", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006659")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006660")
    void case_UTAPI_006660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006660",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006660", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006660", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006660", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006660")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006661")
    void case_UTAPI_006661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006661",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006661", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006661", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006661")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006662")
    void case_UTAPI_006662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006662",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006662", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006662", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006662")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006663")
    void case_UTAPI_006663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006663",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006663", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006663", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006663")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006664")
    void case_UTAPI_006664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006664",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006664", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006664", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006664")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006665")
    void case_UTAPI_006665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006665",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006665", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006665", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006665")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006666")
    void case_UTAPI_006666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006666",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006666", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006666", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006666")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006667")
    void case_UTAPI_006667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006667",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006667", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006667", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006667")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006668")
    void case_UTAPI_006668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006668",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006668", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006668", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006668")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006669")
    void case_UTAPI_006669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006669",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006669", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006669", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006669")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006670")
    void case_UTAPI_006670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006670",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006670", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006670", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006670")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006671")
    void case_UTAPI_006671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006671",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006671", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006671", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006671")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006672")
    void case_UTAPI_006672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006672",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006672", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006672", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006672")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006673")
    void case_UTAPI_006673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006673",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006673", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006673", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006673")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006674")
    void case_UTAPI_006674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006674",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006674", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006674", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006674")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006675")
    void case_UTAPI_006675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006675",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006675", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006675", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006675")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006676")
    void case_UTAPI_006676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006676",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006676", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006676", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006676")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006677")
    void case_UTAPI_006677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006677",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006677", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006677", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006677")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006678")
    void case_UTAPI_006678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006678",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006678", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006678", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006678", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006678")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006679")
    void case_UTAPI_006679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006679",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006679", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006679", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006679")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006680")
    void case_UTAPI_006680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006680",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006680", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006680", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006680")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006681")
    void case_UTAPI_006681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006681",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006681", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006681")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006682")
    void case_UTAPI_006682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006682",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006682", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006682")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006683")
    void case_UTAPI_006683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006683",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006683", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006683")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006684")
    void case_UTAPI_006684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006684",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006684", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006684", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006684")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006685")
    void case_UTAPI_006685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006685",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006685", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006685", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006685")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006686")
    void case_UTAPI_006686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006686",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006686", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006686", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006686")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006687")
    void case_UTAPI_006687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006687",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006687", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006687", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006687", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006687", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006687", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006687")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006688")
    void case_UTAPI_006688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006688",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006688", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006688", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006688", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006688", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006688", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006688")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006689")
    void case_UTAPI_006689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006689",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006689", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006689", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006689", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006689", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006689", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006689")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006690")
    void case_UTAPI_006690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006690",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006690", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006690", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006690", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006690", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006690", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006690")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006691")
    void case_UTAPI_006691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006691",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006691", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006691", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006691", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006691", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006691", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006691")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006692")
    void case_UTAPI_006692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006692",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006692", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006692", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006692", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006692", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006692", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006692")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006693")
    void case_UTAPI_006693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006693",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006693", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006693", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006693", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006693", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006693", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006693")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006694")
    void case_UTAPI_006694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006694",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006694", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006694", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006694", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006694", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006694", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006694")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006695")
    void case_UTAPI_006695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006695",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006695", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006695", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006695", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006695", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006695", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006695", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006695")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006696")
    void case_UTAPI_006696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006696",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006696", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006696", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006696", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006696", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006696", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006696", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006696")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006697")
    void case_UTAPI_006697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006697",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006697", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006697", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006697", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006697", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006697", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006697", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006697")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006698")
    void case_UTAPI_006698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006698",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006698", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006698", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006698", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006698", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006698", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006698")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006699")
    void case_UTAPI_006699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006699",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006699", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006699", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006699", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006699", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006699", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006699")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006700")
    void case_UTAPI_006700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006700",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006700", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006700", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006700", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006700", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006700", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006700", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006700")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006701")
    void case_UTAPI_006701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006701",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006701", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006701", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006701", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006701", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006701", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006701", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006701")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006702")
    void case_UTAPI_006702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006702",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006702", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006702", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006702", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006702", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006702", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006702", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006702")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006703")
    void case_UTAPI_006703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006703",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006703", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006703", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006703", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006703", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006703", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006703", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006703")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006704")
    void case_UTAPI_006704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006704",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006704", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006704", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006704", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006704", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006704", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006704", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006704")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006705")
    void case_UTAPI_006705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006705",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006705", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006705", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006705", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006705", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006705", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006705")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006706")
    void case_UTAPI_006706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006706",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006706", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006706", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006706", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006706", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006706", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006706")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006707")
    void case_UTAPI_006707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006707",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006707", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006707", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006707", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006707", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006707", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006707")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006708")
    void case_UTAPI_006708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006708",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006708", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006708", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006708", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006708", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006708", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006708")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006709")
    void case_UTAPI_006709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006709",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006709", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006709", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006709", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006709", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006709", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006709")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006710")
    void case_UTAPI_006710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006710",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006710", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006710", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006710", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006710", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006710", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006710")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006711")
    void case_UTAPI_006711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006711",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006711", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006711", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006711", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006711", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006711", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006711")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006712")
    void case_UTAPI_006712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006712",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006712", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006712", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006712", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006712", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006712", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006712")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006713")
    void case_UTAPI_006713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006713",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006713", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006713", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006713", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006713", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006713", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006713")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006714")
    void case_UTAPI_006714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006714",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006714", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006714", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006714", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006714", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006714", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006714")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006715")
    void case_UTAPI_006715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006715",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006715", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006715")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006716")
    void case_UTAPI_006716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006716",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006716", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006716")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006717")
    void case_UTAPI_006717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006717",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006717", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006717")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006718")
    void case_UTAPI_006718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006718",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006718", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006718")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006719")
    void case_UTAPI_006719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006719",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006719", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006719", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006719", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006719")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006720")
    void case_UTAPI_006720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006720",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006720", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006720", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006720", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006720")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006721")
    void case_UTAPI_006721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006721",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006721", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006721", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006721", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006721")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006722")
    void case_UTAPI_006722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006722",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006722", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006722", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006722", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006722")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006723")
    void case_UTAPI_006723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006723",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006723", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006723", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006723", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006723")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006724")
    void case_UTAPI_006724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006724",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006724", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006724", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006724", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006724")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006725")
    void case_UTAPI_006725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006725",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006725", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006725", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006725", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006725")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006726")
    void case_UTAPI_006726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006726",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006726", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006726", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006726", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006726", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006726", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006726", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006726", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006726")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006727")
    void case_UTAPI_006727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006727",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006727", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006727", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006727", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006727", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006727", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006727", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006727")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006728")
    void case_UTAPI_006728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006728",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006728", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006728", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006728", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006728", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006728", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006728", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006728")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006729")
    void case_UTAPI_006729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006729",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006729", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006729", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006729", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006729", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006729", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006729", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006729")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006730")
    void case_UTAPI_006730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006730",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006730", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006730", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006730", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006730", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006730", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006730", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006730")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006731")
    void case_UTAPI_006731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006731",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006731", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006731", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006731", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006731", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006731", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006731", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006731")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006732")
    void case_UTAPI_006732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006732",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006732", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006732", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006732", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006732", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006732", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006732", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006732")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006733")
    void case_UTAPI_006733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006733",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006733", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006733", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006733", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006733", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006733", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006733")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006734")
    void case_UTAPI_006734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006734",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006734", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006734", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006734", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006734", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006734", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006734")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006735")
    void case_UTAPI_006735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006735",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006735", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006735", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006735", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006735", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006735", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006735")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006736")
    void case_UTAPI_006736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006736",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006736", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006736", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006736", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006736", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006736", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006736")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006737")
    void case_UTAPI_006737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006737",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006737", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006737", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006737", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006737", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006737", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006737")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006738")
    void case_UTAPI_006738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006738",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006738", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006738", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006738", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006738", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006738", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006738")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006739")
    void case_UTAPI_006739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006739",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006739", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006739", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006739", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006739", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006739", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006739")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006740")
    void case_UTAPI_006740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006740",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006740", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006740", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006740", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006740", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006740", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006740")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006741")
    void case_UTAPI_006741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006741",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006741", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006741", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006741", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006741", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006741", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006741", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006741")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006742")
    void case_UTAPI_006742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006742",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006742", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006742", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006742", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006742", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006742", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006742", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006742")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006743")
    void case_UTAPI_006743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006743",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006743", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006743", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006743", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006743", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006743", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006743", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006743")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006744")
    void case_UTAPI_006744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006744",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006744", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006744", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006744", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006744", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006744", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006744", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006744")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006745")
    void case_UTAPI_006745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006745",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006745", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006745", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006745", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006745", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006745", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006745", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006745")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006746")
    void case_UTAPI_006746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006746",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006746", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006746", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006746", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006746", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006746", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006746")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006747")
    void case_UTAPI_006747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006747",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006747", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006747", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006747", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006747")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006748")
    void case_UTAPI_006748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006748",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006748", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006748", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006748", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006748")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006749")
    void case_UTAPI_006749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006749",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006749", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006749", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006749", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006749")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006750")
    void case_UTAPI_006750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006750",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006750", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006750", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006750", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006750")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006751")
    void case_UTAPI_006751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006751",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006751", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006751", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006751", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006751")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006752")
    void case_UTAPI_006752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006752",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006752", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006752", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006752", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006752")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006753")
    void case_UTAPI_006753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006753",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006753", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006753", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006753", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006753")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006754")
    void case_UTAPI_006754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006754",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006754", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006754", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006754", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006754")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006755")
    void case_UTAPI_006755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006755",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006755", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006755", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006755", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006755")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006756")
    void case_UTAPI_006756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006756",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006756", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006756", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006756", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006756")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006757")
    void case_UTAPI_006757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006757",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006757", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006757", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006757", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006757")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006758")
    void case_UTAPI_006758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006758",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006758", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006758", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006758", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006758", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006758")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006759")
    void case_UTAPI_006759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006759",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006759", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006759", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006759", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006759", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006759")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006760")
    void case_UTAPI_006760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006760",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006760", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006760", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006760", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006760")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006761")
    void case_UTAPI_006761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006761",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006761", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006761", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006761", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006761")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006762")
    void case_UTAPI_006762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006762",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006762", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006762", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006762", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006762")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006763")
    void case_UTAPI_006763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006763",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006763", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006763", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006763", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006763")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006764")
    void case_UTAPI_006764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006764",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006764", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006764", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006764", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006764")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006765")
    void case_UTAPI_006765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006765",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006765", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006765", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006765", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006765")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006766")
    void case_UTAPI_006766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006766",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006766", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006766", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006766", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006766")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006767")
    void case_UTAPI_006767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006767",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006767", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006767", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006767", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006767")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006768")
    void case_UTAPI_006768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006768",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006768", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006768", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006768", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006768")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006769")
    void case_UTAPI_006769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006769",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006769", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006769", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006769", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006769")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006770")
    void case_UTAPI_006770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006770",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006770", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006770", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006770", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006770")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006771")
    void case_UTAPI_006771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006771",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006771", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006771", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006771", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006771")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006772")
    void case_UTAPI_006772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006772",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006772", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006772", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006772")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006773")
    void case_UTAPI_006773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006773",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006773", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006773", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006773")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006774")
    void case_UTAPI_006774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006774",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006774", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006774", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006774")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006775")
    void case_UTAPI_006775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006775",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006775", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006775", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006775")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006776")
    void case_UTAPI_006776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006776",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006776", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006776", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006776", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006776", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006776", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006776", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006776")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006777")
    void case_UTAPI_006777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006777",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006777", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006777", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006777", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006777", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006777", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006777")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006778")
    void case_UTAPI_006778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006778",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006778", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006778", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006778", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006778", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006778", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006778")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006779")
    void case_UTAPI_006779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006779",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006779", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006779", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006779", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006779", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006779", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006779")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006780")
    void case_UTAPI_006780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006780",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006780", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006780", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006780", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006780", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006780", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006780")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006781")
    void case_UTAPI_006781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006781",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006781", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006781", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006781", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006781", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006781", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006781")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006782")
    void case_UTAPI_006782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006782",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006782", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006782", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006782", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006782", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006782", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006782")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006783")
    void case_UTAPI_006783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006783",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006783", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006783", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006783", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006783", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006783", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006783")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006784")
    void case_UTAPI_006784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006784",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006784", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006784", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006784", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006784", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006784", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006784")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006785")
    void case_UTAPI_006785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006785",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006785", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006785", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006785", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006785", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006785", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006785")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006786")
    void case_UTAPI_006786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006786",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006786", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006786", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006786", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006786", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006786", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006786")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006787")
    void case_UTAPI_006787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006787",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006787", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006787", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006787", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006787", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006787", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006787")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006788")
    void case_UTAPI_006788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006788",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006788", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006788", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006788", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006788", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006788", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006788")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006789")
    void case_UTAPI_006789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006789",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006789", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006789", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006789", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006789", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006789")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006790")
    void case_UTAPI_006790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006790",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006790", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006790", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006790", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006790")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006791")
    void case_UTAPI_006791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006791",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006791", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006791", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006791", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006791")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006792")
    void case_UTAPI_006792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006792",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006792", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006792", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006792", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006792")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006793")
    void case_UTAPI_006793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006793",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006793", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006793", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006793", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006793")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006794")
    void case_UTAPI_006794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006794",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006794", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006794", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006794", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006794")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006795")
    void case_UTAPI_006795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006795",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006795", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006795", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006795", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006795")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006796")
    void case_UTAPI_006796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006796",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006796", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006796", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006796", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006796")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006797")
    void case_UTAPI_006797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006797",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006797", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006797", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006797", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006797")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006798")
    void case_UTAPI_006798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006798",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006798", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006798", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006798")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006799")
    void case_UTAPI_006799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006799",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006799", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006799", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006799")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006800")
    void case_UTAPI_006800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006800",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006800", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006800", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006800")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006801")
    void case_UTAPI_006801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006801",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006801", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006801", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006801")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006802")
    void case_UTAPI_006802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006802",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006802", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006802", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006802")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006803")
    void case_UTAPI_006803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006803",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006803", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006803", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006803")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006804")
    void case_UTAPI_006804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006804",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006804", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006804", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006804")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006805")
    void case_UTAPI_006805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006805",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006805", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006805", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006805")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006806")
    void case_UTAPI_006806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006806",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006806", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006806", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006806")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006807")
    void case_UTAPI_006807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006807",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006807", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006807", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006807")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

}

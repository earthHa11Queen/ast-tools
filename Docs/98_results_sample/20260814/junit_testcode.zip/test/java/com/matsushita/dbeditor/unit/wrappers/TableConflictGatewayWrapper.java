package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableConflictGateway.
 */
public final class TableConflictGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway";
    private static final String[] DEP_NAMES = new String[] {"targetDatabaseConnector"};
    private static final String[] DEP_TYPES = new String[] {"TargetDatabaseConnector"};
    private static final String[] TYPES_applyToReal = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_calcDiff = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_createBackup = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_hasConflict = new String[] {"ConnectionSetting", "String", "String"};

    public TableConflictGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void applyToReal(setting, schemaName, tableName) */
    public ExecutionResult applyToReal(Object[] args) {
        return invoke("applyToReal", TYPES_applyToReal, args);
    }

    /** List<Map<String,Object>> calcDiff(setting, schemaName, tableName) */
    public ExecutionResult calcDiff(Object[] args) {
        return invoke("calcDiff", TYPES_calcDiff, args);
    }

    /** void createBackup(setting, schemaName, tableName) */
    public ExecutionResult createBackup(Object[] args) {
        return invoke("createBackup", TYPES_createBackup, args);
    }

    /** boolean hasConflict(setting, schemaName, tableName) */
    public ExecutionResult hasConflict(Object[] args) {
        return invoke("hasConflict", TYPES_hasConflict, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("applyToReal".equals(operation)) {
            return applyToReal(args);
        } else if ("calcDiff".equals(operation)) {
            return calcDiff(args);
        } else if ("createBackup".equals(operation)) {
            return createBackup(args);
        } else if ("hasConflict".equals(operation)) {
            return hasConflict(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

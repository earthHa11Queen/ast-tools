package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableMetadataResponse.
 */
public final class TableMetadataResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse";
    private static final String[] DEP_NAMES = new String[] {"schemaName", "tableName", "tableType"};
    private static final String[] DEP_TYPES = new String[] {"String", "String", "String"};
    private static final String[] TYPES_fromEntity = new String[] {"TableMetadata"};

    public TableMetadataResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** TableMetadataResponse fromEntity(entity) */
    public ExecutionResult fromEntity(Object[] args) {
        return invoke("fromEntity", TYPES_fromEntity, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("fromEntity".equals(operation)) {
            return fromEntity(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

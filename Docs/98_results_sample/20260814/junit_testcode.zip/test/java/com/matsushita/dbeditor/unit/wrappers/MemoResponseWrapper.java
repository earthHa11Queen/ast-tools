package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for MemoResponse.
 */
public final class MemoResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.MemoResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.MemoResponse";
    private static final String[] DEP_NAMES = new String[] {"connectionId", "tableName", "content"};
    private static final String[] DEP_TYPES = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_empty = new String[] {"Integer", "String"};
    private static final String[] TYPES_fromEntity = new String[] {"TableMemo"};

    public MemoResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** MemoResponse empty(connectionId, tableName) */
    public ExecutionResult empty(Object[] args) {
        return invoke("empty", TYPES_empty, args);
    }

    /** MemoResponse fromEntity(memo) */
    public ExecutionResult fromEntity(Object[] args) {
        return invoke("fromEntity", TYPES_fromEntity, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("empty".equals(operation)) {
            return empty(args);
        } else if ("fromEntity".equals(operation)) {
            return fromEntity(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

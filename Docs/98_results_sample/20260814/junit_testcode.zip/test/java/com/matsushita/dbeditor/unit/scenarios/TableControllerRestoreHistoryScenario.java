package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#restoreHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerRestoreHistoryScenario {

    @Test
    @DisplayName("UTAPI-001566")
    void case_UTAPI_001566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001566",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001566", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001566", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001566", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001566", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001567")
    void case_UTAPI_001567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001567",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001567", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001567", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001567", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001567", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001568")
    void case_UTAPI_001568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001568",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001568", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001568", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001568", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001568", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001569")
    void case_UTAPI_001569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001569",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001569", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001569", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001569", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001569", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001570")
    void case_UTAPI_001570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001570",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001570", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001570", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001570", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001570", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001571")
    void case_UTAPI_001571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001571",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001571", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001571", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001571", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001571", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001572")
    void case_UTAPI_001572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001572",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001572", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001572", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001572", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001572", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001573")
    void case_UTAPI_001573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001573",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001573", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001573", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001573", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001573", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001574")
    void case_UTAPI_001574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001574",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001574", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001574", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001574", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001574", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001575")
    void case_UTAPI_001575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001575",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001575", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001575", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001575", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001575", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001576")
    void case_UTAPI_001576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001576",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001576", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001576", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001576", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001576", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001577")
    void case_UTAPI_001577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001577",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001577", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001577", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001577", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001577", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001578")
    void case_UTAPI_001578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001578",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001578", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001578", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001578", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001578", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001579")
    void case_UTAPI_001579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001579",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001579", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001579", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001579", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001579", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001580")
    void case_UTAPI_001580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001580",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001580", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001580", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001580", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001580", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001581")
    void case_UTAPI_001581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001581",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001581", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001581", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001581", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001581", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001582")
    void case_UTAPI_001582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001582",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001582", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001582", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001582", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001582", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001583")
    void case_UTAPI_001583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001583",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001583", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001583", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001583", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001583", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001584")
    void case_UTAPI_001584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001584",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001584", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001584", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001584", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001584", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001585")
    void case_UTAPI_001585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001585",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001585", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001585", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001585", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001585", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001586")
    void case_UTAPI_001586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001586",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001586", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001586", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001586", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001586", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001587")
    void case_UTAPI_001587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001587",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001587", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001587", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001587", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001587", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001588")
    void case_UTAPI_001588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001588",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001588", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001588", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001588", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001588", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001589")
    void case_UTAPI_001589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001589",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001589", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001589", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001589", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001589", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001590")
    void case_UTAPI_001590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001590",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001590", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001590", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001590", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001590", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001591")
    void case_UTAPI_001591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001591",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001591", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001591", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001591", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001591", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001592")
    void case_UTAPI_001592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001592",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001592", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001592", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001592", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001592", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001593")
    void case_UTAPI_001593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001593",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001593", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001593", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001593", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001593", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001594")
    void case_UTAPI_001594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001594",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001594", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001594", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001594", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001594", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001595")
    void case_UTAPI_001595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001595",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001595", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001595", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001595", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001595", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001596")
    void case_UTAPI_001596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001596",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001596", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001596", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001596", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001596", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001597")
    void case_UTAPI_001597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001597",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001597", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001597", "seq", "TARGET", "NUMBER", "int"),
                    new DataRef("UTAPI-001597", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001597", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::2::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001598")
    void case_UTAPI_001598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001598",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001598", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001598", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001598", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001598", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001599")
    void case_UTAPI_001599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001599",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001599", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001599", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001599", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001599", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001600")
    void case_UTAPI_001600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001600",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001600", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001600", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001600", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001600", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001601")
    void case_UTAPI_001601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001601",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001601", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001601", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001601", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001601", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001602")
    void case_UTAPI_001602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001602",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001602", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001602", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001602", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001602", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001603")
    void case_UTAPI_001603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001603",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001603", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001603", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001603", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001603", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001604")
    void case_UTAPI_001604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001604",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001604", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001604", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001604", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001604", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001605")
    void case_UTAPI_001605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001605",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001605", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001605", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001605", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001605", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001606")
    void case_UTAPI_001606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001606",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001606", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001606", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001606", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001606", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001607")
    void case_UTAPI_001607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001607",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001607", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001607", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001607", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001607", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001608")
    void case_UTAPI_001608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001608",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001608", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001608", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001608", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001608", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::3::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001609")
    void case_UTAPI_001609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001609",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001609", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001609", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001609", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001609", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001610")
    void case_UTAPI_001610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001610",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001610", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001610", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001610", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001610", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001611")
    void case_UTAPI_001611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001611",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001611", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001611", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001611", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001611", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001612")
    void case_UTAPI_001612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001612",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001612", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001612", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001612", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001612", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001613")
    void case_UTAPI_001613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001613",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001613", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001613", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001613", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001613", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001614")
    void case_UTAPI_001614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001614",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001614", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001614", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001614", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001614", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001615")
    void case_UTAPI_001615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001615",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001615", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001615", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001615", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001615", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001616")
    void case_UTAPI_001616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001616",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001616", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001616", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001616", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001616", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001617")
    void case_UTAPI_001617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001617",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001617", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001617", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001617", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001617", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001618")
    void case_UTAPI_001618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001618",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001618", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001618", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001618", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001618", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001619")
    void case_UTAPI_001619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001619",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001619", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001619", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001619", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001619", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001620")
    void case_UTAPI_001620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001620",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001620", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001620", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001620", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001620", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001621")
    void case_UTAPI_001621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001621",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001621", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001621", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001621", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001621", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001622")
    void case_UTAPI_001622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001622",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001622", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001622", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001622", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001622", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001623")
    void case_UTAPI_001623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001623",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001623", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001623", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001623", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001623", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001624")
    void case_UTAPI_001624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001624",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001624", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001624", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001624", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001624", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001625")
    void case_UTAPI_001625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001625",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001625", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001625", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001625", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001625", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001626")
    void case_UTAPI_001626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001626",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001626", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001626", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001626", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001626", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001627")
    void case_UTAPI_001627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001627",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001627", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001627", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001627", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001627", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001628")
    void case_UTAPI_001628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001628",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "restoreHistory",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("seq", "int", "seq"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001628", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001628", "seq", "NORMAL", "NUMBER", "int"),
                    new DataRef("UTAPI-001628", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001628", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::restoreHistory::9::ARG::4::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.restoreHistory")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.restoreHistory", "tableHistoryUseCase", "restoreHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.restoreHistory must carry the value generated for connectionId", "tableHistoryUseCase", "restoreHistory", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.restoreHistory must carry the value generated for schema", "tableHistoryUseCase", "restoreHistory", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.restoreHistory must carry the value generated for name", "tableHistoryUseCase", "restoreHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.restoreHistory must carry the value generated for seq", "tableHistoryUseCase", "restoreHistory", "3", "data:seq")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

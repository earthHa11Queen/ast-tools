package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#getAllRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseGetAllRecordsScenario {

    @Test
    @DisplayName("UTAPI-013375")
    void case_UTAPI_013375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013375",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013375", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013375", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013375")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013376")
    void case_UTAPI_013376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013376",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013376", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013376", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013376")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013377")
    void case_UTAPI_013377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013377",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013377", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013377", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013377")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013378")
    void case_UTAPI_013378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013378",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013378", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013378", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013378")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013379")
    void case_UTAPI_013379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013379",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013379", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013379", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013379")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013380")
    void case_UTAPI_013380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013380",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013380", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013380", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013380")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013381")
    void case_UTAPI_013381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013381",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013381", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013381", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013381")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013382")
    void case_UTAPI_013382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013382",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013382", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013382", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013382")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013383")
    void case_UTAPI_013383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013383",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013383", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013383", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013383")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013384")
    void case_UTAPI_013384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013384",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013384", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013384", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013384")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013385")
    void case_UTAPI_013385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013385",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013385", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013385", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013385")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013386")
    void case_UTAPI_013386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013386",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013386", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013386", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013386", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013386")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013387")
    void case_UTAPI_013387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013387",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013387", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013387", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013387", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013387")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013388")
    void case_UTAPI_013388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013388",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013388", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013388", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013388", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013388")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013389")
    void case_UTAPI_013389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013389",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013389", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013389", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013389", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013389")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013390")
    void case_UTAPI_013390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013390",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013390", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013390", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013390", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013390")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013391")
    void case_UTAPI_013391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013391",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013391", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013391", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013391", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013391")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013392")
    void case_UTAPI_013392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013392",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013392", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013392", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013392", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013392")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013393")
    void case_UTAPI_013393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013393",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013393", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013393", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013393", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013393")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013394")
    void case_UTAPI_013394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013394",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013394", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013394", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013394", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013394")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013395")
    void case_UTAPI_013395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013395",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013395", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013395", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013395", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013395")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013396")
    void case_UTAPI_013396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013396",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013396", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013396", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013396", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013396")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013397")
    void case_UTAPI_013397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013397",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013397", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013397", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013397", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013397")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013398")
    void case_UTAPI_013398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013398",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013398", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013398", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013398", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013398")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013399")
    void case_UTAPI_013399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013399",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013399", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013399", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013399", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013399")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013400")
    void case_UTAPI_013400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013400",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013400", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013400", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013400", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013400")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013401")
    void case_UTAPI_013401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013401",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013401", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013401", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013401", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013401")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013402")
    void case_UTAPI_013402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013402",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013402", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013402", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013402", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013402")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013403")
    void case_UTAPI_013403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013403",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013403", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013403", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013403", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013403")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013404")
    void case_UTAPI_013404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013404",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013404", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013404", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013404", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013404")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013405")
    void case_UTAPI_013405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013405",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013405", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013405", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013405", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013405")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013406")
    void case_UTAPI_013406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013406",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013406", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013406", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013406", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013406")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013407")
    void case_UTAPI_013407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013407",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013407", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013407", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013407", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013407")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013408")
    void case_UTAPI_013408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013408",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013408", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013408", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013408", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013408")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013409")
    void case_UTAPI_013409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013409",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013409", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013409", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013409", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013409")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013410")
    void case_UTAPI_013410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013410",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013410", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013410", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013410", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013410")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013411")
    void case_UTAPI_013411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013411",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013411", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013411", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013411", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013411")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013412")
    void case_UTAPI_013412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013412",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013412", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013412", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013412", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013412")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013413")
    void case_UTAPI_013413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013413",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013413", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013413", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013413", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013413")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013414")
    void case_UTAPI_013414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013414",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013414", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013414", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013414", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013414")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013415")
    void case_UTAPI_013415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013415",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013415", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013415", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013415", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013415")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013416")
    void case_UTAPI_013416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013416",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013416", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013416", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013416", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013416")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013417")
    void case_UTAPI_013417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013417",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013417", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013417", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013417", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013417")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013418")
    void case_UTAPI_013418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013418",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013418", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013418", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013418", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013418")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013419")
    void case_UTAPI_013419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013419",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013419", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013419", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013419", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013419")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013420")
    void case_UTAPI_013420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013420",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013420", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013420", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013420", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013420")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013421")
    void case_UTAPI_013421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013421",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013421", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013421", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013421", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013421")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013422")
    void case_UTAPI_013422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013422",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013422", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013422", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013422", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013422")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013423")
    void case_UTAPI_013423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013423",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013423", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013423", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013423", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013423")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013424")
    void case_UTAPI_013424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013424",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013424", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013424", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013424", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013424")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013425")
    void case_UTAPI_013425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013425",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013425", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013425", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013425", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013425")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013426")
    void case_UTAPI_013426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013426",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013426", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013426", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013426", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013426")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013427")
    void case_UTAPI_013427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013427",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013427", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013427", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013427", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013427")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findAllRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findAllRecords must carry the value generated for schemaName", "tableRecordRepository", "findAllRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.findAllRecords must carry the value generated for tableName", "tableRecordRepository", "findAllRecords", "2", "data:tableName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findAllRecords", "tableRecordRepository", "findAllRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

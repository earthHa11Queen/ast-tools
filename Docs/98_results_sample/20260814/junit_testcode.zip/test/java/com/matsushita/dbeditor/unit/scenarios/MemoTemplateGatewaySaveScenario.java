package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoTemplateGateway#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoTemplateGatewaySaveScenario {

    @Test
    @DisplayName("UTAPI-002872")
    void case_UTAPI_002872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002872",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002872", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002872", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002872", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002872", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002872", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002873")
    void case_UTAPI_002873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002873",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002873", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002873", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002873", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002873", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002873", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002874")
    void case_UTAPI_002874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002874",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002874", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002874", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002874", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002874", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002874", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002875")
    void case_UTAPI_002875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002875",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002875", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002875", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002875", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002875", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002875", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002876")
    void case_UTAPI_002876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002876",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002876", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002876", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002876", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002876", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002876", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002877")
    void case_UTAPI_002877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002877",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002877", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002877", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002877", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002877", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002877", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002878")
    void case_UTAPI_002878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002878",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002878", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002878", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002878", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002878", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002878", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002879")
    void case_UTAPI_002879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002879",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002879", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002879", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002879", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002879", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002879", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002880")
    void case_UTAPI_002880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002880",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002880", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002880", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002880", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002880", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002880", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002881")
    void case_UTAPI_002881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002881",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002881", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002881", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002881", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002881", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002881", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002882")
    void case_UTAPI_002882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002882",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002882", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002882", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002882", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002882", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002882", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002882")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002883")
    void case_UTAPI_002883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002883",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002883", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002883", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002883", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002883", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002883", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002883")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002884")
    void case_UTAPI_002884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002884",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002884", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002884", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002884", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002884", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002884", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002884")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002885")
    void case_UTAPI_002885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002885",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002885", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002885", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002885", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002885", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002885", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002885")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002886")
    void case_UTAPI_002886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002886",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002886", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002886", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002886", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002886", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002886", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002886")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002887")
    void case_UTAPI_002887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002887",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002887", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002887", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002887", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002887", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002887", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002887")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002888")
    void case_UTAPI_002888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002888",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002888", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002888", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002888", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002888", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002888", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002888")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002889")
    void case_UTAPI_002889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002889",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002889", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002889", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002889", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002889", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002889", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002889")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002890")
    void case_UTAPI_002890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002890",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002890", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002890", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002890", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002890", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002890", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002890")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002891")
    void case_UTAPI_002891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002891",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002891", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002891", "template.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002891", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002891", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002891", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002891")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002892")
    void case_UTAPI_002892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002892",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002892", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002892", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002892", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002892", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002892", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002892")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002893")
    void case_UTAPI_002893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002893",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002893", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002893", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002893", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002893", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002893", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002893")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002894")
    void case_UTAPI_002894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002894",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002894", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002894", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002894", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002894", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002894", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002894")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002895")
    void case_UTAPI_002895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002895",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002895", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002895", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002895", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002895", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002895", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002895")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002896")
    void case_UTAPI_002896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002896",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002896", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002896", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002896", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002896", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002896", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002896")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002897")
    void case_UTAPI_002897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002897",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002897", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002897", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002897", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002897", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002897", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002897")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002898")
    void case_UTAPI_002898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002898",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002898", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002898", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002898", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002898", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002898", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002898")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002899")
    void case_UTAPI_002899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002899",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002899", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002899", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002899", "template.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002899", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002899", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002899")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("template.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002900")
    void case_UTAPI_002900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002900",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002900", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002900", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002900", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002900", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002900", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002900")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002901")
    void case_UTAPI_002901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002901",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002901", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002901", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002901", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002901", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002901", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002901")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002902")
    void case_UTAPI_002902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002902",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002902", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002902", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002902", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002902", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002902", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002902")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002903")
    void case_UTAPI_002903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002903",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002903", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002903", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002903", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002903", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002903", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002903")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002904")
    void case_UTAPI_002904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002904",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002904", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002904", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002904", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002904", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002904", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002904")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002905")
    void case_UTAPI_002905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002905",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002905", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002905", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002905", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002905", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002905", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002905")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002906")
    void case_UTAPI_002906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002906",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002906", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002906", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002906", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002906", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002906", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002906")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002907")
    void case_UTAPI_002907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002907",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002907", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002907", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002907", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002907", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002907", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002907")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002908")
    void case_UTAPI_002908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002908",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002908", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002908", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002908", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002908", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002908", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002908")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002909")
    void case_UTAPI_002909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002909",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002909", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002909", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002909", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002909", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002909", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002909")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002910")
    void case_UTAPI_002910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002910",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002910", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002910", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002910", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002910", "template.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002910", "template.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002910")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("template.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002911")
    void case_UTAPI_002911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002911",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002911", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002911", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002911", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002911", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002911", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002911")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002912")
    void case_UTAPI_002912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002912",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002912", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002912", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002912", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002912", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002912", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002912")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002913")
    void case_UTAPI_002913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002913",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002913", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002913", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002913", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002913", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002913", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002913")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002914")
    void case_UTAPI_002914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002914",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002914", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002914", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002914", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002914", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002914", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002914")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002915")
    void case_UTAPI_002915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002915",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002915", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002915", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002915", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002915", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002915", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002915")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002916")
    void case_UTAPI_002916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002916",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002916", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002916", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002916", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002916", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002916", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002916")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002917")
    void case_UTAPI_002917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002917",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002917", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002917", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002917", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002917", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002917", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002917")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002918")
    void case_UTAPI_002918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002918",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002918", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002918", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002918", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002918", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002918", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002918")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002919")
    void case_UTAPI_002919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002919",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002919", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002919", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002919", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002919", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002919", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002919")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002920")
    void case_UTAPI_002920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002920",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002920", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002920", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002920", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002920", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002920", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002920")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002921")
    void case_UTAPI_002921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002921",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002921", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002921", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002921", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002921", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002921", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002921")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002922")
    void case_UTAPI_002922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002922",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002922", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002922", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002922", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002922", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002922", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002922")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002923")
    void case_UTAPI_002923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002923",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002923", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002923", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002923", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002923", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002923", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002923")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002924")
    void case_UTAPI_002924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002924",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002924", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002924", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002924", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002924", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002924", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002924")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "56:space")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002925")
    void case_UTAPI_002925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002925",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002925", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002925", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002925", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002925", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002925", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002925")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002926")
    void case_UTAPI_002926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002926",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002926", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002926", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002926", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002926", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002926", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002926")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002927")
    void case_UTAPI_002927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002927",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002927", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002927", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002927", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002927", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002927", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002927")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "59:tab")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002928")
    void case_UTAPI_002928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002928",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002928", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002928", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002928", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002928", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002928", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002928")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002929")
    void case_UTAPI_002929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002929",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002929", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002929", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002929", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002929", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002929", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002929")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002930")
    void case_UTAPI_002930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002930",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002930", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002930", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002930", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002930", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002930", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002930")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002931")
    void case_UTAPI_002931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002931",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "save",
                "MemoTemplate",
                new ParamSpec[] {
                    new ParamSpec("template", "MemoTemplate", "template")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002931", "template", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-002931", "template.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002931", "template.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002931", "template.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002931", "template.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002931")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::save::3::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("template.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for template.titleMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:template.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for template.titleMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:template.titleMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

}

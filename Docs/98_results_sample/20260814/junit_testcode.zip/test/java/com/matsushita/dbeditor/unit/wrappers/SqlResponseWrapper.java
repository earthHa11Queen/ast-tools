package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for SqlResponse.
 */
public final class SqlResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.SqlResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.SqlResponse";
    private static final String[] DEP_NAMES = new String[] {"n", "connectionId", "title", "content"};
    private static final String[] DEP_TYPES = new String[] {"Integer", "Integer", "String", "String"};
    private static final String[] TYPES_fromEntity = new String[] {"SavedSql"};
    private static final String[] TYPES_summaryFromEntity = new String[] {"SavedSql"};

    public SqlResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** SqlResponse fromEntity(sql) */
    public ExecutionResult fromEntity(Object[] args) {
        return invoke("fromEntity", TYPES_fromEntity, args);
    }

    /** SqlResponse summaryFromEntity(sql) */
    public ExecutionResult summaryFromEntity(Object[] args) {
        return invoke("summaryFromEntity", TYPES_summaryFromEntity, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("fromEntity".equals(operation)) {
            return fromEntity(args);
        } else if ("summaryFromEntity".equals(operation)) {
            return summaryFromEntity(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

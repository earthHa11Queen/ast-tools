package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#getStaleTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseGetStaleTablesScenario {

    @Test
    @DisplayName("UTAPI-013492")
    void case_UTAPI_013492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013492",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013492", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013492", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013492")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013493")
    void case_UTAPI_013493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013493",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013493", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013493", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013493")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013494")
    void case_UTAPI_013494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013494",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013494", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013494", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013494")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013495")
    void case_UTAPI_013495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013495",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013495", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013495", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013495")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013496")
    void case_UTAPI_013496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013496",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013496", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013496", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013496")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013497")
    void case_UTAPI_013497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013497",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013497", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013497", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013497")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013498")
    void case_UTAPI_013498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013498",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013498", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013498", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013498")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013499")
    void case_UTAPI_013499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013499",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013499", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013499", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013499")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013500")
    void case_UTAPI_013500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013500",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013500", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013500", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013500")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013501")
    void case_UTAPI_013501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013501",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013501", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013501", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013501")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013502")
    void case_UTAPI_013502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013502",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013502", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013502", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013502")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013503")
    void case_UTAPI_013503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013503",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013503", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013503", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013503")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013504")
    void case_UTAPI_013504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013504",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013504", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013504", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013504")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013505")
    void case_UTAPI_013505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013505",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013505", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013505", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013505")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013506")
    void case_UTAPI_013506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013506",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013506", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013506", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013506")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013507")
    void case_UTAPI_013507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013507",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013507", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013507", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013507")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013508")
    void case_UTAPI_013508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013508",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013508", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013508", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013508")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013509")
    void case_UTAPI_013509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013509",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013509", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013509", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013509")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013510")
    void case_UTAPI_013510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013510",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013510", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013510", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013510")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013511")
    void case_UTAPI_013511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013511",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013511", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013511", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013511")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013512")
    void case_UTAPI_013512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013512",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013512", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013512", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013512")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013513")
    void case_UTAPI_013513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013513",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013513", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013513", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013513")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013514")
    void case_UTAPI_013514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013514",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013514", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013514", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013514")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013515")
    void case_UTAPI_013515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013515",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013515", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013515", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013515")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013516")
    void case_UTAPI_013516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013516",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013516", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013516", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013516")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013517")
    void case_UTAPI_013517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013517",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013517", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013517", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013517")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013518")
    void case_UTAPI_013518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013518",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013518", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013518", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013518")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013519")
    void case_UTAPI_013519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013519",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013519", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013519", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013519")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013520")
    void case_UTAPI_013520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013520",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013520", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013520", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013520")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013521")
    void case_UTAPI_013521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013521",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013521", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013521", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013521")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013522")
    void case_UTAPI_013522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013522",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013522", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013522", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013522")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013523")
    void case_UTAPI_013523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013523",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "getStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013523", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013523", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013523")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::getStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.findStaleTables")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.findStaleTables must carry the value generated for schemaName", "tableRecordRepository", "findStaleTables", "1", "data:schemaName")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableRecordRepository.findStaleTables", "tableRecordRepository", "findStaleTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

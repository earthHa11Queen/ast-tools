package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoTemplateGateway#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoTemplateGatewayDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-002849")
    void case_UTAPI_002849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002849",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002849", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002850")
    void case_UTAPI_002850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002850",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002850", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002851")
    void case_UTAPI_002851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002851",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002851", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002852")
    void case_UTAPI_002852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002852",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002852", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002853")
    void case_UTAPI_002853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002853",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002853", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002854")
    void case_UTAPI_002854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002854",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002854", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002855")
    void case_UTAPI_002855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002855",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002855", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002856")
    void case_UTAPI_002856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002856",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002856", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002857")
    void case_UTAPI_002857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002857",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002857", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002858")
    void case_UTAPI_002858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002858",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002858", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002858")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002859")
    void case_UTAPI_002859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002859",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002859", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002859")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

}

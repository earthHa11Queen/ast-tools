package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlTemplateGateway#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlTemplateGatewayDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-003044")
    void case_UTAPI_003044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003044",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003044", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003044")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003045")
    void case_UTAPI_003045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003045",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003045", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003045")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003046")
    void case_UTAPI_003046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003046",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003046", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003046")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003047")
    void case_UTAPI_003047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003047",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003047", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003047")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003048")
    void case_UTAPI_003048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003048",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003048", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003048")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003049")
    void case_UTAPI_003049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003049",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003049", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003049")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003050")
    void case_UTAPI_003050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003050",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003050", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003050")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003051")
    void case_UTAPI_003051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003051",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003051", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003051")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003052")
    void case_UTAPI_003052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003052",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003052", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003052")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003053")
    void case_UTAPI_003053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003053",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003053", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003053")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003054")
    void case_UTAPI_003054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003054",
                "com.matsushita.dbeditor.adapter.gateway.SqlTemplateGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003054", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-003054")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SqlTemplateGateway.java::SqlTemplateGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlTemplateGatewayWrapper());
    }

}

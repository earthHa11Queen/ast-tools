package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for MemoController.
 */
public final class MemoControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.MemoController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.MemoController";
    private static final String[] DEP_NAMES = new String[] {"memoUseCase"};
    private static final String[] DEP_TYPES = new String[] {"MemoUseCase"};
    private static final String[] TYPES_downloadMemo = new String[] {"Integer", "String"};
    private static final String[] TYPES_getMemo = new String[] {"Integer", "String"};
    private static final String[] TYPES_saveMemo = new String[] {"Integer", "String", "MemoSaveRequest"};
    private static final String[] TYPES_uploadMemo = new String[] {"Integer", "String", "MultipartFile"};

    public MemoControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<byte[]> downloadMemo(connectionId, tableName) */
    public ExecutionResult downloadMemo(Object[] args) {
        return invoke("downloadMemo", TYPES_downloadMemo, args);
    }

    /** ResponseEntity<MemoResponse> getMemo(connectionId, tableName) */
    public ExecutionResult getMemo(Object[] args) {
        return invoke("getMemo", TYPES_getMemo, args);
    }

    /** ResponseEntity<MemoResponse> saveMemo(connectionId, tableName, request) */
    public ExecutionResult saveMemo(Object[] args) {
        return invoke("saveMemo", TYPES_saveMemo, args);
    }

    /** ResponseEntity<MemoResponse> uploadMemo(connectionId, tableName, file) */
    public ExecutionResult uploadMemo(Object[] args) {
        return invoke("uploadMemo", TYPES_uploadMemo, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("downloadMemo".equals(operation)) {
            return downloadMemo(args);
        } else if ("getMemo".equals(operation)) {
            return getMemo(args);
        } else if ("saveMemo".equals(operation)) {
            return saveMemo(args);
        } else if ("uploadMemo".equals(operation)) {
            return uploadMemo(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

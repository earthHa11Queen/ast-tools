package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ImportController.
 */
public final class ImportControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.ImportController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.ImportController";
    private static final String[] DEP_NAMES = new String[] {"importUseCase"};
    private static final String[] DEP_TYPES = new String[] {"ImportUseCase"};
    private static final String[] TYPES_applyMapping = new String[] {"MappingApplyRequest"};
    private static final String[] TYPES_createTableAndImport = new String[] {"NewTableImportRequest"};
    private static final String[] TYPES_csvAutoMapping = new String[] {"MultipartFile", "Integer", "String", "String"};
    private static final String[] TYPES_excelAutoMapping = new String[] {"MultipartFile", "Integer", "String", "int", "String"};
    private static final String[] TYPES_getExcelSheets = new String[] {"MultipartFile"};

    public ImportControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<Void> applyMapping(request) */
    public ExecutionResult applyMapping(Object[] args) {
        return invoke("applyMapping", TYPES_applyMapping, args);
    }

    /** ResponseEntity<Void> createTableAndImport(request) */
    public ExecutionResult createTableAndImport(Object[] args) {
        return invoke("createTableAndImport", TYPES_createTableAndImport, args);
    }

    /** ResponseEntity<AutoMappingResponse> csvAutoMapping(file, connectionId, tableName, schemaName) */
    public ExecutionResult csvAutoMapping(Object[] args) {
        return invoke("csvAutoMapping", TYPES_csvAutoMapping, args);
    }

    /** ResponseEntity<AutoMappingResponse> excelAutoMapping(file, connectionId, tableName, sheetIndex, schemaName) */
    public ExecutionResult excelAutoMapping(Object[] args) {
        return invoke("excelAutoMapping", TYPES_excelAutoMapping, args);
    }

    /** ResponseEntity<List<String>> getExcelSheets(file) */
    public ExecutionResult getExcelSheets(Object[] args) {
        return invoke("getExcelSheets", TYPES_getExcelSheets, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("applyMapping".equals(operation)) {
            return applyMapping(args);
        } else if ("createTableAndImport".equals(operation)) {
            return createTableAndImport(args);
        } else if ("csvAutoMapping".equals(operation)) {
            return csvAutoMapping(args);
        } else if ("excelAutoMapping".equals(operation)) {
            return excelAutoMapping(args);
        } else if ("getExcelSheets".equals(operation)) {
            return getExcelSheets(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

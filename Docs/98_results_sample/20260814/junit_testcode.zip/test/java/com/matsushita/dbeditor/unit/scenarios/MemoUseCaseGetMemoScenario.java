package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoUseCase#getMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoUseCaseGetMemoScenario {

    @Test
    @DisplayName("UTAPI-012609")
    void case_UTAPI_012609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012609",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012609", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012609")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012610")
    void case_UTAPI_012610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012610",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012610", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012610")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012611")
    void case_UTAPI_012611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012611",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012611", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012611")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012612")
    void case_UTAPI_012612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012612",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012612", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012612")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012613")
    void case_UTAPI_012613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012613",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012613", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012613")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012614")
    void case_UTAPI_012614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012614",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012614", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012614")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012615")
    void case_UTAPI_012615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012615",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012615", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012615")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012616")
    void case_UTAPI_012616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012616",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012616", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012616")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012617")
    void case_UTAPI_012617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012617",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012617", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012617")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012618")
    void case_UTAPI_012618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012618",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012618", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012618")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012619")
    void case_UTAPI_012619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012619",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012619", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012619")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012620")
    void case_UTAPI_012620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012620",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012620", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012620", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012620")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012621")
    void case_UTAPI_012621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012621",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012621", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012621", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012621")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012622")
    void case_UTAPI_012622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012622",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012622", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012622", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012622")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012623")
    void case_UTAPI_012623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012623",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012623", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012623", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012623")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012624")
    void case_UTAPI_012624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012624",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012624", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012624", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012624")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012625")
    void case_UTAPI_012625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012625",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012625", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012625", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012625")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012626")
    void case_UTAPI_012626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012626",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012626", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012626", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012626")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012627")
    void case_UTAPI_012627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012627",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012627", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012627", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012627")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012628")
    void case_UTAPI_012628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012628",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012628", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012628", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012628")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012629")
    void case_UTAPI_012629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012629",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012629", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012629", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012629")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012630")
    void case_UTAPI_012630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012630",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012630", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012630", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012630")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012631")
    void case_UTAPI_012631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012631",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012631", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012631", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012631")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012632")
    void case_UTAPI_012632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012632",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012632", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012632", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012632")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012633")
    void case_UTAPI_012633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012633",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012633", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012633", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012633")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012634")
    void case_UTAPI_012634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012634",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012634", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012634", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012634")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012635")
    void case_UTAPI_012635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012635",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012635", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012635", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012635")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012636")
    void case_UTAPI_012636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012636",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012636", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012636", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012636")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012637")
    void case_UTAPI_012637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012637",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012637", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012637", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012637")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012638")
    void case_UTAPI_012638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012638",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012638", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012638", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012638")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012639")
    void case_UTAPI_012639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012639",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012639", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012639", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012639")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012640")
    void case_UTAPI_012640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012640",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "getMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012640", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012640", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012640")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::getMemo::1::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.findByConnectionIdAndTableName")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.findByConnectionIdAndTableName", "tableMemoRepository", "findByConnectionIdAndTableName")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for connectionId", "tableMemoRepository", "findByConnectionIdAndTableName", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableMemoRepository.findByConnectionIdAndTableName must carry the value generated for tableName", "tableMemoRepository", "findByConnectionIdAndTableName", "1", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

}

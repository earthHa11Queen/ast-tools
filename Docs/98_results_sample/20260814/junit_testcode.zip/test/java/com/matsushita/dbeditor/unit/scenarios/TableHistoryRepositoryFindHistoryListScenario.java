package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryRepository#findHistoryList.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryRepositoryFindHistoryListScenario {

    @Test
    @DisplayName("UTAPI-008015")
    void case_UTAPI_008015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008015",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008015", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008015", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008015", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008015", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008015")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008016")
    void case_UTAPI_008016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008016",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008016", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008016", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008016", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008016")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008017")
    void case_UTAPI_008017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008017",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008017", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008017", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008017", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008017")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008018")
    void case_UTAPI_008018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008018",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008018", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008018", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008018", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008018")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008019")
    void case_UTAPI_008019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008019",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008019", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008019", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008019", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008019")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008020")
    void case_UTAPI_008020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008020",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008020", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008020", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008020", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008020")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008021")
    void case_UTAPI_008021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008021",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008021", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008021", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008021", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008021")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008022")
    void case_UTAPI_008022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008022",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008022", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008022", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008022", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008022")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008023")
    void case_UTAPI_008023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008023",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008023", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008023", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008023", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008023", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008023", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008023", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008023", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008023", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008023", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008023", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008023", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008023", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008023")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008024")
    void case_UTAPI_008024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008024",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008024", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008024", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008024", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008024", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008024", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008024", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008024", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008024", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008024", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008024", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008024", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008024", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008024")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008025")
    void case_UTAPI_008025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008025",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008025", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008025", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008025", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008025", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008025", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008025", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008025", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008025", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008025", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008025", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008025", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008025", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008025")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008026")
    void case_UTAPI_008026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008026",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008026", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008026", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008026", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008026", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008026", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008026", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008026", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008026", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008026", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008026", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008026", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008026", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008026")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008027")
    void case_UTAPI_008027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008027",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008027", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008027", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008027", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008027", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008027", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008027", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008027", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008027", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008027", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008027", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008027", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008027", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008027")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008028")
    void case_UTAPI_008028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008028",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008028", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008028", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008028", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008028", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008028", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008028", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008028", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008028", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008028", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008028", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008028")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008029")
    void case_UTAPI_008029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008029",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008029", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008029", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008029", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008029", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008029", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008029", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008029", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008029", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008029", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008029", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008029")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008030")
    void case_UTAPI_008030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008030",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008030", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008030", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008030", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008030", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008030", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008030", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008030", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008030", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008030", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008030", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008030")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008031")
    void case_UTAPI_008031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008031",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008031", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008031", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008031", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008031", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008031", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008031", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008031", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008031", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008031", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008031", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008031")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008032")
    void case_UTAPI_008032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008032",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008032", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008032", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008032", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008032", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008032", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008032", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008032", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008032", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008032", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008032", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008032")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008033")
    void case_UTAPI_008033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008033",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008033", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008033", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008033", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008033", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008033", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008033", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008033", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008033", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008033", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008033", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008033")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008034")
    void case_UTAPI_008034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008034",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008034", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008034", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008034", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008034", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008034", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008034", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008034", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008034", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008034", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008034", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008034")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008035")
    void case_UTAPI_008035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008035",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008035", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008035", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008035", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008035", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008035", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008035", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008035", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008035", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008035", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008035", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008035")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008036")
    void case_UTAPI_008036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008036",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008036", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008036", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008036", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008036", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008036", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008036", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008036", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008036", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008036", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008036", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008036")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008037")
    void case_UTAPI_008037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008037",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008037", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008037", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008037", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008037", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008037", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008037", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008037", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008037", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008037", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008037", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008037")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008038")
    void case_UTAPI_008038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008038",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008038", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008038", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008038", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008038", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008038", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008038", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008038", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008038", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008038", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008038", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008038")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008039")
    void case_UTAPI_008039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008039",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008039", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008039", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008039", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008039", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008039", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008039", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008039", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008039", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008039", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008039", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008039", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008039")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008040")
    void case_UTAPI_008040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008040",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008040", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008040", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008040", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008040", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008040", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008040", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008040", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008040", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008040", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008040", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008040", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008040")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008041")
    void case_UTAPI_008041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008041",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008041", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008041", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008041", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008041", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008041", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008041", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008041", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008041", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008041", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008041", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008041", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008041")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008042")
    void case_UTAPI_008042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008042",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008042", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008042", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008042", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008042", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008042", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008042", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008042", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008042", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008042", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008042", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008042", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008042")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008043")
    void case_UTAPI_008043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008043",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008043", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008043", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008043", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008043", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008043", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008043", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008043", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008043", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008043", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008043", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008043", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008043")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008044")
    void case_UTAPI_008044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008044",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008044", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008044", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008044", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008044", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008044", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008044", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008044", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008044", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008044", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008044", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008044", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008044", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008044")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008045")
    void case_UTAPI_008045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008045",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008045", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008045", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008045", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008045", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008045", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008045", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008045", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008045", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008045", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008045", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008045", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008045", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008045")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008046")
    void case_UTAPI_008046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008046",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008046", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008046", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008046", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008046", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008046", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008046", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008046", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008046")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008047")
    void case_UTAPI_008047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008047",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008047", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008047", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008047", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008047", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008047", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008047", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008047", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008047")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008048")
    void case_UTAPI_008048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008048",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008048", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008048", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008048", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008048", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008048", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008048", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008048", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008048")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008049")
    void case_UTAPI_008049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008049",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008049", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008049", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008049", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008049", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008049", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008049", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008049", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008049")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008050")
    void case_UTAPI_008050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008050",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008050", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008050", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008050", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008050", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008050", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008050", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008050", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008050")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008051")
    void case_UTAPI_008051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008051",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008051", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008051", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008051", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008051", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008051", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008051", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008051", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008051")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008052")
    void case_UTAPI_008052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008052",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008052", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008052", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008052", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008052", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008052", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008052", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008052", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008052")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008053")
    void case_UTAPI_008053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008053",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008053", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008053", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008053", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008053", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008053", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008053", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008053", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008053")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008054")
    void case_UTAPI_008054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008054",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008054", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008054", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008054", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008054", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008054", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008054", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008054")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008055")
    void case_UTAPI_008055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008055",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008055", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008055", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008055", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008055", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008055", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008055", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008055")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008056")
    void case_UTAPI_008056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008056",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008056", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008056", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008056", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008056", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008056", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008056", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008056")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008057")
    void case_UTAPI_008057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008057",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008057", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008057", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008057", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008057", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008057", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008057", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008057")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008058")
    void case_UTAPI_008058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008058",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008058", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008058", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008058", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008058", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008058", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008058", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008058")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008059")
    void case_UTAPI_008059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008059",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008059", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008059", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008059", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008059", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008059", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008059", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008059")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008060")
    void case_UTAPI_008060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008060",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008060", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008060", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008060", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008060", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008060", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008060")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008061")
    void case_UTAPI_008061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008061",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008061", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008061", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008061", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008061", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008061", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008061")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008062")
    void case_UTAPI_008062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008062",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008062", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008062", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008062", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008062", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008062", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008062")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008063")
    void case_UTAPI_008063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008063",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008063", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008063", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008063", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008063", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008063", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008063")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008064")
    void case_UTAPI_008064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008064",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008064", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008064", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008064", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008064", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008064", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008064", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008064")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008065")
    void case_UTAPI_008065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008065",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008065", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008065", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008065", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008065", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008065", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008065", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008065", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008065")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008066")
    void case_UTAPI_008066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008066",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008066", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008066", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008066", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008066", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008066", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008066", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008066", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008066")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008067")
    void case_UTAPI_008067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008067",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008067", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008067", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008067", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008067", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008067", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008067", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008067", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008067")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008068")
    void case_UTAPI_008068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008068",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008068", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008068", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008068", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008068", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008068", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008068", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008068", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008068")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008069")
    void case_UTAPI_008069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008069",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008069", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008069", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008069", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008069", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008069")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008070")
    void case_UTAPI_008070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008070",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008070", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008070", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008070", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008070", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008070")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008071")
    void case_UTAPI_008071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008071",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008071", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008071", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008071", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008071", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008071")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008072")
    void case_UTAPI_008072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008072",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008072", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008072", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008072", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008072", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008072")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008073")
    void case_UTAPI_008073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008073",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008073", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008073", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008073", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008073", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008073")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008074")
    void case_UTAPI_008074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008074",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008074", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008074", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008074", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008074", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008074")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008075")
    void case_UTAPI_008075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008075",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008075", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008075", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008075", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008075", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008075")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008076")
    void case_UTAPI_008076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008076",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008076", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008076", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008076", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008076", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008076")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008077")
    void case_UTAPI_008077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008077",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008077", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008077", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008077", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008077", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008077")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008078")
    void case_UTAPI_008078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008078",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008078", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008078", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008078", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008078", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008078")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008079")
    void case_UTAPI_008079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008079",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008079", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008079", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008079", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008079", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008079")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008080")
    void case_UTAPI_008080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008080",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008080", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008080", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008080", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008080", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008080")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008081")
    void case_UTAPI_008081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008081",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008081", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008081", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008081", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008081", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008081")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008082")
    void case_UTAPI_008082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008082",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008082", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008082", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008082", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008082", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008082")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008083")
    void case_UTAPI_008083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008083",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008083", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008083", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008083", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008083", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008083")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008084")
    void case_UTAPI_008084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008084",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008084", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008084", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008084", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008084", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008084")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008085")
    void case_UTAPI_008085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008085",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008085", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008085", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008085", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008085", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008085")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008086")
    void case_UTAPI_008086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008086",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008086", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008086", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008086", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008086", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008086")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008087")
    void case_UTAPI_008087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008087",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008087", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008087", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008087", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008087", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008087")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008088")
    void case_UTAPI_008088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008088",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008088", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008088", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008088", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008088", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008088")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008089")
    void case_UTAPI_008089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008089",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008089", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008089", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008089", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008089", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008089")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008090")
    void case_UTAPI_008090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008090",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008090", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008090", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008090", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008090", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008090")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008091")
    void case_UTAPI_008091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008091",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008091", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008091", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008091", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008091", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008091")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008092")
    void case_UTAPI_008092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008092",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008092", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008092", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008092", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008092", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008092")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008093")
    void case_UTAPI_008093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008093",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008093", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008093", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008093", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008093", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008093")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008094")
    void case_UTAPI_008094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008094",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008094", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008094", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008094", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008094", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008094")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008095")
    void case_UTAPI_008095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008095",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008095", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008095", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008095", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008095", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008095")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008096")
    void case_UTAPI_008096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008096",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008096", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008096", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008096", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008096", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008096")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008097")
    void case_UTAPI_008097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008097",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008097", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008097", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008097", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008097", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008097")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008098")
    void case_UTAPI_008098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008098",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008098", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008098", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008098", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008098", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008098")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008099")
    void case_UTAPI_008099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008099",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008099", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008099", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008099", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008099", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008099")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008100")
    void case_UTAPI_008100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008100",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008100", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008100", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008100", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008100", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008100")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008101")
    void case_UTAPI_008101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008101",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008101", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008101", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008101", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008101")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008102")
    void case_UTAPI_008102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008102",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008102", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008102", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008102", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008102")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008103")
    void case_UTAPI_008103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008103",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008103", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008103", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008103", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008103")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008104")
    void case_UTAPI_008104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008104",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008104", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008104", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008104")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008105")
    void case_UTAPI_008105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008105",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008105", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008105", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008105")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008106")
    void case_UTAPI_008106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008106",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008106", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008106", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008106")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008107")
    void case_UTAPI_008107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008107",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008107", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008107", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008107")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008108")
    void case_UTAPI_008108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008108",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008108", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008108", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008108")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008109")
    void case_UTAPI_008109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008109",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008109", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008109", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008109")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008110")
    void case_UTAPI_008110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008110",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008110", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008110", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008110")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008111")
    void case_UTAPI_008111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008111",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008111", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008111", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008111")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008112")
    void case_UTAPI_008112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008112",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008112", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008112", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008112")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008113")
    void case_UTAPI_008113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008113",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008113", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008113", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008113")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008114")
    void case_UTAPI_008114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008114",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008114", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008114", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008114")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008115")
    void case_UTAPI_008115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008115",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008115", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008115", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008115")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008116")
    void case_UTAPI_008116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008116",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008116", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008116", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008116", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008116", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008116")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008117")
    void case_UTAPI_008117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008117",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008117", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008117", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008117", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008117", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008117")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008118")
    void case_UTAPI_008118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008118",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008118", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008118", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008118", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008118", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008118")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008119")
    void case_UTAPI_008119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008119",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008119", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008119", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008119", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008119", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008119")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008120")
    void case_UTAPI_008120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008120",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008120", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008120", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008120", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008120", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008120")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008121")
    void case_UTAPI_008121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008121",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008121", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008121", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008121", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008121", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008121")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008122")
    void case_UTAPI_008122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008122",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008122", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008122", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008122", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008122", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008122")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008123")
    void case_UTAPI_008123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008123",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008123", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008123", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008123", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008123", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008123")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008124")
    void case_UTAPI_008124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008124",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008124", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008124", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008124", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008124", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008124")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008125")
    void case_UTAPI_008125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008125",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008125", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008125", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008125", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008125", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008125")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008126")
    void case_UTAPI_008126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008126",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008126", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008126", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008126", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008126")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008127")
    void case_UTAPI_008127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008127",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008127", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008127", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008127")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008128")
    void case_UTAPI_008128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008128",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008128", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008128", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008128")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008129")
    void case_UTAPI_008129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008129",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008129", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008129", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008129")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008130")
    void case_UTAPI_008130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008130",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008130", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008130", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008130")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008131")
    void case_UTAPI_008131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008131",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008131", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008131", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008131")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008132")
    void case_UTAPI_008132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008132",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008132", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008132", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008132")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008133")
    void case_UTAPI_008133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008133",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008133", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008133", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008133")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008134")
    void case_UTAPI_008134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008134",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008134", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008134", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008134")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008135")
    void case_UTAPI_008135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008135",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008135", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008135", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008135")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008136")
    void case_UTAPI_008136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008136",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008136", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008136", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008136")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008137")
    void case_UTAPI_008137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008137",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008137", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008137")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008138")
    void case_UTAPI_008138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008138",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008138", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008138")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008139")
    void case_UTAPI_008139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008139",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008139", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008139")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008140")
    void case_UTAPI_008140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008140",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008140", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008140")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008141")
    void case_UTAPI_008141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008141",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008141", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008141")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008142")
    void case_UTAPI_008142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008142",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008142", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008142")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008143")
    void case_UTAPI_008143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008143",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008143", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008143")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008144")
    void case_UTAPI_008144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008144",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008144", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008144")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008145")
    void case_UTAPI_008145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008145",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008145", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008145")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008146")
    void case_UTAPI_008146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008146",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008146", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008146")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008147")
    void case_UTAPI_008147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008147",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008147", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008147")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008148")
    void case_UTAPI_008148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008148",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008148", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008148", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008148")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008149")
    void case_UTAPI_008149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008149",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008149", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008149", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008149")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008150")
    void case_UTAPI_008150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008150",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008150", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008150", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008150")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008151")
    void case_UTAPI_008151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008151",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008151", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008151", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008151")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008152")
    void case_UTAPI_008152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008152",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008152", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008152", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008152")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008153")
    void case_UTAPI_008153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008153",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008153", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008153", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008153")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008154")
    void case_UTAPI_008154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008154",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008154", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008154", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008154")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008155")
    void case_UTAPI_008155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008155",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008155", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008155", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008155")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008156")
    void case_UTAPI_008156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008156",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008156", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008156", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008156")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008157")
    void case_UTAPI_008157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008157",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008157", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008157", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008157")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008158")
    void case_UTAPI_008158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008158",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008158", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008158", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008158")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008159")
    void case_UTAPI_008159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008159",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008159", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008159", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008159")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008160")
    void case_UTAPI_008160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008160",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008160", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008160", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008160")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008161")
    void case_UTAPI_008161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008161",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008161", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008161", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008161")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008162")
    void case_UTAPI_008162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008162",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008162", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008162", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008162")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008163")
    void case_UTAPI_008163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008163",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008163", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008163", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008163")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008164")
    void case_UTAPI_008164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008164",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008164", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008164", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008164")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008165")
    void case_UTAPI_008165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008165",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008165", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008165", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008165")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008166")
    void case_UTAPI_008166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008166",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008166", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008166", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008166")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008167")
    void case_UTAPI_008167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008167",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008167", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008167", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008167")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008168")
    void case_UTAPI_008168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008168",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008168", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008168", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008168")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008169")
    void case_UTAPI_008169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008169",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008169", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008169", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008169")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008170")
    void case_UTAPI_008170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008170",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008170", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008170", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008170")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008171")
    void case_UTAPI_008171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008171",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008171", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008171", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008171")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008172")
    void case_UTAPI_008172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008172",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008172", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008172", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008172")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008173")
    void case_UTAPI_008173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008173",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008173", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008173", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008173")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008174")
    void case_UTAPI_008174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008174",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008174", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008174", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008174")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008175")
    void case_UTAPI_008175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008175",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008175", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008175", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008175")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008176")
    void case_UTAPI_008176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008176",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008176", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008176", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008176")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008177")
    void case_UTAPI_008177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008177",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008177", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008177", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008177")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008178")
    void case_UTAPI_008178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008178",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008178", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008178", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008178")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008179")
    void case_UTAPI_008179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008179",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008179", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008179")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008180")
    void case_UTAPI_008180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008180",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008180", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008180")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008181")
    void case_UTAPI_008181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008181",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008181", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008181")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008182")
    void case_UTAPI_008182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008182",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008182", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008182")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008183")
    void case_UTAPI_008183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008183",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008183", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008183")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008184")
    void case_UTAPI_008184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008184",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008184", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008184")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008185")
    void case_UTAPI_008185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008185",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008185", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008185")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008186")
    void case_UTAPI_008186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008186",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008186", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008186")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008187")
    void case_UTAPI_008187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008187",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008187", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008187")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008188")
    void case_UTAPI_008188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008188",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008188", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008188")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008189")
    void case_UTAPI_008189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008189",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008189", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008189")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008190")
    void case_UTAPI_008190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008190",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008190", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008190")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008191")
    void case_UTAPI_008191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008191",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008191", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008191")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008192")
    void case_UTAPI_008192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008192",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008192", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008192")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008193")
    void case_UTAPI_008193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008193",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008193", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008193")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008194")
    void case_UTAPI_008194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008194",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008194", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008194")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008195")
    void case_UTAPI_008195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008195",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008195", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008195")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008196")
    void case_UTAPI_008196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008196",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008196", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008196")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008197")
    void case_UTAPI_008197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008197",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryList",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008197", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008197")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryList::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateUseCase#deleteSqlTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateUseCaseDeleteSqlTemplateScenario {

    @Test
    @DisplayName("UTAPI-012756")
    void case_UTAPI_012756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012756",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012756", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012756")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012757")
    void case_UTAPI_012757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012757",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012757", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012757")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012758")
    void case_UTAPI_012758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012758",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012758", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012758")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012759")
    void case_UTAPI_012759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012759",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012759", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012759")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012760")
    void case_UTAPI_012760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012760",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012760", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012760")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012761")
    void case_UTAPI_012761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012761",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012761", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012761")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012762")
    void case_UTAPI_012762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012762",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012762", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012762")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012763")
    void case_UTAPI_012763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012763",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012763", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012763")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012764")
    void case_UTAPI_012764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012764",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012764", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012764")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012765")
    void case_UTAPI_012765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012765",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012765", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012765")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012766")
    void case_UTAPI_012766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012766",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteSqlTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012766", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012766")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteSqlTemplate::6::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlTemplateRepository.deleteById", "sqlTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlTemplateRepository.deleteById must carry the value generated for n", "sqlTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

}

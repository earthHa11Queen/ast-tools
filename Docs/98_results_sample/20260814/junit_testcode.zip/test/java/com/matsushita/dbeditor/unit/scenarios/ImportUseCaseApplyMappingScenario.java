package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#applyMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseApplyMappingScenario {

    @Test
    @DisplayName("UTAPI-012260")
    void case_UTAPI_012260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012260",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012260", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012260", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012260", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012260", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012260", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012260", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012260", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012260", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012260", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012260", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012260")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012261")
    void case_UTAPI_012261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012261",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012261", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012261", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012261", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012261", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012261", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012261", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012261", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012261", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012261", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012261", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012261")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012262")
    void case_UTAPI_012262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012262",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012262", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012262", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012262", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012262", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012262", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012262", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012262", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012262", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012262", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012262", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012262")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012263")
    void case_UTAPI_012263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012263",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012263", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012263", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012263", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012263", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012263", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012263", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012263", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012263", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012263", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012263", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012263")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012264")
    void case_UTAPI_012264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012264",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012264", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012264", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012264", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012264", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012264", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012264", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012264", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012264", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012264", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012264", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012264")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012265")
    void case_UTAPI_012265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012265",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012265", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012265", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012265", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012265", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012265", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012265", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012265", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012265", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012265", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012265", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012265")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012266")
    void case_UTAPI_012266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012266",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012266", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012266", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012266", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012266", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012266", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012266", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012266", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012266", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012266", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012266", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012266")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012267")
    void case_UTAPI_012267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012267",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012267", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012267", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012267", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012267", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012267", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012267", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012267", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012267", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012267", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012267", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012267")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012268")
    void case_UTAPI_012268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012268",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012268", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012268", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012268", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012268", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012268", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012268", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012268", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012268", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012268", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012268", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012268")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012269")
    void case_UTAPI_012269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012269",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012269", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012269", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012269", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012269", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012269", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012269", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012269", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012269", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012269", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012269", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012269")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012270")
    void case_UTAPI_012270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012270",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012270", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012270", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012270", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012270", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012270", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012270", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012270", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012270", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012270", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012270", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012270")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012271")
    void case_UTAPI_012271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012271",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012271", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012271", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012271", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012271", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012271", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012271", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012271", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012271", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012271", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012271", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012271")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012272")
    void case_UTAPI_012272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012272",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012272", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012272", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012272", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012272", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012272", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012272", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012272", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012272", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012272", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012272", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012272")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012273")
    void case_UTAPI_012273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012273",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012273", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012273", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012273", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012273", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012273", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012273", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012273", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012273", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012273", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012273", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012273")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012274")
    void case_UTAPI_012274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012274",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012274", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012274", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012274", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012274", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012274", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012274", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012274", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012274", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012274", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012274", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012274")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012275")
    void case_UTAPI_012275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012275",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012275", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012275", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012275", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012275", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012275", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012275", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012275", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012275", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012275", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012275", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012275")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012276")
    void case_UTAPI_012276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012276",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012276", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012276", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012276", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012276", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012276", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012276", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012276", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012276", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012276", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012276", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012276")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012277")
    void case_UTAPI_012277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012277",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012277", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012277", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012277", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012277", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012277", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012277", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012277", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012277", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012277", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012277", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012277")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012278")
    void case_UTAPI_012278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012278",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012278", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012278", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012278", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012278", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012278", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012278", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012278", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012278", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012278", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012278", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012278")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012279")
    void case_UTAPI_012279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012279",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012279", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012279", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012279", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012279", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012279", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012279", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012279", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012279", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012279", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012279", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012279")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012280")
    void case_UTAPI_012280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012280",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012280", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012280", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012280", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012280", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012280", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012280", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012280", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012280", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012280", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012280", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012280")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012281")
    void case_UTAPI_012281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012281",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012281", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012281", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012281", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012281", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012281", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012281", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012281", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012281", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012281", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012281", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012281")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012282")
    void case_UTAPI_012282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012282",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012282", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012282", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012282", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012282", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012282", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012282", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012282", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012282", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012282", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012282", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012282")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012283")
    void case_UTAPI_012283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012283",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012283", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012283", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012283", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012283", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012283", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012283", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012283", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012283", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012283", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012283", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012283")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012284")
    void case_UTAPI_012284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012284",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012284", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012284", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012284", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012284", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012284", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012284", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012284", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012284", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012284", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012284", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012284")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012285")
    void case_UTAPI_012285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012285",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012285", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012285", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012285", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012285", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012285", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012285", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012285", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012285", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012285", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012285", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012285")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012286")
    void case_UTAPI_012286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012286",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012286", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012286", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012286", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012286", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012286", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012286", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012286", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012286", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012286", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012286", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012286")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012287")
    void case_UTAPI_012287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012287",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012287", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012287", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012287", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012287", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012287", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012287", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012287", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012287", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012287", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012287", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012287")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012288")
    void case_UTAPI_012288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012288",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012288", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012288", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012288", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012288", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012288", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012288", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012288", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012288", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012288", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012288", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012288")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012289")
    void case_UTAPI_012289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012289",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012289", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012289", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012289", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012289", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012289", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012289", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012289", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012289", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012289", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012289", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012289")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012290")
    void case_UTAPI_012290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012290",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012290", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012290", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012290", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012290", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012290", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012290", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012290", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012290", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012290", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012290", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012290")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012291")
    void case_UTAPI_012291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012291",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012291", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012291", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012291", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012291", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012291", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012291", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012291", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012291", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012291", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012291", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012291")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012292")
    void case_UTAPI_012292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012292",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012292", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012292", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012292", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012292", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012292", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012292", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012292", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012292", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012292", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012292", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012292")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012293")
    void case_UTAPI_012293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012293",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012293", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012293", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012293", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012293", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012293", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012293", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012293", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012293", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012293", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012293", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012293")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012294")
    void case_UTAPI_012294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012294",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012294", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012294", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012294", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012294", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012294", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012294", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012294", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012294", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012294", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012294", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012294")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012295")
    void case_UTAPI_012295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012295",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012295", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012295", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012295", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012295", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012295", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012295", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012295", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012295", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012295", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012295", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012295")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012296")
    void case_UTAPI_012296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012296",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012296", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012296", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012296", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012296", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012296", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012296", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012296", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012296", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012296", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012296", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012296")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012297")
    void case_UTAPI_012297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012297",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012297", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012297", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012297", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012297", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012297", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012297", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012297", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012297", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012297", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012297", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012297")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012298")
    void case_UTAPI_012298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012298",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012298", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012298", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012298", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012298", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012298", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012298", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012298", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012298", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012298", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012298", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012298")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012299")
    void case_UTAPI_012299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012299",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012299", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012299", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012299", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012299", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012299", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012299", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012299", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012299", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012299", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012299", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012299")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012300")
    void case_UTAPI_012300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012300",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012300", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012300", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012300", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012300", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012300", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012300", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012300", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012300", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012300", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012300", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012300")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012301")
    void case_UTAPI_012301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012301",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012301", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012301", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012301", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012301", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012301", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012301", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012301", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012301", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012301", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012301", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012301")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012302")
    void case_UTAPI_012302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012302",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012302", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012302", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012302", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012302", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012302", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012302", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012302", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012302", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012302", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012302", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012302")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012303")
    void case_UTAPI_012303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012303",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012303", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012303", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012303", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012303", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012303", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012303", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012303", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012303", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012303", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012303", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012303")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012304")
    void case_UTAPI_012304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012304",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012304", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012304", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012304", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012304", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012304", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012304", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012304", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012304", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012304", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012304", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012304")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012305")
    void case_UTAPI_012305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012305",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012305", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012305", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012305", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012305", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012305", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012305", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012305", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012305", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012305", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012305", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012305")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012306")
    void case_UTAPI_012306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012306",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012306", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012306", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012306", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012306", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012306", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012306", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012306", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012306", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012306", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012306", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012306")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012307")
    void case_UTAPI_012307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012307",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012307", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012307", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012307", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012307", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012307", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012307", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012307", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012307", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012307", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012307", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012307")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012308")
    void case_UTAPI_012308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012308",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012308", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012308", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012308", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012308", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012308", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012308", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012308", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012308", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012308", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012308", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012308")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012309")
    void case_UTAPI_012309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012309",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012309", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012309", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012309", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012309", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012309", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012309", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012309", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012309", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012309", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012309", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012309")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012310")
    void case_UTAPI_012310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012310",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012310", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012310", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012310", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012310", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012310", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012310", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012310", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012310", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012310", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012310", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012310")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012311")
    void case_UTAPI_012311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012311",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012311", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012311", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012311", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012311", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012311", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012311", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012311", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012311", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012311", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012311", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012311")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012312")
    void case_UTAPI_012312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012312",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012312", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012312", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012312", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012312", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012312", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012312", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012312", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012312", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012312", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012312", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012312")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::3::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012313")
    void case_UTAPI_012313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012313",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012313", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012313", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012313", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012313", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012313", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012313", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012313", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012313", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012313", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012313", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012313")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "1:length_null", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012314")
    void case_UTAPI_012314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012314",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012314", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012314", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012314", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012314", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012314", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012314", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012314", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012314", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012314", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012314", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012314")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "2:length_empty", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012315")
    void case_UTAPI_012315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012315",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012315", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012315", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012315", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012315", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012315", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012315", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012315", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012315", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012315", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012315", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012315")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "3:length_min", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012316")
    void case_UTAPI_012316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012316",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012316", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012316", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012316", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012316", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012316", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012316", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012316", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012316", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012316", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012316", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012316")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012317")
    void case_UTAPI_012317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012317",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012317", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012317", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012317", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012317", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012317", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012317", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012317", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012317", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012317", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012317", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012317")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "5:length_max", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012318")
    void case_UTAPI_012318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012318",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012318", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012318", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012318", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012318", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012318", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012318", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012318", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012318", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012318", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012318", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012318")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012319")
    void case_UTAPI_012319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012319",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012319", "mapping", "TARGET", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012319", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012319", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012319", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012319", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012319", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012319", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012319", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012319", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012319", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012319")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::4::-::mapping")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("mapping", "mapping")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for mapping is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied mapping entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "3", "data:mapping")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012320")
    void case_UTAPI_012320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012320",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012320", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012320", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012320", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012320", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012320", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012320", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012320", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012320", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012320", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012320", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012320")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "1:length_null", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012321")
    void case_UTAPI_012321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012321",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012321", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012321", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012321", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012321", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012321", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012321", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012321", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012321", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012321", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012321", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012321")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012322")
    void case_UTAPI_012322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012322",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012322", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012322", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012322", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012322", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012322", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012322", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012322", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012322", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012322", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012322", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012322")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012323")
    void case_UTAPI_012323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012323",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012323", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012323", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012323", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012323", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012323", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012323", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012323", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012323", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012323", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012323", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012323")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012324")
    void case_UTAPI_012324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012324",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012324", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012324", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012324", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012324", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012324", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012324", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012324", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012324", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012324", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012324", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012324")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012325")
    void case_UTAPI_012325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012325",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012325", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012325", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012325", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012325", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012325", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012325", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012325", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012325", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012325", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012325", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012325")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012326")
    void case_UTAPI_012326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012326",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "applyMapping",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("mapping", "Map<String, String>", "mapping"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012326", "mapping", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012326", "mapping{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012326", "mapping{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012326", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012326", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012326", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012326", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012326", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012326", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012326", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012326")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::applyMapping::4::ARG::5::-::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.insertIntoCopyTable")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.insertIntoCopyTable", "importRepository", "insertIntoCopyTable")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.insertIntoCopyTable must carry the value generated for schemaName", "importRepository", "insertIntoCopyTable", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.insertIntoCopyTable must carry the value generated for tableName", "importRepository", "insertIntoCopyTable", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the insertion", "importRepository", "insertIntoCopyTable", "4", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

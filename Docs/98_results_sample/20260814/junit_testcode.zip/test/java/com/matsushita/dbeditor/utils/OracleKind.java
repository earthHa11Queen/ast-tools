package com.matsushita.dbeditor.utils;

/**
 * Classification of the Oracle derived for a CaseNo. The kind records which
 * observation family the Case belongs to; the concrete PASS / FAIL conditions are
 * carried by the OracleCheck list of the same OraclePlan.
 */
public enum OracleKind {
    /** Value must reach the declared collaborator operation unchanged. */
    DELEGATION_CONTRACT,
    /** Gateway level contract against the declared infrastructure collaborator. */
    INFRA_DELEGATION_CONTRACT,
    /** Static mapper: source field values must be projected onto the response DTO. */
    DTO_FIELD_PROJECTION,
    /** Identifier validation contract of TableNameValidator.validate. */
    IDENTIFIER_VALIDATION,
    /** Identifier composition (quoted / copy / backup / history names). */
    IDENTIFIER_COMPOSITION,
    /** Normalizing pure function (idempotent, structure preserving). */
    PURE_NORMALIZATION,
    /** CSV field preservation for split / join / parse helpers. */
    CSV_FIELD_PRESERVATION,
    /** DataSource / JdbcTemplate composition from connection settings. */
    DATASOURCE_COMPOSITION,
    /** JDBC connection contract observed through DriverManager. */
    JDBC_CONNECTION_CONTRACT,
    /** Application bootstrap contract observed through SpringApplication. */
    APPLICATION_BOOTSTRAP,
    /** CORS registration contract. */
    CORS_REGISTRATION,
    /** Exception to error response mapping. */
    ERROR_RESPONSE_MAPPING,
    /** Health endpoint contract. */
    HEALTH_RESPONSE,
    /** Utility class must not be publicly instantiable. */
    UTILITY_CLASS_CONSTRUCTION,
    /** File based import contract. */
    FILE_IMPORT_DELEGATION
}

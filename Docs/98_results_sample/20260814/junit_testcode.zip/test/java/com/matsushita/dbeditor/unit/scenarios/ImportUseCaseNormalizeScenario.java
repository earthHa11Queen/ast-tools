package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#normalize.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseNormalizeScenario {

    @Test
    @DisplayName("UTAPI-012535")
    void case_UTAPI_012535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012535",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012535", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012535")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "1:length_null", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012536")
    void case_UTAPI_012536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012536",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012536", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012536")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "2:length_empty", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012537")
    void case_UTAPI_012537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012537",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012537", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012537")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "3:length_min", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012538")
    void case_UTAPI_012538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012538",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012538", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012538")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012539")
    void case_UTAPI_012539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012539",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012539", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012539")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "5:length_max", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012540")
    void case_UTAPI_012540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012540",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012540", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012540")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012541")
    void case_UTAPI_012541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012541",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012541", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012541")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012542")
    void case_UTAPI_012542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012542",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012542", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012542")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012543")
    void case_UTAPI_012543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012543",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012543", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012543")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012544")
    void case_UTAPI_012544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012544",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012544", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012544")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012545")
    void case_UTAPI_012545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012545",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012545", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012545")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012546")
    void case_UTAPI_012546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012546",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012546", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012546")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012547")
    void case_UTAPI_012547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012547",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012547", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012547")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "56:space")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012548")
    void case_UTAPI_012548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012548",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012548", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012548")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012549")
    void case_UTAPI_012549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012549",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012549", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012549")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012550")
    void case_UTAPI_012550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012550",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012550", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012550")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "59:tab")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012551")
    void case_UTAPI_012551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012551",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012551", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012551")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "60:control_character_null")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012552")
    void case_UTAPI_012552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012552",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012552", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012552")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012553")
    void case_UTAPI_012553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012553",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012553", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012553")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012554")
    void case_UTAPI_012554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012554",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "normalize",
                "String",
                new ParamSpec[] {
                    new ParamSpec("s", "String", "s")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012554", "s", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012554")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::normalize::7::ARG::1::-::s")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("s", "s")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.PURE_NORMALIZATION)
                    .observation("the normalised value and the result of normalising it once more")
                    .expected("the normalisation is total and stable for this character condition")
                    .failure("the value is rejected, lost, or keeps changing on repeated normalisation")
                    .assertion("assertNotNull and assertEquals(result, normalize(result))")
                    .check(CheckType.NO_EXCEPTION, "normalisation must accept this input condition")
                    .check(CheckType.RETURN_NOT_NULL, "normalisation must produce a value")
                    .check(CheckType.IDEMPOTENT_ON_RESULT, "normalising an already normalised value must not change it again", "0", "data:s")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

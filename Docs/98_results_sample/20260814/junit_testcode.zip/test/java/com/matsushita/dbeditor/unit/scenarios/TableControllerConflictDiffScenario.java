package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#conflictDiff.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerConflictDiffScenario {

    @Test
    @DisplayName("UTAPI-001212")
    void case_UTAPI_001212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001212",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001212", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001212", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001212", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001212", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001213")
    void case_UTAPI_001213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001213",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001213", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001213", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001213", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001213", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001214")
    void case_UTAPI_001214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001214",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001214", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001214", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001214", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001214", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001215")
    void case_UTAPI_001215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001215",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001215", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001215", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001215", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001215", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001216")
    void case_UTAPI_001216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001216",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001216", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001216", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001216", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001216", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001217")
    void case_UTAPI_001217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001217",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001217", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001217", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001217", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001217", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001218")
    void case_UTAPI_001218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001218",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001218", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001218", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001218", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001218", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001219")
    void case_UTAPI_001219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001219",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001219", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001219", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001219", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001219", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001220")
    void case_UTAPI_001220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001220",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001220", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001220", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001220", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001220", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001221")
    void case_UTAPI_001221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001221",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001221", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001221", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001221", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001221", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001222")
    void case_UTAPI_001222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001222",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001222", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001222", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001222", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001222", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001223")
    void case_UTAPI_001223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001223",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001223", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001223", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001223", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001223", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001224")
    void case_UTAPI_001224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001224",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001224", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001224", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001224", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001224", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001225")
    void case_UTAPI_001225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001225",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001225", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001225", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001225", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001225", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001226")
    void case_UTAPI_001226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001226",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001226", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001226", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001226", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001226", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001227")
    void case_UTAPI_001227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001227",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001227", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001227", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001227", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001227", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001228")
    void case_UTAPI_001228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001228",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001228", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001228", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001228", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001228", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001229")
    void case_UTAPI_001229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001229",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001229", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001229", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001229", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001229", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001230")
    void case_UTAPI_001230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001230",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001230", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001230", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001230", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001230", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001231")
    void case_UTAPI_001231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001231",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001231", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001231", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001231", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001231", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001232")
    void case_UTAPI_001232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001232",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001232", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001232", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001232", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001232", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001233")
    void case_UTAPI_001233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001233",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001233", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001233", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001233", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001233", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001234")
    void case_UTAPI_001234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001234",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001234", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001234", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001234", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001234", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001235")
    void case_UTAPI_001235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001235",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001235", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001235", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001235", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001235", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001236")
    void case_UTAPI_001236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001236",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001236", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001236", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001236", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001236", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001237")
    void case_UTAPI_001237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001237",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001237", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001237", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001237", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001237", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001238")
    void case_UTAPI_001238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001238",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001238", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001238", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001238", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001238", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001239")
    void case_UTAPI_001239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001239",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001239", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001239", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001239", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001239", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001240")
    void case_UTAPI_001240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001240",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001240", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001240", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001240", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001240", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001241")
    void case_UTAPI_001241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001241",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001241", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001241", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001241", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001241", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001242")
    void case_UTAPI_001242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001242",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001242", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001242", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001242", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001242", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001243")
    void case_UTAPI_001243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001243",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001243", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001243", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001243", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001243", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001244")
    void case_UTAPI_001244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001244",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001244", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001244", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001244", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001244", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001245")
    void case_UTAPI_001245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001245",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001245", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001245", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001245", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001245", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001245")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001246")
    void case_UTAPI_001246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001246",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001246", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001246", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001246", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001246", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001246")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001247")
    void case_UTAPI_001247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001247",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001247", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001247", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001247", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001247", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001247")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001248")
    void case_UTAPI_001248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001248",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001248", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001248", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001248", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001248", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001248")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001249")
    void case_UTAPI_001249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001249",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001249", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001249", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001249", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001249", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001249")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001250")
    void case_UTAPI_001250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001250",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001250", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001250", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001250", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001250", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001250")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001251")
    void case_UTAPI_001251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001251",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001251", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001251", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001251", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001251", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001251")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001252")
    void case_UTAPI_001252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001252",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001252", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001252", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001252", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001252", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001252")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001253")
    void case_UTAPI_001253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001253",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001253", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001253", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001253", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001253", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001253")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001254")
    void case_UTAPI_001254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001254",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001254", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001254", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001254", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001254", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001254")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001255")
    void case_UTAPI_001255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001255",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001255", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001255", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001255", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001255", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001255")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001256")
    void case_UTAPI_001256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001256",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001256", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001256", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001256", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001256", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001256")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001257")
    void case_UTAPI_001257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001257",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001257", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001257", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001257", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001257", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001257")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001258")
    void case_UTAPI_001258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001258",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001258", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001258", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001258", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001258", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001258")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001259")
    void case_UTAPI_001259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001259",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001259", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001259", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001259", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001259", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001259")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001260")
    void case_UTAPI_001260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001260",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001260", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001260", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001260", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001260", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001260")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001261")
    void case_UTAPI_001261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001261",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001261", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001261", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001261", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001261", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001261")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001262")
    void case_UTAPI_001262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001262",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001262", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001262", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001262", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001262", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001262")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001263")
    void case_UTAPI_001263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001263",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictDiff",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001263", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001263", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001263", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001263", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001263")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictDiff::12::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.calcDiff")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.calcDiff", "conflictUseCase", "calcDiff")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.calcDiff must carry the value generated for request.connectionId", "conflictUseCase", "calcDiff", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.calcDiff must carry the value generated for request.schemaName", "conflictUseCase", "calcDiff", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.calcDiff must carry the value generated for name", "conflictUseCase", "calcDiff", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMemoRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMemoRepository#findByConnectionIdAndTableName.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMemoRepositoryFindByConnectionIdAndTableNameScenario {

    @Test
    @DisplayName("UTAPI-008776")
    void case_UTAPI_008776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008776",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008776", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008776", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008776")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008777")
    void case_UTAPI_008777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008777",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008777", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008777", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008777")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008778")
    void case_UTAPI_008778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008778",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008778", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008778", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008778")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008779")
    void case_UTAPI_008779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008779",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008779", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008779", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008779")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008780")
    void case_UTAPI_008780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008780",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008780", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008780", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008780")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008781")
    void case_UTAPI_008781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008781",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008781", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008781", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008781")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008782")
    void case_UTAPI_008782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008782",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008782", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008782", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008782")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008783")
    void case_UTAPI_008783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008783",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008783", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008783", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008783")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008784")
    void case_UTAPI_008784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008784",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008784", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008784", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008784")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008785")
    void case_UTAPI_008785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008785",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008785", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008785", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008785")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008786")
    void case_UTAPI_008786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008786",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008786", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008786", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008786")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008787")
    void case_UTAPI_008787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008787",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008787", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008787", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008787")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008788")
    void case_UTAPI_008788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008788",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008788", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008788", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008788")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008789")
    void case_UTAPI_008789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008789",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008789", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008789", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008789")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008790")
    void case_UTAPI_008790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008790",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008790", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008790", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008790")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008791")
    void case_UTAPI_008791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008791",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008791", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008791", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008791")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008792")
    void case_UTAPI_008792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008792",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008792", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008792", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008792")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008793")
    void case_UTAPI_008793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008793",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008793", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008793", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008793")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008794")
    void case_UTAPI_008794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008794",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008794", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008794", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008794")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008795")
    void case_UTAPI_008795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008795",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008795", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008795", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008795")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008796")
    void case_UTAPI_008796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008796",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008796", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008796", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008796")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008797")
    void case_UTAPI_008797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008797",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008797", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008797", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008797")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008798")
    void case_UTAPI_008798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008798",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008798", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008798", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008798")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008799")
    void case_UTAPI_008799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008799",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008799", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008799", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008799")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008800")
    void case_UTAPI_008800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008800",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008800", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008800", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008800")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008801")
    void case_UTAPI_008801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008801",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008801", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008801", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008801")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008802")
    void case_UTAPI_008802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008802",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008802", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008802", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008802")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008803")
    void case_UTAPI_008803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008803",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008803", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008803", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008803")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008804")
    void case_UTAPI_008804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008804",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008804", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008804", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008804")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008805")
    void case_UTAPI_008805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008805",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008805", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008805", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008805")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008806")
    void case_UTAPI_008806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008806",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008806", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008806", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008806")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008807")
    void case_UTAPI_008807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008807",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008807", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008807", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008807")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

}

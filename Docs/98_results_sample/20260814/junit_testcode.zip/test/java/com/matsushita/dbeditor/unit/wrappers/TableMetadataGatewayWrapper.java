package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableMetadataGateway.
 */
public final class TableMetadataGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableMetadataGateway";
    private static final String[] DEP_NAMES = new String[] {"targetDatabaseConnector", "QUERY_TABLES"};
    private static final String[] DEP_TYPES = new String[] {"TargetDatabaseConnector", "String"};
    private static final String[] TYPES_findAllTables = new String[] {"ConnectionSetting"};

    public TableMetadataGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** List<TableMetadata> findAllTables(setting) */
    public ExecutionResult findAllTables(Object[] args) {
        return invoke("findAllTables", TYPES_findAllTables, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("findAllTables".equals(operation)) {
            return findAllTables(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

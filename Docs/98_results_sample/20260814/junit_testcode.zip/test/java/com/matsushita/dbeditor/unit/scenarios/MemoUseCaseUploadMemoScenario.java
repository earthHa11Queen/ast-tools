package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoUseCase#uploadMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoUseCaseUploadMemoScenario {

    @Test
    @DisplayName("UTAPI-012693")
    void case_UTAPI_012693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012693",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012693", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012693", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012693", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012693")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012694")
    void case_UTAPI_012694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012694",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012694", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012694", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012694", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012694")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012695")
    void case_UTAPI_012695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012695",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012695", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012695", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012695", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012695")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012696")
    void case_UTAPI_012696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012696",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012696", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012696", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012696", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012696")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012697")
    void case_UTAPI_012697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012697",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012697", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012697", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012697", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012697")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012698")
    void case_UTAPI_012698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012698",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012698", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012698", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012698", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012698")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012699")
    void case_UTAPI_012699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012699",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012699", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012699", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012699", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012699")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012700")
    void case_UTAPI_012700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012700",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012700", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012700", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012700", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012700")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012701")
    void case_UTAPI_012701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012701",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012701", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012701", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012701", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012701")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012702")
    void case_UTAPI_012702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012702",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012702", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012702", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012702", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012702")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012703")
    void case_UTAPI_012703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012703",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012703", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012703", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012703", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012703")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012704")
    void case_UTAPI_012704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012704",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012704", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012704", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012704", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012704")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012705")
    void case_UTAPI_012705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012705",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012705", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012705", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012705", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012705")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012706")
    void case_UTAPI_012706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012706",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012706", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012706", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012706", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012706")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012707")
    void case_UTAPI_012707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012707",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012707", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012707", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012707", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012707")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012708")
    void case_UTAPI_012708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012708",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012708", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012708", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012708", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012708")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012709")
    void case_UTAPI_012709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012709",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012709", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012709", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012709", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012709")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012710")
    void case_UTAPI_012710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012710",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012710", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012710", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012710", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012710")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012711")
    void case_UTAPI_012711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012711",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012711", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012711", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012711", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012711")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012712")
    void case_UTAPI_012712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012712",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012712", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012712", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012712", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012712")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012713")
    void case_UTAPI_012713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012713",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012713", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012713", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012713", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012713")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012714")
    void case_UTAPI_012714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012714",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012714", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012714", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012714", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012714")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012715")
    void case_UTAPI_012715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012715",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012715", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012715", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012715", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012715")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012716")
    void case_UTAPI_012716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012716",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012716", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012716", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012716", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012716")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012717")
    void case_UTAPI_012717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012717",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012717", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012717", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012717", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012717")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012718")
    void case_UTAPI_012718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012718",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012718", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012718", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012718", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012718")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012719")
    void case_UTAPI_012719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012719",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012719", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012719", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012719", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012719")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012720")
    void case_UTAPI_012720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012720",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012720", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012720", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012720", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012720")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012721")
    void case_UTAPI_012721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012721",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012721", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012721", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012721", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012721")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012722")
    void case_UTAPI_012722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012722",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012722", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012722", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012722", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012722")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012723")
    void case_UTAPI_012723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012723",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012723", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012723", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012723", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012723")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012724")
    void case_UTAPI_012724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012724",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012724", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012724", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012724", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012724")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012725")
    void case_UTAPI_012725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012725",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012725", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012725", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012725", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012725")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "1:length_null", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012726")
    void case_UTAPI_012726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012726",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012726", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012726", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012726", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012726")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012727")
    void case_UTAPI_012727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012727",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012727", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012727", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012727", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012727")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "3:length_min", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012728")
    void case_UTAPI_012728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012728",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012728", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012728", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012728", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012728")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012729")
    void case_UTAPI_012729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012729",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012729", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012729", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012729", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012729")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "5:length_max", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012730")
    void case_UTAPI_012730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012730",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012730", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012730", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012730", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012730")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012731")
    void case_UTAPI_012731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012731",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012731", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012731", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012731", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012731")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012732")
    void case_UTAPI_012732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012732",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012732", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012732", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012732", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012732")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012733")
    void case_UTAPI_012733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012733",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012733", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012733", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012733", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012733")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012734")
    void case_UTAPI_012734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012734",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012734", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012734", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012734", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012734")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012735")
    void case_UTAPI_012735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012735",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012735", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012735", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012735", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012735")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012736")
    void case_UTAPI_012736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012736",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012736", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012736", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012736", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012736")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012737")
    void case_UTAPI_012737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012737",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012737", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012737", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012737", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012737")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "56:space")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012738")
    void case_UTAPI_012738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012738",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012738", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012738", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012738", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012738")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012739")
    void case_UTAPI_012739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012739",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012739", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012739", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012739", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012739")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012740")
    void case_UTAPI_012740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012740",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012740", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012740", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012740", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012740")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "59:tab")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012741")
    void case_UTAPI_012741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012741",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012741", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012741", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012741", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012741")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012742")
    void case_UTAPI_012742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012742",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012742", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012742", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012742", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012742")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012743")
    void case_UTAPI_012743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012743",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012743", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012743", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012743", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012743")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012744")
    void case_UTAPI_012744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012744",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "uploadMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012744", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012744", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012744", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012744")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::uploadMemo::4::ARG::3::-::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#executeSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseExecuteSqlScenario {

    @Test
    @DisplayName("UTAPI-012851")
    void case_UTAPI_012851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012851",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012851", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012851", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012851")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012852")
    void case_UTAPI_012852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012852",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012852", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012852", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012852")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012853")
    void case_UTAPI_012853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012853",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012853", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012853", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012853")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012854")
    void case_UTAPI_012854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012854",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012854", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012854", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012854")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012855")
    void case_UTAPI_012855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012855",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012855", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012855", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012855")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012856")
    void case_UTAPI_012856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012856",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012856", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012856", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012856")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012857")
    void case_UTAPI_012857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012857",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012857", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012857", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012857")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012858")
    void case_UTAPI_012858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012858",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012858", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012858", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012858")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012859")
    void case_UTAPI_012859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012859",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012859", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012859", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012859")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012860")
    void case_UTAPI_012860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012860",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012860", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012860", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012860")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012861")
    void case_UTAPI_012861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012861",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012861", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012861", "sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012861")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012862")
    void case_UTAPI_012862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012862",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012862", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012862", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012862")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "1:length_null", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012863")
    void case_UTAPI_012863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012863",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012863", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012863", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012863")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "2:length_empty", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012864")
    void case_UTAPI_012864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012864",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012864", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012864", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012864")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "3:length_min", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012865")
    void case_UTAPI_012865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012865",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012865", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012865", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012865")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012866")
    void case_UTAPI_012866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012866",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012866", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012866", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012866")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "5:length_max", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012867")
    void case_UTAPI_012867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012867",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012867", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012867", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012867")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012868")
    void case_UTAPI_012868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012868",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012868", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012868", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012868")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012869")
    void case_UTAPI_012869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012869",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012869", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012869", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012869")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012870")
    void case_UTAPI_012870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012870",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012870", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012870", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012870")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012871")
    void case_UTAPI_012871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012871",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012871", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012871", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012871")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012872")
    void case_UTAPI_012872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012872",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012872", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012872", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012872")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012873")
    void case_UTAPI_012873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012873",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012873", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012873", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012873")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012874")
    void case_UTAPI_012874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012874",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012874", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012874", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012874")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "56:space")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012875")
    void case_UTAPI_012875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012875",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012875", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012875", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012875")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012876")
    void case_UTAPI_012876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012876",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012876", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012876", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012876")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012877")
    void case_UTAPI_012877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012877",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012877", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012877", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012877")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "59:tab")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012878")
    void case_UTAPI_012878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012878",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012878", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012878", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012878")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012879")
    void case_UTAPI_012879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012879",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012879", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012879", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012879")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012880")
    void case_UTAPI_012880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012880",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012880", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012880", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012880")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012881")
    void case_UTAPI_012881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012881",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "executeSql",
                "SqlExecuteResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("sql", "String", "sql")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012881", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012881", "sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012881")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::executeSql::4::ARG::2::-::sql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("sql", "sql")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of connector.any declared operation")
                    .expected("the value generated for sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through connector", "connector", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for sql must reach JdbcTemplate unchanged", "JdbcTemplate", "", "data:sql")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

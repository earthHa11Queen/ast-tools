package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryGateway#ensureHistoryIndex.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryGatewayEnsureHistoryIndexScenario {

    @Test
    @DisplayName("UTAPI-003859")
    void case_UTAPI_003859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003859",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003859", "jdbc", "TARGET", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003859", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003859")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::1::-::jdbc")
                    .mirror("-", "1:length_null", "-")
                    .target("jdbc", "jdbc")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the outcome for a missing JDBC handle")
                    .expected("the operation fails instead of silently skipping the statement")
                    .failure("the call returns normally although no statement can be executed")
                    .assertion("assertThrows for the missing handle")
                    .check(CheckType.EXCEPTION_REQUIRED, "without a JDBC handle the index cannot be maintained", "java.lang.RuntimeException", "data:jdbc")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003860")
    void case_UTAPI_003860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003860",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003860", "jdbc", "TARGET", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003860", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003860")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::1::-::jdbc")
                    .mirror("-", "2:length_empty", "-")
                    .target("jdbc", "jdbc")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for jdbc reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NOT_INVOKED, "the supplied handle must be used instead of opening another connection", "targetDatabaseConnector", "", "data:jdbc")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003861")
    void case_UTAPI_003861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003861",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003861", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003861", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003861")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003862")
    void case_UTAPI_003862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003862",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003862", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003862", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003862")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003863")
    void case_UTAPI_003863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003863",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003863", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003863", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003863")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003864")
    void case_UTAPI_003864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003864",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003864", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003864", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003864")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003865")
    void case_UTAPI_003865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003865",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003865", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003865", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003865")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003866")
    void case_UTAPI_003866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003866",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003866", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003866", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003866")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003867")
    void case_UTAPI_003867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003867",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003867", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003867", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003867")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003868")
    void case_UTAPI_003868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003868",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003868", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003868", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003868")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003869")
    void case_UTAPI_003869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003869",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003869", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003869", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003869")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003870")
    void case_UTAPI_003870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003870",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003870", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003870", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003871")
    void case_UTAPI_003871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003871",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003871", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003871", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003872")
    void case_UTAPI_003872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003872",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003872", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003872", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003872")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003873")
    void case_UTAPI_003873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003873",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003873", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003873", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003873")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003874")
    void case_UTAPI_003874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003874",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003874", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003874", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003874")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003875")
    void case_UTAPI_003875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003875",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003875", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003875", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003875")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003876")
    void case_UTAPI_003876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003876",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003876", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003876", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003876")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003877")
    void case_UTAPI_003877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003877",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003877", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003877", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003877")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003878")
    void case_UTAPI_003878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003878",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003878", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003878", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003878")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003879")
    void case_UTAPI_003879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003879",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003879", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003879", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003879")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003880")
    void case_UTAPI_003880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003880",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003880", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003880", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003880")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003881")
    void case_UTAPI_003881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003881",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "ensureHistoryIndex",
                "void",
                new ParamSpec[] {
                    new ParamSpec("jdbc", "JdbcTemplate", "jdbc"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003881", "jdbc", "NORMAL", "OBJECT", "JdbcTemplate"),
                    new DataRef("UTAPI-003881", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003881")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::ensureHistoryIndex::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

}

package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableRecordGateway.
 */
public final class TableRecordGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway";
    private static final String[] DEP_NAMES = new String[] {"targetDatabaseConnector"};
    private static final String[] DEP_TYPES = new String[] {"TargetDatabaseConnector"};
    private static final String[] TYPES_createCopyTable = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_dropTable = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_findAllCopyRecords = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_findAllRecords = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_findStaleTables = new String[] {"ConnectionSetting", "String"};
    private static final String[] TYPES_updateCopyRecords = new String[] {"ConnectionSetting", "String", "String", "List<Map<String, Object>>"};

    public TableRecordGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void createCopyTable(setting, schemaName, tableName) */
    public ExecutionResult createCopyTable(Object[] args) {
        return invoke("createCopyTable", TYPES_createCopyTable, args);
    }

    /** void dropTable(setting, schemaName, tableName) */
    public ExecutionResult dropTable(Object[] args) {
        return invoke("dropTable", TYPES_dropTable, args);
    }

    /** List<Map<String,Object>> findAllCopyRecords(setting, schemaName, tableName) */
    public ExecutionResult findAllCopyRecords(Object[] args) {
        return invoke("findAllCopyRecords", TYPES_findAllCopyRecords, args);
    }

    /** List<Map<String,Object>> findAllRecords(setting, schemaName, tableName) */
    public ExecutionResult findAllRecords(Object[] args) {
        return invoke("findAllRecords", TYPES_findAllRecords, args);
    }

    /** List<String> findStaleTables(setting, schemaName) */
    public ExecutionResult findStaleTables(Object[] args) {
        return invoke("findStaleTables", TYPES_findStaleTables, args);
    }

    /** void updateCopyRecords(setting, schemaName, tableName, records) */
    public ExecutionResult updateCopyRecords(Object[] args) {
        return invoke("updateCopyRecords", TYPES_updateCopyRecords, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("createCopyTable".equals(operation)) {
            return createCopyTable(args);
        } else if ("dropTable".equals(operation)) {
            return dropTable(args);
        } else if ("findAllCopyRecords".equals(operation)) {
            return findAllCopyRecords(args);
        } else if ("findAllRecords".equals(operation)) {
            return findAllRecords(args);
        } else if ("findStaleTables".equals(operation)) {
            return findStaleTables(args);
        } else if ("updateCopyRecords".equals(operation)) {
            return updateCopyRecords(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

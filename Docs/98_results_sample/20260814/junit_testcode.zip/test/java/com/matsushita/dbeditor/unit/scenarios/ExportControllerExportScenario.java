package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportController#export.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportControllerExportScenario {

    @Test
    @DisplayName("UTAPI-000424")
    void case_UTAPI_000424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000424",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000424", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000424", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000424", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000424", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000424")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000425")
    void case_UTAPI_000425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000425",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000425", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000425", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000425", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000425", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000425")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000426")
    void case_UTAPI_000426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000426",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000426", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000426", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000426", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000426", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000426")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000427")
    void case_UTAPI_000427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000427",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000427", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000427", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000427", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000427", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000427")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000428")
    void case_UTAPI_000428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000428",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000428", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000428", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000428", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000428", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000428")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000429")
    void case_UTAPI_000429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000429",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000429", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000429", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000429", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000429", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000429")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000430")
    void case_UTAPI_000430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000430",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000430", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000430", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000430", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000430", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000430")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000431")
    void case_UTAPI_000431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000431",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000431", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000431", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000431", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000431", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000431")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000432")
    void case_UTAPI_000432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000432",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000432", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000432", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000432", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000432", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000432")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000433")
    void case_UTAPI_000433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000433",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000433", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000433", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000433", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000433", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000433")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000434")
    void case_UTAPI_000434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000434",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000434", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000434", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000434", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000434", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000434")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000435")
    void case_UTAPI_000435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000435",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000435", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000435", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000435", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000435", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000435")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000436")
    void case_UTAPI_000436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000436",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000436", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000436", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000436", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000436", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000436")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000437")
    void case_UTAPI_000437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000437",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000437", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000437", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000437", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000437", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000437")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000438")
    void case_UTAPI_000438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000438",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000438", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000438", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000438", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000438", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000438")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000439")
    void case_UTAPI_000439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000439",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000439", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000439", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000439", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000439", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000439")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000440")
    void case_UTAPI_000440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000440",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000440", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000440", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000440", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000440", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000440")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000441")
    void case_UTAPI_000441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000441",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000441", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000441", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000441", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000441", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000441")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000442")
    void case_UTAPI_000442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000442",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000442", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000442", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000442", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000442", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000442")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000443")
    void case_UTAPI_000443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000443",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000443", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000443", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000443", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000443", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000443")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000444")
    void case_UTAPI_000444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000444",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000444", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000444", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000444", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000444", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000444")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000445")
    void case_UTAPI_000445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000445",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000445", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000445", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000445", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000445", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000445")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000446")
    void case_UTAPI_000446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000446",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000446", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000446", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000446", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000446", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000446")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000447")
    void case_UTAPI_000447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000447",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000447", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000447", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000447", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000447", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000447")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000448")
    void case_UTAPI_000448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000448",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000448", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000448", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000448", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000448", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000448")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000449")
    void case_UTAPI_000449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000449",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000449", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000449", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000449", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000449", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000449")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000450")
    void case_UTAPI_000450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000450",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000450", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000450", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000450", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000450", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000450")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000451")
    void case_UTAPI_000451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000451",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000451", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000451", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000451", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000451", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000451")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000452")
    void case_UTAPI_000452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000452",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000452", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000452", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000452", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000452", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000452")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000453")
    void case_UTAPI_000453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000453",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000453", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000453", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000453", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000453", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000453")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000454")
    void case_UTAPI_000454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000454",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000454", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000454", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000454", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000454", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000454")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000455")
    void case_UTAPI_000455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000455",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000455", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000455", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000455", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000455", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000455")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000456")
    void case_UTAPI_000456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000456",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000456", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000456", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000456", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000456", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000456")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "1:length_null", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000457")
    void case_UTAPI_000457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000457",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000457", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000457", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000457", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000457", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000457")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "2:length_empty", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000458")
    void case_UTAPI_000458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000458",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000458", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000458", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000458", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000458", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000458")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "3:length_min", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000459")
    void case_UTAPI_000459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000459",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000459", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000459", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000459", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000459", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000459")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000460")
    void case_UTAPI_000460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000460",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000460", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000460", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000460", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000460", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000460")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "5:length_max", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000461")
    void case_UTAPI_000461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000461",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000461", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000461", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000461", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000461", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000461")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000462")
    void case_UTAPI_000462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000462",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000462", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000462", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000462", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000462", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000462")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000463")
    void case_UTAPI_000463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000463",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000463", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000463", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000463", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000463", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000463")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000464")
    void case_UTAPI_000464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000464",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000464", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000464", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000464", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000464", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000464")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000465")
    void case_UTAPI_000465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000465",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000465", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000465", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000465", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000465", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000465")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000466")
    void case_UTAPI_000466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000466",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000466", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000466", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000466", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000466", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000466")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000467")
    void case_UTAPI_000467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000467",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000467", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000467", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000467", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000467", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000467")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000468")
    void case_UTAPI_000468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000468",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000468", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000468", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000468", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000468", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000468")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "56:space")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000469")
    void case_UTAPI_000469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000469",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000469", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000469", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000469", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000469", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000469")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000470")
    void case_UTAPI_000470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000470",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000470", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000470", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000470", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000470", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000470")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000471")
    void case_UTAPI_000471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000471",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000471", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000471", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000471", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000471", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000471")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "59:tab")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000472")
    void case_UTAPI_000472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000472",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000472", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000472", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000472", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000472", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000472")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "60:control_character_null")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000473")
    void case_UTAPI_000473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000473",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000473", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000473", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000473", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000473", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000473")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000474")
    void case_UTAPI_000474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000474",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000474", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000474", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000474", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000474", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000474")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000475")
    void case_UTAPI_000475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000475",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000475", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000475", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000475", "format", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000475", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000475")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::3::-::format")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("format", "format")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for format is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an unsupported export format must be rejected before any export is produced", "java.lang.IllegalArgumentException", "exportUseCase")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.INVOKED_ONCE, "the requested format must select exactly one export operation", "exportUseCase", "", "data:format")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000476")
    void case_UTAPI_000476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000476",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000476", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000476", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000476", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000476", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000476")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000477")
    void case_UTAPI_000477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000477",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000477", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000477", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000477", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000477", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000477")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000478")
    void case_UTAPI_000478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000478",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000478", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000478", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000478", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000478", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000478")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000479")
    void case_UTAPI_000479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000479",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000479", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000479", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000479", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000479", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000479")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000480")
    void case_UTAPI_000480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000480",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000480", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000480", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000480", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000480", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000480")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000481")
    void case_UTAPI_000481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000481",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000481", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000481", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000481", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000481", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000481")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000482")
    void case_UTAPI_000482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000482",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000482", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000482", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000482", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000482", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000482")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000483")
    void case_UTAPI_000483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000483",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000483", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000483", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000483", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000483", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000483")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000484")
    void case_UTAPI_000484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000484",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000484", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000484", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000484", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000484", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000484")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000485")
    void case_UTAPI_000485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000485",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000485", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000485", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000485", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000485", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000485")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000486")
    void case_UTAPI_000486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000486",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000486", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000486", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000486", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000486", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000486")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000487")
    void case_UTAPI_000487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000487",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000487", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000487", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000487", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000487", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000487")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000488")
    void case_UTAPI_000488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000488",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000488", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000488", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000488", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000488", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000489")
    void case_UTAPI_000489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000489",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000489", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000489", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000489", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000489", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000490")
    void case_UTAPI_000490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000490",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000490", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000490", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000490", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000490", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000491")
    void case_UTAPI_000491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000491",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000491", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000491", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000491", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000491", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000492")
    void case_UTAPI_000492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000492",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000492", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000492", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000492", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000492", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000493")
    void case_UTAPI_000493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000493",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000493", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000493", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000493", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000493", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000494")
    void case_UTAPI_000494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000494",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000494", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000494", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000494", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000494", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000495")
    void case_UTAPI_000495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000495",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "export",
                "ResponseEntity<byte[]>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("format", "String", "format"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000495", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000495", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000495", "format", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000495", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::export::1::ARG::4::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of exportUseCase.any declared operation")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through exportUseCase", "exportUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of exportUseCase.any declared operation must carry the value generated for connectionId", "exportUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of exportUseCase.any declared operation must carry the value generated for schema", "exportUseCase", "", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of exportUseCase.any declared operation must carry the value generated for name", "exportUseCase", "", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportControllerWrapper());
    }

}
